# Bin Hayyan Pharmacy - GitHub Pages Publishing Guide

## 🚀 How to Publish in 60 Seconds:
1. Extract this ZIP file on your computer.
2. Go to https://github.com/new and create a new repository (e.g. `bin-hayyan-pharmacy`, set to Public).
3. Click "uploading an existing file" (or Add file -> Upload files).
4. Select all files inside the extracted folder (`index.html`, `assets`, `404.html`, `.nojekyll`) and drag them onto GitHub.
5. Click "Commit changes".
6. In your GitHub repository:
   - Click "Settings" (top tab) -> "Pages" (left sidebar).
   - Under "Build and deployment > Source", select "Deploy from a branch".
   - Select Branch: `main` and folder `/(root)`.
   - Click Save!
7. Within 60 seconds, your pharmacy website is live at:
   https://<your-username>.github.io/bin-hayyan-pharmacy/

Admin Portal: Access via the "Admin" button on top or visit /#admin
Default Admin: admin@binhayyanpharmacy.pk / password: admin123
