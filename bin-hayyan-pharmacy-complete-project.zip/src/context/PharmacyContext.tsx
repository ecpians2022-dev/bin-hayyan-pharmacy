import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  Product,
  CartItem,
  Order,
  Prescription,
  DeliveryZone,
  PharmacySettings,
  User,
  UserRole,
  MedicineRequest,
  OrderStatus,
  PrescriptionStatus,
  ProductCategory,
} from '../types/pharmacy';
import { StorageService } from '../services/storage';

export type AppPage =
  | 'home'
  | 'shop'
  | 'product-detail'
  | 'cart'
  | 'checkout'
  | 'order-confirmation'
  | 'order-tracking'
  | 'prescription-upload'
  | 'account'
  | 'contact'
  | 'about'
  | 'faqs'
  | 'policies'
  | 'admin'
  | 'request-medicine'
  | '404';

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

interface PharmacyContextType {
  // Navigation & Page State
  currentPage: AppPage;
  navigateTo: (page: AppPage, params?: Record<string, any>) => void;
  pageParams: Record<string, any>;

  // Products
  products: Product[];
  categories: ProductCategory[];
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  selectedCategory: ProductCategory | 'All';
  setSelectedCategory: (cat: ProductCategory | 'All') => void;
  selectedProduct: Product | null;
  setSelectedProduct: (p: Product | null) => void;
  addProduct: (p: Product) => void;
  updateProduct: (p: Product) => void;
  deleteProduct: (id: string) => void;

  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  cartSubtotal: number;
  cartItemCount: number;

  // Wishlist
  wishlist: string[];
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;

  // Auth & Roles
  currentUser: User | null;
  login: (email: string, password?: string, role?: UserRole) => boolean;
  logout: () => void;
  register: (name: string, email: string, phone: string, password?: string) => boolean;
  switchRole: (role: UserRole) => void;
  changePassword: (userId: string, oldPass: string, newPass: string) => boolean;
  createSubUser: (subUserData: Omit<User, 'id' | 'createdAt'>) => User;
  updateSubUser: (user: User) => void;
  deleteSubUser: (userId: string) => void;
  users: User[];

  // Customer Auth Modal (for registration before placing order)
  authModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;

  // Orders
  orders: Order[];
  placeOrder: (orderData: Omit<Order, 'id' | 'orderNumber' | 'timeline' | 'createdAt'>) => Order;
  updateOrderStatus: (orderId: string, status: OrderStatus, note?: string) => void;
  getOrder: (idOrNumber: string) => Order | undefined;

  // Prescriptions
  prescriptions: Prescription[];
  uploadPrescription: (
    data: Omit<Prescription, 'id' | 'referenceNumber' | 'status' | 'uploadedAt'>
  ) => Prescription;
  updatePrescriptionStatus: (
    prescriptionId: string,
    status: PrescriptionStatus,
    notes?: string,
    pharmacistName?: string
  ) => void;

  // Delivery Zones
  deliveryZones: DeliveryZone[];
  updateDeliveryZones: (zones: DeliveryZone[]) => void;

  // Settings
  settings: PharmacySettings;
  updateSettings: (settings: PharmacySettings) => void;

  // Medicine Requests
  medicineRequests: MedicineRequest[];
  submitMedicineRequest: (req: Omit<MedicineRequest, 'id' | 'createdAt' | 'status'>) => void;
  updateMedicineRequestStatus: (id: string, status: MedicineRequest['status']) => void;

  // Toasts
  toasts: Toast[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;

  // Demo Data Reset
  resetDemoData: () => void;
}

const PharmacyContext = createContext<PharmacyContextType | undefined>(undefined);

export const PharmacyProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const getInitialPage = (): AppPage => {
    if (typeof window !== 'undefined') {
      const pathname = window.location.pathname.toLowerCase();
      const hash = window.location.hash.toLowerCase().replace('#', '').replace('/', '');
      if (pathname === '/admin' || pathname.startsWith('/admin') || hash === 'admin') {
        return 'admin';
      }
      if (
        hash &&
        [
          'home',
          'shop',
          'cart',
          'checkout',
          'order-tracking',
          'prescription-upload',
          'account',
          'contact',
          'about',
          'faqs',
          'policies',
          'request-medicine',
        ].includes(hash)
      ) {
        return hash as AppPage;
      }
    }
    return 'home';
  };

  const [currentPage, setCurrentPage] = useState<AppPage>(getInitialPage);
  const [pageParams, setPageParams] = useState<Record<string, any>>({});
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([]);
  const [deliveryZones, setDeliveryZones] = useState<DeliveryZone[]>([]);
  const [settings, setSettings] = useState<PharmacySettings>(StorageService.getSettings());
  const [users, setUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [medicineRequests, setMedicineRequests] = useState<MedicineRequest[]>([]);
  const [authModalOpen, setAuthModalOpen] = useState(false);

  // Cart
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('bhp_cart_items');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory | 'All'>('All');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Toasts
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Categories list
  const categories: ProductCategory[] = [
    'Medicines',
    'Prescription Medicines',
    'OTC Medicines',
    'Vitamins & Supplements',
    'Pain Relief',
    'Cold & Flu',
    'Digestive Health',
    'Diabetes Care',
    'Blood Pressure Care',
    'Personal Care',
    'Skin Care',
    'Baby Care',
    'Medical Devices',
    'First Aid',
  ];

  // Initialize data on mount
  useEffect(() => {
    setProducts(StorageService.getProducts());
    setOrders(StorageService.getOrders());
    setPrescriptions(StorageService.getPrescriptions());
    setDeliveryZones(StorageService.getDeliveryZones());
    setSettings(StorageService.getSettings());
    const allUsers = StorageService.getUsers();
    setUsers(allUsers);

    // If an existing session was saved, restore it; otherwise start as guest
    const curr = StorageService.getCurrentUser();
    if (curr) {
      setCurrentUser(curr);
    } else {
      // Default as guest customer so customer can browse freely without login,
      // and will register/login before placing online orders
      setCurrentUser(null);
    }

    setWishlist(StorageService.getWishlist());
    setMedicineRequests(StorageService.getMedicineRequests());

    // Listen to browser navigation popstate and hashchange
    const handleLocationChange = () => {
      const pathname = window.location.pathname.toLowerCase();
      const hash = window.location.hash.toLowerCase().replace('#', '').replace('/', '');
      if (pathname === '/admin' || pathname.startsWith('/admin') || hash === 'admin') {
        setCurrentPage('admin');
      } else if (
        hash &&
        [
          'home',
          'shop',
          'cart',
          'checkout',
          'order-tracking',
          'prescription-upload',
          'account',
          'contact',
          'about',
          'faqs',
          'policies',
          'request-medicine',
        ].includes(hash)
      ) {
        setCurrentPage(hash as AppPage);
      } else if (pathname === '/' && !hash) {
        setCurrentPage('home');
      }
    };

    window.addEventListener('popstate', handleLocationChange);
    window.addEventListener('hashchange', handleLocationChange);

    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.removeEventListener('hashchange', handleLocationChange);
    };
  }, []);

  // Sync cart to storage
  useEffect(() => {
    try {
      localStorage.setItem('bhp_cart_items', JSON.stringify(cart));
    } catch (e) {
      console.warn('Cart persistence error', e);
    }
  }, [cart]);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Date.now().toString() + Math.random().toString().slice(2, 6);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const navigateTo = (page: AppPage, params: Record<string, any> = {}) => {
    setCurrentPage(page);
    setPageParams(params);
    window.scrollTo({ top: 0, behavior: 'smooth' });

    try {
      if (page === 'admin') {
        if (window.location.pathname !== '/admin') {
          window.history.pushState({ page }, '', '/admin');
        }
      } else if (page === 'home') {
        if (window.location.pathname !== '/' || window.location.hash) {
          window.history.pushState({ page }, '', '/');
        }
      } else {
        window.history.pushState({ page }, '', `/#${page}`);
      }
    } catch {
      // Ignore if iframe restricts pushState
    }
  };

  // Product actions
  const addProduct = (p: Product) => {
    StorageService.saveProduct(p);
    setProducts(StorageService.getProducts());
    showToast(`Product "${p.name}" added successfully.`, 'success');
  };

  const updateProduct = (p: Product) => {
    StorageService.saveProduct(p);
    setProducts(StorageService.getProducts());
    showToast(`Product "${p.name}" updated successfully.`, 'success');
  };

  const deleteProduct = (id: string) => {
    StorageService.deleteProduct(id);
    setProducts(StorageService.getProducts());
    showToast('Product removed from catalog.', 'info');
  };

  // Cart actions
  const addToCart = (product: Product, quantity = 1) => {
    if (product.stock <= 0) {
      showToast('This product is currently out of stock.', 'error');
      return;
    }

    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        const newQty = existing.quantity + quantity;
        if (newQty > product.stock) {
          showToast(`Only ${product.stock} units available in stock.`, 'info');
          return prev.map((item) =>
            item.product.id === product.id ? { ...item, quantity: product.stock } : item
          );
        }
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: newQty } : item
        );
      }
      return [...prev, { product, quantity: Math.min(quantity, product.stock) }];
    });

    showToast(`Added ${product.name} to your cart`, 'success');
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
    showToast('Item removed from cart.', 'info');
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => {
        if (item.product.id === productId) {
          const validQty = Math.min(quantity, item.product.stock);
          return { ...item, quantity: validQty };
        }
        return item;
      })
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartSubtotal = cart.reduce((sum, item) => {
    const price = item.product.discountPrice ?? item.product.price;
    return sum + price * item.quantity;
  }, 0);

  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Wishlist actions
  const toggleWishlist = (productId: string) => {
    let nextWishlist: string[];
    if (wishlist.includes(productId)) {
      nextWishlist = wishlist.filter((id) => id !== productId);
      showToast('Removed from wishlist.', 'info');
    } else {
      nextWishlist = [...wishlist, productId];
      showToast('Saved to your wishlist!', 'success');
    }
    setWishlist(nextWishlist);
    StorageService.saveWishlist(nextWishlist);
  };

  const isInWishlist = (productId: string) => wishlist.includes(productId);

  // Auth actions
  const login = (email: string, password?: string, role: UserRole = 'customer') => {
    const existing = users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
    if (existing) {
      if (password && existing.password && existing.password !== password) {
        showToast('Invalid password. Please check your credentials.', 'error');
        return false;
      }
      if (existing.isActive === false) {
        showToast('This account has been deactivated. Please contact administrator.', 'error');
        return false;
      }
      setCurrentUser(existing);
      StorageService.setCurrentUser(existing);
      showToast(`Welcome back, ${existing.name}!`, 'success');
      return true;
    }

    // If logging in with password for non-existent account
    if (password) {
      showToast('No account found with this email. Please check your details or register.', 'error');
      return false;
    }

    // New login fallback (quick-mode)
    const newUser: User = {
      id: `usr-${Date.now()}`,
      name: email.split('@')[0],
      email: email.trim(),
      phone: '+92 300 0000000',
      role,
      password: 'password123',
      isActive: true,
      createdAt: new Date().toISOString(),
    };
    const updatedUsers = [...users, newUser];
    setUsers(updatedUsers);
    StorageService.saveUsers(updatedUsers);
    setCurrentUser(newUser);
    StorageService.setCurrentUser(newUser);
    showToast(`Welcome, ${newUser.name}!`, 'success');
    return true;
  };

  const register = (
    name: string,
    email: string,
    phone: string,
    password = 'customer123'
  ) => {
    const existing = users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
    if (existing) {
      showToast('An account with this email already exists. Please sign in.', 'error');
      return false;
    }

    const newUser: User = {
      id: `usr-${Date.now()}`,
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      role: 'customer',
      password,
      isActive: true,
      savedAddresses: [],
      createdAt: new Date().toISOString(),
    };
    const updated = [...users, newUser];
    setUsers(updated);
    StorageService.saveUsers(updated);
    setCurrentUser(newUser);
    StorageService.setCurrentUser(newUser);
    showToast(`Account created! Welcome to Bin Hayyan Pharmacy, ${newUser.name}.`, 'success');
    return true;
  };

  const logout = () => {
    setCurrentUser(null);
    StorageService.setCurrentUser(null);
    showToast('You have been signed out.', 'info');
    navigateTo('home');
  };

  const changePassword = (userId: string, oldPass: string, newPass: string): boolean => {
    const user = users.find((u) => u.id === userId);
    if (!user) {
      showToast('User not found.', 'error');
      return false;
    }

    if (user.password && user.password !== oldPass) {
      showToast('Current password does not match.', 'error');
      return false;
    }

    if (!newPass || newPass.length < 5) {
      showToast('New password must be at least 5 characters long.', 'error');
      return false;
    }

    const updatedUser: User = { ...user, password: newPass };
    StorageService.updateUser(updatedUser);
    setUsers(StorageService.getUsers());
    if (currentUser?.id === userId) {
      setCurrentUser(updatedUser);
    }
    showToast('Password changed successfully!', 'success');
    return true;
  };

  const createSubUser = (subUserData: Omit<User, 'id' | 'createdAt'>): User => {
    const newUser: User = {
      ...subUserData,
      id: `usr-sub-${Date.now()}`,
      isActive: true,
      createdAt: new Date().toISOString(),
    };
    StorageService.updateUser(newUser);
    setUsers(StorageService.getUsers());
    showToast(`Staff member "${newUser.name}" created successfully.`, 'success');
    return newUser;
  };

  const updateSubUser = (user: User) => {
    StorageService.updateUser(user);
    setUsers(StorageService.getUsers());
    if (currentUser?.id === user.id) {
      setCurrentUser(user);
    }
    showToast(`Staff account "${user.name}" updated.`, 'success');
  };

  const deleteSubUser = (userId: string) => {
    StorageService.deleteUser(userId);
    setUsers(StorageService.getUsers());
    showToast('Staff sub-user removed.', 'info');
  };

  const switchRole = (role: UserRole) => {
    const targetUser = users.find((u) => u.role === role);
    if (targetUser) {
      setCurrentUser(targetUser);
      StorageService.setCurrentUser(targetUser);
      showToast(`Switched view to ${role.toUpperCase()}: ${targetUser.name}`, 'info');
    } else {
      const tempUser: User = {
        id: `usr-${role}-${Date.now()}`,
        name: `${role.charAt(0).toUpperCase() + role.slice(1)} Staff`,
        email: `${role}@binhayyanpharmacy.pk`,
        phone: '+92 51 2856789',
        role,
        password: 'password123',
        isActive: true,
        createdAt: new Date().toISOString(),
      };
      setUsers([...users, tempUser]);
      setCurrentUser(tempUser);
      StorageService.setCurrentUser(tempUser);
      showToast(`Switched role to ${role.toUpperCase()}`, 'info');
    }
  };

  // Orders
  const placeOrder = (orderData: Omit<Order, 'id' | 'orderNumber' | 'timeline' | 'createdAt'>): Order => {
    const timestamp = new Date().toISOString();
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const orderNumber = `BHP-2026-${randomSuffix}`;

    const newOrder: Order = {
      ...orderData,
      id: `ord-${Date.now()}`,
      orderNumber,
      createdAt: timestamp,
      timeline: [
        {
          status: 'Pending',
          timestamp,
          note: 'Order submitted through online checkout.',
        },
      ],
    };

    const saved = StorageService.createOrder(newOrder);
    setOrders(StorageService.getOrders());
    setProducts(StorageService.getProducts());
    clearCart();
    return saved;
  };

  const updateOrderStatus = (orderId: string, status: OrderStatus, note?: string) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return;

    const updated: Order = {
      ...order,
      orderStatus: status,
      timeline: [
        ...order.timeline,
        {
          status,
          timestamp: new Date().toISOString(),
          note: note || `Order status updated to ${status}`,
          actor: currentUser?.name,
        },
      ],
    };

    StorageService.updateOrder(updated);
    setOrders(StorageService.getOrders());
    showToast(`Order ${order.orderNumber} status changed to ${status}`, 'success');
  };

  const getOrder = (idOrNumber: string) => {
    return StorageService.getOrderById(idOrNumber);
  };

  // Prescriptions
  const uploadPrescription = (
    data: Omit<Prescription, 'id' | 'referenceNumber' | 'status' | 'uploadedAt'>
  ): Prescription => {
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const referenceNumber = `RX-2026-${randomSuffix}`;

    const newPrescription: Prescription = {
      ...data,
      id: `rx-${Date.now()}`,
      referenceNumber,
      status: 'Pending Review',
      uploadedAt: new Date().toISOString(),
    };

    const saved = StorageService.createPrescription(newPrescription);
    setPrescriptions(StorageService.getPrescriptions());
    showToast(`Prescription ${referenceNumber} submitted successfully!`, 'success');
    return saved;
  };

  const updatePrescriptionStatus = (
    prescriptionId: string,
    status: PrescriptionStatus,
    notes?: string,
    pharmacistName?: string
  ) => {
    const rx = prescriptions.find((p) => p.id === prescriptionId);
    if (!rx) return;

    const updated: Prescription = {
      ...rx,
      status,
      reviewNotes: notes,
      reviewedBy: pharmacistName || currentUser?.name || 'Licensed Pharmacist',
      reviewedAt: new Date().toISOString(),
    };

    StorageService.updatePrescription(updated);
    setPrescriptions(StorageService.getPrescriptions());
    showToast(`Prescription ${rx.referenceNumber} updated to ${status}.`, 'success');
  };

  // Delivery zones
  const updateDeliveryZones = (zones: DeliveryZone[]) => {
    StorageService.saveDeliveryZones(zones);
    setDeliveryZones(zones);
    showToast('Islamabad delivery zones updated.', 'success');
  };

  // Settings
  const updateSettings = (newSettings: PharmacySettings) => {
    StorageService.saveSettings(newSettings);
    setSettings(newSettings);
    showToast('Pharmacy settings updated.', 'success');
  };

  // Medicine Requests
  const submitMedicineRequest = (req: Omit<MedicineRequest, 'id' | 'createdAt' | 'status'>) => {
    const newReq: MedicineRequest = {
      ...req,
      id: `req-${Date.now()}`,
      status: 'Pending',
      createdAt: new Date().toISOString(),
    };
    const list = [newReq, ...medicineRequests];
    StorageService.saveMedicineRequests(list);
    setMedicineRequests(list);
    showToast('Your medicine sourcing request has been received!', 'success');
  };

  const updateMedicineRequestStatus = (id: string, status: MedicineRequest['status']) => {
    const list = medicineRequests.map((r) => (r.id === id ? { ...r, status } : r));
    StorageService.saveMedicineRequests(list);
    setMedicineRequests(list);
    showToast('Request status updated.', 'info');
  };

  // Demo Data Reset
  const resetDemoData = () => {
    StorageService.resetAllToFactoryDefaults();
    setProducts(StorageService.getProducts());
    setOrders(StorageService.getOrders());
    setPrescriptions(StorageService.getPrescriptions());
    setDeliveryZones(StorageService.getDeliveryZones());
    setSettings(StorageService.getSettings());
    const refreshedUsers = StorageService.getUsers();
    setUsers(refreshedUsers);
    setCurrentUser(refreshedUsers[0]);
    setWishlist(StorageService.getWishlist());
    setMedicineRequests(StorageService.getMedicineRequests());
    showToast('All data has been reset to factory demo values.', 'info');
  };

  return (
    <PharmacyContext.Provider
      value={{
        currentPage,
        navigateTo,
        pageParams,
        products,
        categories,
        searchQuery,
        setSearchQuery,
        selectedCategory,
        setSelectedCategory,
        selectedProduct,
        setSelectedProduct,
        addProduct,
        updateProduct,
        deleteProduct,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        cartSubtotal,
        cartItemCount,
        wishlist,
        toggleWishlist,
        isInWishlist,
        currentUser,
        login,
        logout,
        register,
        switchRole,
        changePassword,
        createSubUser,
        updateSubUser,
        deleteSubUser,
        users,
        authModalOpen,
        setAuthModalOpen,
        orders,
        placeOrder,
        updateOrderStatus,
        getOrder,
        prescriptions,
        uploadPrescription,
        updatePrescriptionStatus,
        deliveryZones,
        updateDeliveryZones,
        settings,
        updateSettings,
        medicineRequests,
        submitMedicineRequest,
        updateMedicineRequestStatus,
        toasts,
        showToast,
        removeToast,
        resetDemoData,
      }}
    >
      {children}
    </PharmacyContext.Provider>
  );
};

export const usePharmacy = () => {
  const context = useContext(PharmacyContext);
  if (!context) {
    throw new Error('usePharmacy must be used within a PharmacyProvider');
  }
  return context;
};
