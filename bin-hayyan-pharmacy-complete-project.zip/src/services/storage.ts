import {
  Product,
  Order,
  Prescription,
  DeliveryZone,
  PharmacySettings,
  User,
  MedicineRequest,
  FAQItem,
} from '../types/pharmacy';
import {
  initialProducts,
  initialOrders,
  initialPrescriptions,
  initialDeliveryZones,
  initialSettings,
  initialUsers,
  initialFAQs,
} from '../data/initialData';

const KEYS = {
  PRODUCTS: 'bhp_products_v1',
  ORDERS: 'bhp_orders_v1',
  PRESCRIPTIONS: 'bhp_prescriptions_v1',
  ZONES: 'bhp_delivery_zones_v1',
  SETTINGS: 'bhp_settings_v1',
  USERS: 'bhp_users_v1',
  CURRENT_USER: 'bhp_current_user_v1',
  WISHLIST: 'bhp_wishlist_v1',
  REQUESTS: 'bhp_medicine_requests_v1',
  FAQS: 'bhp_faqs_v1',
};

function safeGet<T>(key: string, fallback: T): T {
  try {
    const item = localStorage.getItem(key);
    if (!item) return fallback;
    return JSON.parse(item) as T;
  } catch (err) {
    console.warn(`Error reading localStorage key "${key}":`, err);
    return fallback;
  }
}

function safeSet<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.warn(`Error writing localStorage key "${key}":`, err);
  }
}

export const StorageService = {
  // Products
  getProducts(): Product[] {
    const data = safeGet<Product[]>(KEYS.PRODUCTS, []);
    if (!data || data.length === 0) {
      safeSet(KEYS.PRODUCTS, initialProducts);
      return initialProducts;
    }
    return data;
  },

  saveProducts(products: Product[]): void {
    safeSet(KEYS.PRODUCTS, products);
  },

  getProductById(id: string): Product | undefined {
    return this.getProducts().find((p) => p.id === id);
  },

  saveProduct(product: Product): void {
    const list = this.getProducts();
    const idx = list.findIndex((p) => p.id === product.id);
    if (idx >= 0) {
      list[idx] = product;
    } else {
      list.unshift(product);
    }
    this.saveProducts(list);
  },

  deleteProduct(id: string): void {
    const list = this.getProducts().filter((p) => p.id !== id);
    this.saveProducts(list);
  },

  // Orders
  getOrders(): Order[] {
    const data = safeGet<Order[]>(KEYS.ORDERS, []);
    if (!data || data.length === 0) {
      safeSet(KEYS.ORDERS, initialOrders);
      return initialOrders;
    }
    return data;
  },

  saveOrders(orders: Order[]): void {
    safeSet(KEYS.ORDERS, orders);
  },

  getOrderById(idOrNumber: string): Order | undefined {
    return this.getOrders().find(
      (o) =>
        o.id === idOrNumber ||
        o.orderNumber.toLowerCase() === idOrNumber.trim().toLowerCase()
    );
  },

  createOrder(order: Order): Order {
    const orders = this.getOrders();
    orders.unshift(order);
    this.saveOrders(orders);

    // Deduct stock for ordered products
    const products = this.getProducts();
    order.items.forEach((item) => {
      const p = products.find((prod) => prod.id === item.productId);
      if (p) {
        p.stock = Math.max(0, p.stock - item.quantity);
        p.soldCount = (p.soldCount || 0) + item.quantity;
      }
    });
    this.saveProducts(products);

    return order;
  },

  updateOrder(order: Order): void {
    const orders = this.getOrders();
    const idx = orders.findIndex((o) => o.id === order.id);
    if (idx >= 0) {
      orders[idx] = order;
      this.saveOrders(orders);
    }
  },

  // Prescriptions
  getPrescriptions(): Prescription[] {
    const data = safeGet<Prescription[]>(KEYS.PRESCRIPTIONS, []);
    if (!data || data.length === 0) {
      safeSet(KEYS.PRESCRIPTIONS, initialPrescriptions);
      return initialPrescriptions;
    }
    return data;
  },

  savePrescriptions(prescriptions: Prescription[]): void {
    safeSet(KEYS.PRESCRIPTIONS, prescriptions);
  },

  createPrescription(prescription: Prescription): Prescription {
    const list = this.getPrescriptions();
    list.unshift(prescription);
    this.savePrescriptions(list);
    return prescription;
  },

  updatePrescription(prescription: Prescription): void {
    const list = this.getPrescriptions();
    const idx = list.findIndex((p) => p.id === prescription.id);
    if (idx >= 0) {
      list[idx] = prescription;
      this.savePrescriptions(list);
    }
  },

  // Delivery Zones
  getDeliveryZones(): DeliveryZone[] {
    const data = safeGet<DeliveryZone[]>(KEYS.ZONES, []);
    if (!data || data.length === 0) {
      safeSet(KEYS.ZONES, initialDeliveryZones);
      return initialDeliveryZones;
    }
    return data;
  },

  saveDeliveryZones(zones: DeliveryZone[]): void {
    safeSet(KEYS.ZONES, zones);
  },

  // Settings
  getSettings(): PharmacySettings {
    return safeGet<PharmacySettings>(KEYS.SETTINGS, initialSettings);
  },

  saveSettings(settings: PharmacySettings): void {
    safeSet(KEYS.SETTINGS, settings);
  },

  // Users & Auth
  getUsers(): User[] {
    const data = safeGet<User[]>(KEYS.USERS, []);
    if (!data || data.length === 0) {
      safeSet(KEYS.USERS, initialUsers);
      return initialUsers;
    }
    // Ensure initial admin and staff passwords exist if migrated
    let modified = false;
    const merged = data.map((u) => {
      if (!u.password) {
        const init = initialUsers.find(
          (iu) => iu.id === u.id || iu.email.toLowerCase() === u.email.toLowerCase()
        );
        if (init && init.password) {
          modified = true;
          return {
            ...u,
            password: init.password,
            designation: u.designation || init.designation,
            isActive: u.isActive ?? true,
          };
        }
      }
      return u;
    });
    if (modified) {
      safeSet(KEYS.USERS, merged);
    }
    return merged;
  },

  saveUsers(users: User[]): void {
    safeSet(KEYS.USERS, users);
  },

  updateUser(user: User): void {
    const users = this.getUsers();
    const idx = users.findIndex((u) => u.id === user.id);
    if (idx >= 0) {
      users[idx] = user;
    } else {
      users.push(user);
    }
    this.saveUsers(users);
    const curr = this.getCurrentUser();
    if (curr && curr.id === user.id) {
      this.setCurrentUser(user);
    }
  },

  deleteUser(userId: string): void {
    const users = this.getUsers().filter((u) => u.id !== userId);
    this.saveUsers(users);
    const curr = this.getCurrentUser();
    if (curr && curr.id === userId) {
      this.setCurrentUser(null);
    }
  },

  getCurrentUser(): User | null {
    return safeGet<User | null>(KEYS.CURRENT_USER, null);
  },

  setCurrentUser(user: User | null): void {
    safeSet(KEYS.CURRENT_USER, user);
  },

  // Wishlist
  getWishlist(): string[] {
    return safeGet<string[]>(KEYS.WISHLIST, ['prod-001', 'prod-007']);
  },

  saveWishlist(ids: string[]): void {
    safeSet(KEYS.WISHLIST, ids);
  },

  // Medicine Requests
  getMedicineRequests(): MedicineRequest[] {
    return safeGet<MedicineRequest[]>(KEYS.REQUESTS, [
      {
        id: 'req-01',
        customerName: 'Muhammad Hamza',
        phone: '+92 312 9988776',
        medicineName: 'Salofalk 500mg Granules',
        quantity: '3 Boxes',
        doctorPrescribed: true,
        notes: 'Prescribed by gastro doctor in Shifa Islamabad. Currently out of stock in F-10.',
        status: 'Pending',
        createdAt: '2026-03-01T15:30:00Z',
      },
    ]);
  },

  saveMedicineRequests(reqs: MedicineRequest[]): void {
    safeSet(KEYS.REQUESTS, reqs);
  },

  // FAQs
  getFAQs(): FAQItem[] {
    const data = safeGet<FAQItem[]>(KEYS.FAQS, []);
    if (!data || data.length === 0) {
      safeSet(KEYS.FAQS, initialFAQs);
      return initialFAQs;
    }
    return data;
  },

  saveFAQs(faqs: FAQItem[]): void {
    safeSet(KEYS.FAQS, faqs);
  },

  // Reset to sample initial data
  resetAllToFactoryDefaults(): void {
    localStorage.removeItem(KEYS.PRODUCTS);
    localStorage.removeItem(KEYS.ORDERS);
    localStorage.removeItem(KEYS.PRESCRIPTIONS);
    localStorage.removeItem(KEYS.ZONES);
    localStorage.removeItem(KEYS.SETTINGS);
    localStorage.removeItem(KEYS.USERS);
    localStorage.removeItem(KEYS.CURRENT_USER);
    localStorage.removeItem(KEYS.WISHLIST);
    localStorage.removeItem(KEYS.REQUESTS);
    localStorage.removeItem(KEYS.FAQS);

    safeSet(KEYS.PRODUCTS, initialProducts);
    safeSet(KEYS.ORDERS, initialOrders);
    safeSet(KEYS.PRESCRIPTIONS, initialPrescriptions);
    safeSet(KEYS.ZONES, initialDeliveryZones);
    safeSet(KEYS.SETTINGS, initialSettings);
    safeSet(KEYS.USERS, initialUsers);
    safeSet(KEYS.FAQS, initialFAQs);
  },
};
