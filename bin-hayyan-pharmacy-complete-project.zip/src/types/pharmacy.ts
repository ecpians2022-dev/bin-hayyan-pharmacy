/**
 * Bin Hayyan Pharmacy - Data Models and Type Definitions
 * Islamabad, Pakistan
 */

export type UserRole = 'customer' | 'pharmacist' | 'admin' | 'super_admin';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  password?: string;
  designation?: string;
  isActive?: boolean;
  avatarUrl?: string;
  savedAddresses?: Address[];
  createdAt: string;
}

export interface Address {
  id: string;
  title: string; // e.g. "Home", "Office", "Clinic"
  recipientName: string;
  recipientPhone: string;
  sectorArea: string; // e.g. "F-7/2", "G-11 Markaz", "Blue Area", "Bahria Town Phase 4"
  streetAddress: string;
  city: string; // Islamabad, Rawalpindi
  postalCode?: string;
  deliveryNotes?: string;
  isDefault?: boolean;
}

export type ProductCategory =
  | 'Medicines'
  | 'Prescription Medicines'
  | 'OTC Medicines'
  | 'Vitamins & Supplements'
  | 'Pain Relief'
  | 'Cold & Flu'
  | 'Digestive Health'
  | 'Diabetes Care'
  | 'Blood Pressure Care'
  | 'Personal Care'
  | 'Skin Care'
  | 'Baby Care'
  | 'Medical Devices'
  | 'First Aid';

export interface Product {
  id: string;
  name: string; // Brand / Trade Name (e.g., "Panadol Extra 500mg/65mg")
  genericName: string; // Generic / Active Ingredient (e.g., "Paracetamol + Caffeine")
  brand: string; // e.g., "GSK", "Getz Pharma", "Abbott", "Merck"
  manufacturer: string;
  category: ProductCategory;
  subcategory?: string;
  image: string;
  additionalImages?: string[];
  description: string;
  ingredients: string;
  strength: string; // e.g., "500mg", "10mg", "250mg/5ml"
  dosageForm: string; // "Tablet", "Capsule", "Syrup", "Suspension", "Injection", "Cream", "Device"
  packSize: string; // "Pack of 20 Tablets", "120ml Bottle", "Box of 50 strips"
  price: number; // PKR
  discountPrice?: number; // PKR
  stock: number;
  lowStockThreshold: number;
  sku: string;
  barcode: string;
  requiresPrescription: boolean;
  tags: string[];
  usageInstructions: string;
  storageInfo: string;
  warnings: string;
  isFeatured?: boolean;
  isActive: boolean;
  createdAt: string;
  soldCount?: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export type OrderStatus =
  | 'Pending'
  | 'Prescription Review'
  | 'Confirmed'
  | 'Preparing'
  | 'Ready for Pickup'
  | 'Out for Delivery'
  | 'Delivered'
  | 'Cancelled'
  | 'Rejected';

export type DeliveryMethod = 'Home Delivery' | 'Pharmacy Pickup';

export type PaymentMethod =
  | 'Cash on Delivery'
  | 'Bank Transfer'
  | 'Card on Delivery'
  | 'JazzCash / Easypaisa (Manual)';

export interface OrderTimelineEvent {
  status: OrderStatus;
  timestamp: string;
  note?: string;
  actor?: string;
}

export interface OrderItem {
  productId: string;
  productName: string;
  genericName: string;
  strength: string;
  packSize: string;
  unitPrice: number;
  quantity: number;
  subtotal: number;
  requiresPrescription: boolean;
  image: string;
}

export interface Order {
  id: string;
  orderNumber: string; // e.g. "BHP-2026-00101"
  userId?: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  deliveryMethod: DeliveryMethod;
  shippingAddress: Address;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  deliveryFee: number;
  total: number;
  paymentMethod: PaymentMethod;
  paymentStatus: 'Pending' | 'Paid' | 'Cash on Hand';
  orderStatus: OrderStatus;
  prescriptionId?: string;
  prescriptionRequired: boolean;
  prescriptionStatus?: 'None' | 'Pending Review' | 'Verified' | 'Rejected';
  notes?: string;
  timeline: OrderTimelineEvent[];
  createdAt: string;
  estimatedDelivery?: string;
}

export type PrescriptionStatus =
  | 'Pending Review'
  | 'Approved'
  | 'Rejected'
  | 'Clarification Required'
  | 'Converted to Order';

export interface Prescription {
  id: string;
  referenceNumber: string; // e.g. "RX-2026-0042"
  userId?: string;
  patientName: string;
  patientPhone: string;
  patientEmail?: string;
  patientAge?: string;
  doctorName?: string;
  deliveryAddress: string;
  sectorArea: string;
  preferredDeliveryTime?: string;
  additionalNotes?: string;
  fileName: string;
  fileType: string;
  fileSize: string;
  fileUrl: string; // Data URL or storage path
  status: PrescriptionStatus;
  uploadedAt: string;
  reviewedBy?: string;
  reviewedAt?: string;
  reviewNotes?: string;
  associatedOrderId?: string;
}

export interface DeliveryZone {
  id: string;
  name: string; // e.g., "Zone 1 - Central Islamabad Sectors"
  sectors: string[]; // ["F-6", "F-7", "F-8", "F-10", "F-11", "Blue Area", "G-6", "G-7", "G-8", "G-9", "G-10", "G-11"]
  fee: number; // PKR
  estimatedTime: string; // "45 - 90 mins"
  isActive: boolean;
}

export interface PharmacySettings {
  pharmacyName: string;
  tagline: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  city: string;
  licenseNumber: string;
  openingHours: string;
  freeDeliveryThreshold: number; // e.g., 2500 PKR
  minOrderValue: number; // e.g., 300 PKR
  currency: string;
  announcementText: string;
  announcementActive: boolean;
  bankDetails: {
    bankName: string;
    accountTitle: string;
    accountNumber: string;
    iban: string;
    branch: string;
  };
  disclaimer: string;
}

export interface MedicineRequest {
  id: string;
  customerName: string;
  phone: string;
  email?: string;
  medicineName: string;
  strengthRequired?: string;
  quantity: string;
  doctorPrescribed: boolean;
  prescriptionFile?: string;
  notes?: string;
  status: 'Pending' | 'Sourced' | 'Unavailable' | 'Customer Contacted';
  createdAt: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}
