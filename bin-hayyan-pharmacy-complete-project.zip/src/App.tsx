import React, { useState } from 'react';
import { PharmacyProvider, usePharmacy } from './context/PharmacyContext';
import { Header } from './components/common/Header';
import { LeftSidebar } from './components/common/LeftSidebar';
import { Footer } from './components/common/Footer';
import { FloatingWhatsApp } from './components/common/FloatingWhatsApp';
import { Toasts } from './components/common/Toasts';

import { HomePage } from './components/pages/HomePage';
import { ShopPage } from './components/pages/ShopPage';
import { PrescriptionUploadPage } from './components/pages/PrescriptionUploadPage';
import { CartPage } from './components/pages/CartPage';
import { CheckoutPage } from './components/pages/CheckoutPage';
import { OrderConfirmationPage } from './components/pages/OrderConfirmationPage';
import { OrderTrackingPage } from './components/pages/OrderTrackingPage';
import { AccountPage } from './components/pages/AccountPage';
import { ContactPage } from './components/pages/ContactPage';
import { AboutPage } from './components/pages/AboutPage';
import { FAQsPage } from './components/pages/FAQsPage';
import { PolicyPages } from './components/pages/PolicyPages';
import { RequestMedicinePage } from './components/pages/RequestMedicinePage';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { NotFoundPage } from './components/pages/NotFoundPage';

const AppContent: React.FC = () => {
  const { currentPage } = usePharmacy();
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage />;
      case 'shop':
      case 'product-detail':
        return <ShopPage />;
      case 'prescription-upload':
        return <PrescriptionUploadPage />;
      case 'cart':
        return <CartPage />;
      case 'checkout':
        return <CheckoutPage />;
      case 'order-confirmation':
        return <OrderConfirmationPage />;
      case 'order-tracking':
        return <OrderTrackingPage />;
      case 'account':
        return <AccountPage />;
      case 'contact':
        return <ContactPage />;
      case 'about':
        return <AboutPage />;
      case 'faqs':
        return <FAQsPage />;
      case 'policies':
        return <PolicyPages />;
      case 'request-medicine':
        return <RequestMedicinePage />;
      case 'admin':
        return <AdminDashboard />;
      case '404':
      default:
        return <NotFoundPage />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col">
      {/* Permanent Left Sidebar containing All Menus & Admin Portal */}
      <LeftSidebar
        isMobileOpen={mobileSidebarOpen}
        onMobileClose={() => setMobileSidebarOpen(false)}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
      />

      {/* Main Content Area offset by Sidebar width on desktop */}
      <div
        className={`flex-1 flex flex-col transition-all duration-300 ease-in-out ${
          sidebarCollapsed ? 'lg:pl-20' : 'lg:pl-72'
        }`}
      >
        <Header onOpenMobileSidebar={() => setMobileSidebarOpen(true)} />
        <main className="flex-1">{renderPage()}</main>
        <Footer />
      </div>

      <FloatingWhatsApp />
      <Toasts />
    </div>
  );
};

export default function App() {
  return (
    <PharmacyProvider>
      <AppContent />
    </PharmacyProvider>
  );
}
