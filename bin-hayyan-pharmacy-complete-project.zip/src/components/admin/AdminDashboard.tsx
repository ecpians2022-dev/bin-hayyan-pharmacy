import React, { useState } from 'react';
import {
  TrendingUp,
  ShoppingBag,
  Clock,
  FileText,
  AlertTriangle,
  Package,
  Users,
  Settings,
  Plus,
  Edit,
  Trash2,
  CheckCircle2,
  XCircle,
  Eye,
  RefreshCw,
  Search,
  Filter,
  ShieldAlert,
  ArrowRight,
  MapPin,
  DollarSign,
  ShieldCheck,
  ChevronRight,
  Phone,
  MessageCircle,
  Printer,
  Archive,
  Check,
  CheckSquare,
  Square,
  Sparkles,
  Github,
  Download,
  UserPlus,
  Lock,
  KeyRound,
  LogIn,
  UserCheck,
  Power,
} from 'lucide-react';
import { usePharmacy } from '../../context/PharmacyContext';
import { GitHubPagesModal } from '../common/GitHubPagesModal';
import { BinHayyanLogo } from '../common/BinHayyanLogo';
import {
  Product,
  Order,
  Prescription,
  OrderStatus,
  PrescriptionStatus,
  ProductCategory,
  DeliveryZone,
  User,
  UserRole,
} from '../../types/pharmacy';

export const AdminDashboard: React.FC = () => {
  const {
    currentUser,
    switchRole,
    products,
    addProduct,
    updateProduct,
    deleteProduct,
    orders,
    updateOrderStatus,
    prescriptions,
    updatePrescriptionStatus,
    deliveryZones,
    updateDeliveryZones,
    settings,
    updateSettings,
    medicineRequests,
    updateMedicineRequestStatus,
    users,
    resetDemoData,
    showToast,
    navigateTo,
    login,
    changePassword,
    createSubUser,
    updateSubUser,
    deleteSubUser,
  } = usePharmacy();

  const [activeTab, setActiveTab] = useState<
    | 'overview'
    | 'orders'
    | 'products'
    | 'inventory'
    | 'subusers'
    | 'password'
    | 'prescriptions'
    | 'customers'
    | 'zones'
    | 'requests'
    | 'settings'
  >('orders');

  const [githubModalOpen, setGithubModalOpen] = useState(false);

  // Staff portal login form states (when not logged in)
  const [staffLoginEmail, setStaffLoginEmail] = useState('admin@binhayyanpharmacy.pk');
  const [staffLoginPassword, setStaffLoginPassword] = useState('admin123');

  // Change Password state
  const [currPasswordInput, setCurrPasswordInput] = useState('');
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [confirmPasswordInput, setConfirmPasswordInput] = useState('');

  // Sub-User creation modal state
  const [isCreatingSubUser, setIsCreatingSubUser] = useState(false);
  const [subName, setSubName] = useState('');
  const [subEmail, setSubEmail] = useState('');
  const [subPhone, setSubPhone] = useState('+92 333 ');
  const [subRole, setSubRole] = useState<UserRole>('pharmacist');
  const [subDesignation, setSubDesignation] = useState('Order Fulfillment & Dispatch Assistant');
  const [subPassword, setSubPassword] = useState('staff123');

  // Sub-user reset password state
  const [subUserToReset, setSubUserToReset] = useState<User | null>(null);
  const [resetPassInput, setResetPassInput] = useState('');

  // Search/Filters in Admin
  const [productSearch, setProductSearch] = useState('');
  const [orderSearch, setOrderSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<OrderStatus | 'All'>('All');
  const [prescriptionFilter, setPrescriptionFilter] = useState<PrescriptionStatus | 'All'>('All');

  // Order Following Drawer / Modal State
  const [selectedOrderToFollow, setSelectedOrderToFollow] = useState<Order | null>(null);
  const [checkpointNote, setCheckpointNote] = useState('');
  const [packedItems, setPackedItems] = useState<Record<string, boolean>>({});

  // Product Add / Edit Modal state
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);

  const [productForm, setProductForm] = useState<Partial<Product>>({
    name: '',
    genericName: '',
    brand: '',
    manufacturer: '',
    category: 'Medicines',
    price: 100,
    discountPrice: undefined,
    stock: 20,
    lowStockThreshold: 10,
    sku: '',
    barcode: '',
    requiresPrescription: false,
    dosageForm: 'Tablet',
    strength: '500mg',
    packSize: 'Pack of 20',
    description: '',
    usageInstructions: '',
    storageInfo: 'Store below 25°C in a dry place.',
    warnings: '',
    isFeatured: false,
    isActive: true,
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=600&q=80',
    tags: ['medicine'],
  });

  // Prescription Review Modal
  const [reviewingPrescription, setReviewingPrescription] = useState<Prescription | null>(null);
  const [pharmacistNotes, setPharmacistNotes] = useState('');

  // Settings Edit State
  const [localSettings, setLocalSettings] = useState(settings);

  // Preset Pakistani medicines for quick-add
  const medicinePresets = [
    {
      label: 'Augmentin 625mg (Antibiotic)',
      name: 'Augmentin 625mg Tablets',
      genericName: 'Co-Amoxiclav (Amoxicillin + Clavulanic Acid)',
      brand: 'Augmentin',
      manufacturer: 'GSK Pakistan',
      category: 'Prescription Medicines' as ProductCategory,
      dosageForm: 'Tablet',
      strength: '625mg',
      packSize: 'Pack of 14 Tablets',
      price: 385,
      stock: 45,
      requiresPrescription: true,
      image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?auto=format&fit=crop&w=600&q=80',
      description: 'Broad-spectrum antibacterial medication for respiratory and ENT infections.',
      usageInstructions: '1 tablet twice daily with meals or as prescribed.',
      storageInfo: 'Store below 25°C in moisture-free blister.',
      warnings: 'Prescription Only (Rx). Complete full course.',
    },
    {
      label: 'Panadol Extra (Painkiller)',
      name: 'Panadol Extra Tablets 500mg/65mg',
      genericName: 'Paracetamol + Caffeine',
      brand: 'Panadol',
      manufacturer: 'GSK Pakistan',
      category: 'Pain Relief' as ProductCategory,
      dosageForm: 'Film-coated Tablet',
      strength: '500mg / 65mg',
      packSize: 'Pack of 100 Tablets',
      price: 360,
      discountPrice: 340,
      stock: 90,
      requiresPrescription: false,
      image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=600&q=80',
      description: 'Fast relief from tough headaches, toothaches, muscular pain, and fever.',
      usageInstructions: '1-2 tablets every 4-6 hours. Max 8 tablets in 24 hours.',
      storageInfo: 'Store below 30°C.',
      warnings: 'Do not exceed stated dose.',
    },
    {
      label: 'Risek 40mg (Stomach / Acid)',
      name: 'Risek 40mg Capsules',
      genericName: 'Omeprazole',
      brand: 'Risek',
      manufacturer: 'Getz Pharma Pakistan',
      category: 'Digestive Health' as ProductCategory,
      dosageForm: 'Capsule',
      strength: '40mg',
      packSize: 'Pack of 14 Capsules',
      price: 520,
      discountPrice: 495,
      stock: 60,
      requiresPrescription: true,
      image: 'https://images.unsplash.com/photo-1550572017-ed200f5e6343?auto=format&fit=crop&w=600&q=80',
      description: 'Proton pump inhibitor reducing stomach acid secretion for ulcers and GERD.',
      usageInstructions: 'Take once daily before breakfast.',
      storageInfo: 'Store below 30°C in moisture-protected Alu-Alu pack.',
      warnings: 'Prescription only.',
    },
    {
      label: 'Ventolin Inhaler (Asthma)',
      name: 'Ventolin Evohaler Inhaler 100mcg',
      genericName: 'Salbutamol',
      brand: 'Ventolin',
      manufacturer: 'GSK Pakistan',
      category: 'Prescription Medicines' as ProductCategory,
      dosageForm: 'Inhalation Aerosol',
      strength: '100mcg per puff',
      packSize: '200 Actuations Canister',
      price: 460,
      stock: 35,
      requiresPrescription: true,
      image: 'https://images.unsplash.com/photo-1550572017-ed200f5e6343?auto=format&fit=crop&w=600&q=80',
      description: 'Fast-acting bronchodilator for immediate relief of asthma bronchospasm.',
      usageInstructions: 'Inhale 1-2 puffs as needed for shortness of breath.',
      storageInfo: 'Store below 30°C away from frost.',
      warnings: 'Prescription only.',
    },
    {
      label: 'Surbex Z (Multivitamins)',
      name: 'Surbex Z High Potency B-Complex with Zinc',
      genericName: 'Multivitamins + Zinc + Vitamin C',
      brand: 'Surbex',
      manufacturer: 'Abbott Laboratories Pakistan',
      category: 'Vitamins & Supplements' as ProductCategory,
      dosageForm: 'Film-coated Tablet',
      strength: 'Standard Formula',
      packSize: 'Pack of 30 Tablets',
      price: 495,
      discountPrice: 470,
      stock: 75,
      requiresPrescription: false,
      image: 'https://images.unsplash.com/photo-1577401239170-897942555fb3?auto=format&fit=crop&w=600&q=80',
      description: 'Daily nutritional support for immunity, recovery, and cellular energy.',
      usageInstructions: '1 tablet daily after meal.',
      storageInfo: 'Store below 30°C.',
      warnings: 'Dietary supplement.',
    },
    {
      label: 'Accu-Chek Glucometer Kit',
      name: 'Accu-Chek Instant Blood Glucose Monitoring System',
      genericName: 'Blood Glucose Meter Kit',
      brand: 'Accu-Chek',
      manufacturer: 'Roche Diabetes Care',
      category: 'Medical Devices' as ProductCategory,
      dosageForm: 'Diagnostic Device',
      strength: 'Instant Meter Kit',
      packSize: '1 Meter + 10 Strips + Device',
      price: 2850,
      discountPrice: 2650,
      stock: 20,
      requiresPrescription: false,
      image: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&w=600&q=80',
      description: 'Fast, clinically validated self-monitoring blood glucose device.',
      usageInstructions: 'Apply small blood droplet to test strip.',
      storageInfo: 'Store between 4°C - 30°C.',
      warnings: 'In-vitro diagnostic use.',
    },
  ];

  const presetImages = [
    { label: 'Blister Tablets', url: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=600&q=80' },
    { label: 'Capsules / Pills', url: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?auto=format&fit=crop&w=600&q=80' },
    { label: 'Syrup / Liquid Bottle', url: 'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?auto=format&fit=crop&w=600&q=80' },
    { label: 'Vitamins & Zinc', url: 'https://images.unsplash.com/photo-1577401239170-897942555fb3?auto=format&fit=crop&w=600&q=80' },
    { label: 'Diagnostic Device / Monitor', url: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&w=600&q=80' },
    { label: 'Baby / Pediatric Care', url: 'https://images.unsplash.com/photo-1555252333-9f8e92e65df9?auto=format&fit=crop&w=600&q=80' },
  ];

  // Security check: Only staff (admin, pharmacist, super_admin) can access
  const isAuthorized =
    currentUser &&
    (currentUser.role === 'admin' ||
      currentUser.role === 'pharmacist' ||
      currentUser.role === 'super_admin');

  const handleStaffLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffLoginEmail.trim()) {
      showToast('Please enter your staff email.', 'error');
      return;
    }
    const success = login(staffLoginEmail, staffLoginPassword, 'admin');
    if (!success) {
      showToast('Invalid email or password. Please verify credentials.', 'error');
    }
  };

  if (!isAuthorized) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 space-y-6">
        <div className="text-center space-y-3">
          <div className="flex justify-center">
            <div className="bg-white p-3 rounded-3xl shadow-lg border border-slate-200">
              <BinHayyanLogo size="lg" />
            </div>
          </div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight">
            Dispensary Staff & Admin Portal
          </h2>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Authorized pharmacy staff and sub-user portal for medicine catalog, inventory control, and order fulfillment in Islamabad.
          </p>
        </div>

        {/* Credentials Info Callout */}
        <div className="p-3.5 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs text-emerald-950 space-y-1">
          <div className="flex items-center gap-1.5 font-extrabold text-emerald-900">
            <Lock className="w-3.5 h-3.5 text-emerald-700" />
            <span>Authorized Pharmacy Credentials:</span>
          </div>
          <div className="font-mono text-[11px] text-emerald-800 space-y-0.5 pt-0.5">
            <p><strong>Lead Admin:</strong> admin@binhayyanpharmacy.pk (admin123)</p>
            <p><strong>Dispensary Staff:</strong> pharmacist@binhayyanpharmacy.pk (pharmacist123)</p>
            <div className="flex items-center justify-between pt-1">
              <button
                type="button"
                onClick={() => {
                  setStaffLoginEmail('admin@binhayyanpharmacy.pk');
                  setStaffLoginPassword('admin123');
                  showToast('Admin credentials filled into fields', 'info');
                }}
                className="text-[11px] font-bold text-emerald-700 hover:text-emerald-900 underline flex items-center gap-1"
              >
                Auto-fill Lead Admin (admin123)
              </button>
              <button
                type="button"
                onClick={() => {
                  setStaffLoginEmail('pharmacist@binhayyanpharmacy.pk');
                  setStaffLoginPassword('pharmacist123');
                  showToast('Pharmacist credentials filled into fields', 'info');
                }}
                className="text-[11px] font-bold text-emerald-700 hover:text-emerald-900 underline flex items-center gap-1"
              >
                Auto-fill Pharmacist
              </button>
            </div>
          </div>
        </div>

        {/* Staff Login Form */}
        <form onSubmit={handleStaffLoginSubmit} className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xl space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 mb-1">Staff Email Address</label>
            <input
              type="email"
              required
              value={staffLoginEmail}
              onChange={(e) => setStaffLoginEmail(e.target.value)}
              placeholder="admin@binhayyanpharmacy.pk"
              className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-semibold focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Staff Password</label>
            <input
              type="password"
              required
              value={staffLoginPassword}
              onChange={(e) => setStaffLoginPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-semibold focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5"
          >
            <LogIn className="w-4 h-4" />
            <span>Sign In to Admin Panel</span>
          </button>

          {/* Quick Demo Access Buttons */}
          <div className="pt-3 border-t border-slate-100 space-y-2">
            <span className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider text-center">
              Quick 1-Click Evaluation Login
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  switchRole('admin');
                  showToast('Logged in as Dr. Shahzad Bin Hayyan (Lead Admin)', 'success');
                }}
                className="py-2 px-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-[11px] rounded-xl text-center transition-colors"
              >
                Lead Admin
              </button>
              <button
                type="button"
                onClick={() => {
                  switchRole('pharmacist');
                  showToast('Logged in as Ayesha Siddiqui (Dispensary Pharmacist)', 'success');
                }}
                className="py-2 px-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-[11px] rounded-xl text-center transition-colors"
              >
                Dispensary Staff
              </button>
            </div>
          </div>
        </form>

        <div className="text-center">
          <button
            onClick={() => navigateTo('home')}
            className="text-slate-500 hover:text-emerald-700 text-xs font-semibold hover:underline"
          >
            ← Return to Customer Storefront
          </button>
        </div>
      </div>
    );
  }

  // Calculated Stats
  const totalSalesPKR = orders.reduce((sum, o) => sum + o.total, 0);
  const totalOrdersCount = orders.length;
  const pendingOrdersCount = orders.filter(
    (o) => o.orderStatus === 'Pending' || o.orderStatus === 'Prescription Review'
  ).length;
  const pendingPrescriptionsCount = prescriptions.filter((p) => p.status === 'Pending Review').length;
  const lowStockCount = products.filter((p) => p.stock > 0 && p.stock <= p.lowStockThreshold).length;
  const outOfStockCount = products.filter((p) => p.stock <= 0).length;

  const handleOpenAddProduct = () => {
    setProductForm({
      name: '',
      genericName: '',
      brand: '',
      manufacturer: '',
      category: 'Medicines',
      price: 150,
      stock: 30,
      lowStockThreshold: 10,
      sku: `BHP-${Math.floor(1000 + Math.random() * 9000)}`,
      barcode: `8964000${Math.floor(100000 + Math.random() * 900000)}`,
      requiresPrescription: false,
      dosageForm: 'Tablet',
      strength: '10mg',
      packSize: 'Pack of 30 Tablets',
      description: 'Manufactured and sealed in compliance with DRAP standards.',
      usageInstructions: 'As directed by a registered medical physician.',
      storageInfo: 'Store below 25°C away from heat and direct sunlight.',
      warnings: 'Keep out of reach of children.',
      isFeatured: false,
      isActive: true,
      image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=600&q=80',
      tags: ['medicine'],
    });
    setEditingProduct(null);
    setIsAddingProduct(true);
  };

  const handleApplyPreset = (preset: (typeof medicinePresets)[0]) => {
    setProductForm({
      ...productForm,
      name: preset.name,
      genericName: preset.genericName,
      brand: preset.brand,
      manufacturer: preset.manufacturer,
      category: preset.category,
      dosageForm: preset.dosageForm,
      strength: preset.strength,
      packSize: preset.packSize,
      price: preset.price,
      discountPrice: (preset as any).discountPrice,
      stock: preset.stock,
      requiresPrescription: preset.requiresPrescription,
      image: preset.image,
      description: preset.description,
      usageInstructions: preset.usageInstructions,
      storageInfo: preset.storageInfo,
      warnings: preset.warnings,
      sku: `BHP-${preset.brand.slice(0, 3).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`,
    });
    showToast(`Preset "${preset.name}" applied!`, 'info');
  };

  const handleOpenEditProduct = (prod: Product) => {
    setEditingProduct(prod);
    setProductForm({ ...prod });
    setIsAddingProduct(true);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!productForm.name || !productForm.genericName) {
      showToast('Product name and Generic salt are required.', 'error');
      return;
    }

    if (editingProduct) {
      const updated: Product = {
        ...editingProduct,
        ...(productForm as Product),
      };
      updateProduct(updated);
    } else {
      const newProd: Product = {
        id: `prod-${Date.now()}`,
        name: productForm.name || 'Unnamed Medicine',
        genericName: productForm.genericName || 'Active Formula',
        brand: productForm.brand || 'Generic',
        manufacturer: productForm.manufacturer || 'Licensed Manufacturer',
        category: (productForm.category as ProductCategory) || 'Medicines',
        image: productForm.image || 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=600&q=80',
        description: productForm.description || '',
        ingredients: productForm.ingredients || productForm.genericName || '',
        strength: productForm.strength || 'Standard',
        dosageForm: productForm.dosageForm || 'Tablet',
        packSize: productForm.packSize || 'Pack of 20',
        price: Number(productForm.price) || 100,
        discountPrice: productForm.discountPrice ? Number(productForm.discountPrice) : undefined,
        stock: Number(productForm.stock) || 0,
        lowStockThreshold: Number(productForm.lowStockThreshold) || 5,
        sku: productForm.sku || `SKU-${Date.now()}`,
        barcode: productForm.barcode || `${Date.now()}`,
        requiresPrescription: Boolean(productForm.requiresPrescription),
        tags: productForm.tags || ['medicine'],
        usageInstructions: productForm.usageInstructions || 'As directed by physician.',
        storageInfo: productForm.storageInfo || 'Store below 25°C.',
        warnings: productForm.warnings || '',
        isFeatured: Boolean(productForm.isFeatured),
        isActive: Boolean(productForm.isActive),
        createdAt: new Date().toISOString(),
        soldCount: 0,
      };
      addProduct(newProd);
    }

    setIsAddingProduct(false);
    setEditingProduct(null);
  };

  const handleConfirmDeleteProduct = (permanent: boolean) => {
    if (!productToDelete) return;
    if (permanent) {
      deleteProduct(productToDelete.id);
      showToast(`Medicine "${productToDelete.name}" permanently deleted.`, 'info');
    } else {
      updateProduct({ ...productToDelete, isActive: false });
      showToast(`Medicine "${productToDelete.name}" archived (marked inactive).`, 'info');
    }
    setProductToDelete(null);
  };

  // Order following actions
  const handleFollowOrder = (ord: Order) => {
    setSelectedOrderToFollow(ord);
    setCheckpointNote('');
    setPackedItems({});
  };

  const handleUpdateFollowedOrderStatus = (status: OrderStatus, noteText?: string) => {
    if (!selectedOrderToFollow) return;
    updateOrderStatus(selectedOrderToFollow.id, status, noteText);

    // Refresh selected order state
    const refreshed = orders.find((o) => o.id === selectedOrderToFollow.id);
    if (refreshed) {
      setSelectedOrderToFollow({
        ...refreshed,
        orderStatus: status,
      });
    }
  };

  const handleAddCheckpointLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOrderToFollow || !checkpointNote.trim()) return;

    handleUpdateFollowedOrderStatus(
      selectedOrderToFollow.orderStatus,
      `Checkpoint: ${checkpointNote.trim()}`
    );
    setCheckpointNote('');
    showToast('Checkpoint note logged to order timeline.', 'success');
  };

  const handlePrescriptionReview = (status: PrescriptionStatus) => {
    if (!reviewingPrescription) return;

    updatePrescriptionStatus(
      reviewingPrescription.id,
      status,
      pharmacistNotes,
      currentUser.name
    );

    setReviewingPrescription(null);
    setPharmacistNotes('');
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings(localSettings);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Admin Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
            <span className="text-xs uppercase font-extrabold tracking-widest text-emerald-400">
              Islamabad Pharmacy Operations Portal
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white mt-1">
            Bin Hayyan Staff Management Desk
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Logged in as <strong>{currentUser?.name}</strong> • Role: <strong className="text-emerald-400 uppercase">{currentUser?.role}</strong>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => handleOpenAddProduct()}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs px-4 py-2.5 rounded-xl shadow-md flex items-center gap-1.5 transition-all"
          >
            <Plus className="w-4 h-4" /> Add Medicine
          </button>
          <button
            onClick={() => setGithubModalOpen(true)}
            className="bg-slate-800 hover:bg-slate-700 text-emerald-300 hover:text-white font-bold text-xs px-3.5 py-2.5 rounded-xl border border-slate-700 flex items-center gap-1.5 transition-colors shadow-sm"
            title="Download complete project ZIP archive for GitHub Pages"
          >
            <Github className="w-4 h-4 text-emerald-400" />
            <span>Download for GitHub Pages</span>
            <Download className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => resetDemoData()}
            className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold px-3 py-2 rounded-xl flex items-center gap-1.5 transition-colors border border-slate-700"
            title="Reset to factory sample data"
          >
            <RefreshCw className="w-3.5 h-3.5 text-amber-400" /> Reset Demo
          </button>
          <button
            onClick={() => navigateTo('home')}
            className="text-xs bg-white text-slate-900 hover:bg-slate-100 font-bold px-3.5 py-2 rounded-xl transition-colors"
          >
            Customer Storefront →
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200 text-xs font-bold">
        {[
          { id: 'orders', label: `Follow & Dispatch Orders (${orders.length})`, icon: ShoppingBag, alert: pendingOrdersCount > 0 },
          { id: 'products', label: `Manage Medicines (${products.length})`, icon: Package },
          { id: 'inventory', label: `Stock Alerts (${lowStockCount + outOfStockCount})`, icon: AlertTriangle, alert: lowStockCount + outOfStockCount > 0 },
          { id: 'prescriptions', label: `Prescription Slips (${pendingPrescriptionsCount})`, icon: FileText, alert: pendingPrescriptionsCount > 0 },
          { id: 'overview', label: 'Overview & Sales', icon: TrendingUp },
          { id: 'requests', label: `Sourcing Requests (${medicineRequests.length})`, icon: RefreshCw },
          { id: 'customers', label: `Customer Records (${users.length})`, icon: Users },
          { id: 'subusers', label: 'Create Sub-Users & Staff', icon: UserPlus },
          { id: 'password', label: 'Change Admin Password', icon: KeyRound },
          { id: 'zones', label: 'Islamabad Delivery Zones', icon: MapPin },
          { id: 'settings', label: 'Dispensary Settings', icon: Settings },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-xl whitespace-nowrap flex items-center gap-2 transition-all ${
                isActive
                  ? 'bg-emerald-700 text-white shadow-md'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.alert && (
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB 1: Follow & Dispatch Orders */}
      {activeTab === 'orders' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-emerald-600" />
                <span>Follow & Manage Customer Orders</span>
              </h2>
              <p className="text-xs text-slate-500">
                Track each Islamabad delivery step-by-step: verification, dispensing, rider dispatch, and cash collection
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search Order ID, phone, customer..."
                  value={orderSearch}
                  onChange={(e) => setOrderSearch(e.target.value)}
                  className="bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-800"
                />
              </div>

              <select
                value={orderStatusFilter}
                onChange={(e) => setOrderStatusFilter(e.target.value as any)}
                className="bg-slate-50 border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 font-semibold"
              >
                <option value="All">All Statuses ({orders.length})</option>
                <option value="Pending">Pending</option>
                <option value="Prescription Review">Prescription Review</option>
                <option value="Confirmed">Confirmed</option>
                <option value="Preparing">Preparing</option>
                <option value="Out for Delivery">Out for Delivery</option>
                <option value="Delivered">Delivered</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-y border-slate-200">
                <tr>
                  <th className="py-3 px-4">Order ID & Date</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Sector (Islamabad)</th>
                  <th className="py-3 px-4">Items</th>
                  <th className="py-3 px-4">Amount & Payment</th>
                  <th className="py-3 px-4">Current Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {orders
                  .filter((o) => {
                    if (orderStatusFilter !== 'All' && o.orderStatus !== orderStatusFilter) return false;
                    if (!orderSearch) return true;
                    const q = orderSearch.toLowerCase();
                    return (
                      o.orderNumber.toLowerCase().includes(q) ||
                      o.customerPhone.includes(q) ||
                      o.customerName.toLowerCase().includes(q) ||
                      o.shippingAddress.sectorArea.toLowerCase().includes(q)
                    );
                  })
                  .map((ord) => (
                    <tr key={ord.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4">
                        <strong className="text-slate-900 block font-black">{ord.orderNumber}</strong>
                        <span className="block text-[10px] text-slate-400">
                          {new Date(ord.createdAt).toLocaleDateString()} at{' '}
                          {new Date(ord.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <strong className="text-slate-800 block">{ord.customerName}</strong>
                        <a
                          href={`tel:${ord.customerPhone}`}
                          className="text-emerald-700 hover:underline text-[11px] font-semibold"
                        >
                          {ord.customerPhone}
                        </a>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-bold text-emerald-900 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          Sector {ord.shippingAddress.sectorArea}
                        </span>
                        <p className="text-[11px] text-slate-500 truncate max-w-xs mt-0.5">
                          {ord.shippingAddress.streetAddress}
                        </p>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-bold text-slate-800">{ord.items.length} items</span>
                        <p className="text-[10px] text-slate-400 truncate max-w-[140px]">
                          {ord.items.map((i) => i.productName).join(', ')}
                        </p>
                      </td>
                      <td className="py-3 px-4">
                        <strong className="text-slate-900 block font-black text-sm">PKR {ord.total}</strong>
                        <span className="text-[11px] text-slate-500">{ord.paymentMethod}</span>
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                            ord.orderStatus === 'Delivered'
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                              : ord.orderStatus === 'Out for Delivery'
                              ? 'bg-blue-100 text-blue-800 border border-blue-300'
                              : ord.orderStatus === 'Preparing'
                              ? 'bg-purple-100 text-purple-800 border border-purple-300'
                              : ord.orderStatus === 'Confirmed'
                              ? 'bg-teal-100 text-teal-800 border border-teal-300'
                              : 'bg-amber-100 text-amber-800 border border-amber-300'
                          }`}
                        >
                          {ord.orderStatus}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => handleFollowOrder(ord)}
                          className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-3 py-1.5 rounded-xl shadow-sm text-xs inline-flex items-center gap-1.5 transition-transform hover:scale-105 active:scale-95"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Follow Order</span>
                        </button>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Follow Order Drawer / Modal */}
      {selectedOrderToFollow && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-3xl w-full max-h-[92vh] overflow-y-auto space-y-6 shadow-2xl border border-slate-200">
            {/* Modal Header */}
            <div className="flex items-start justify-between border-b border-slate-100 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs uppercase font-extrabold tracking-wider bg-emerald-100 text-emerald-800 px-2.5 py-0.5 rounded-md">
                    Order Reference: {selectedOrderToFollow.orderNumber}
                  </span>
                  <span className="text-xs font-bold text-slate-500">
                    Placed on {new Date(selectedOrderToFollow.createdAt).toLocaleDateString()}
                  </span>
                </div>
                <h3 className="text-xl font-black text-slate-900 mt-1">
                  Order Dispatch & Tracking Inspector
                </h3>
              </div>
              <button
                onClick={() => setSelectedOrderToFollow(null)}
                className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700"
              >
                ✕
              </button>
            </div>

            {/* Quick Status Advancement Buttons */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
              <span className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                Follow / Advance Order Status:
              </span>
              <div className="flex flex-wrap gap-2 text-xs">
                {selectedOrderToFollow.orderStatus === 'Pending' && (
                  <button
                    onClick={() => handleUpdateFollowedOrderStatus('Confirmed', 'Order confirmed by dispensary pharmacist')}
                    className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-4 py-2 rounded-xl flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" /> 1. Confirm Order
                  </button>
                )}

                {selectedOrderToFollow.orderStatus === 'Prescription Review' && (
                  <button
                    onClick={() => handleUpdateFollowedOrderStatus('Confirmed', 'Doctor prescription verified; order confirmed')}
                    className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-4 py-2 rounded-xl flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" /> Approve Prescription & Confirm
                  </button>
                )}

                {selectedOrderToFollow.orderStatus === 'Confirmed' && (
                  <button
                    onClick={() => handleUpdateFollowedOrderStatus('Preparing', 'Medicines dispensed from shelf and sealed')}
                    className="bg-purple-700 hover:bg-purple-800 text-white font-bold px-4 py-2 rounded-xl flex items-center gap-1.5"
                  >
                    <Package className="w-4 h-4" /> 2. Start Dispensing & Packaging
                  </button>
                )}

                {selectedOrderToFollow.orderStatus === 'Preparing' && (
                  <>
                    <button
                      onClick={() => handleUpdateFollowedOrderStatus('Out for Delivery', 'Rider dispatched with parcel')}
                      className="bg-blue-700 hover:bg-blue-800 text-white font-bold px-4 py-2 rounded-xl flex items-center gap-1.5"
                    >
                      <ShoppingBag className="w-4 h-4" /> 3. Dispatch to Islamabad Rider
                    </button>
                    <button
                      onClick={() => handleUpdateFollowedOrderStatus('Ready for Pickup', 'Parcel placed on pickup counter')}
                      className="bg-amber-700 hover:bg-amber-800 text-white font-bold px-4 py-2 rounded-xl flex items-center gap-1.5"
                    >
                      Ready for Store Pickup
                    </button>
                  </>
                )}

                {(selectedOrderToFollow.orderStatus === 'Out for Delivery' || selectedOrderToFollow.orderStatus === 'Ready for Pickup') && (
                  <button
                    onClick={() => handleUpdateFollowedOrderStatus('Delivered', 'Delivered safely to recipient and payment collected')}
                    className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-4 py-2 rounded-xl flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" /> 4. Mark Delivered & Cash Collected (PKR {selectedOrderToFollow.total})
                  </button>
                )}

                {/* Dropdown for any custom jump */}
                <div className="flex items-center gap-1 ml-auto">
                  <span className="text-slate-500 text-[11px]">Set manually:</span>
                  <select
                    value={selectedOrderToFollow.orderStatus}
                    onChange={(e) => handleUpdateFollowedOrderStatus(e.target.value as OrderStatus)}
                    className="bg-white border border-slate-300 rounded-lg p-1.5 text-xs font-bold text-slate-800"
                  >
                    <option value="Pending">Pending</option>
                    <option value="Prescription Review">Prescription Review</option>
                    <option value="Confirmed">Confirmed</option>
                    <option value="Preparing">Preparing</option>
                    <option value="Ready for Pickup">Ready for Pickup</option>
                    <option value="Out for Delivery">Out for Delivery</option>
                    <option value="Delivered">Delivered</option>
                    <option value="Cancelled">Cancelled</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Customer & Delivery Dossier */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs bg-emerald-50/50 p-4 rounded-2xl border border-emerald-200">
              <div className="space-y-1">
                <span className="text-emerald-800 font-bold uppercase tracking-wider text-[10px]">Customer Details</span>
                <p className="font-bold text-slate-900 text-sm">{selectedOrderToFollow.customerName}</p>
                <p className="text-slate-600 font-semibold">{selectedOrderToFollow.customerPhone}</p>
                {selectedOrderToFollow.customerEmail && (
                  <p className="text-slate-500">{selectedOrderToFollow.customerEmail}</p>
                )}

                <div className="flex gap-2 pt-2">
                  <a
                    href={`tel:${selectedOrderToFollow.customerPhone}`}
                    className="bg-white border border-slate-200 hover:bg-slate-50 text-slate-800 px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 shadow-sm"
                  >
                    <Phone className="w-3.5 h-3.5 text-emerald-600" /> Call
                  </a>
                  <a
                    href={`https://wa.me/${selectedOrderToFollow.customerPhone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                      `Salam ${selectedOrderToFollow.customerName}, this is Bin Hayyan Pharmacy regarding your order ${selectedOrderToFollow.orderNumber} for Sector ${selectedOrderToFollow.shippingAddress.sectorArea}, Islamabad. Your order status is: ${selectedOrderToFollow.orderStatus}.`
                    )}`}
                    target="_blank"
                    rel="noreferrer"
                    className="bg-emerald-600 hover:bg-emerald-700 text-white px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 shadow-sm"
                  >
                    <MessageCircle className="w-3.5 h-3.5" /> WhatsApp Customer
                  </a>
                </div>
              </div>

              <div className="space-y-1">
                <span className="text-emerald-800 font-bold uppercase tracking-wider text-[10px]">Islamabad Destination</span>
                <p className="font-bold text-slate-900">
                  Sector {selectedOrderToFollow.shippingAddress.sectorArea}, Islamabad
                </p>
                <p className="text-slate-600">{selectedOrderToFollow.shippingAddress.streetAddress}</p>
                {selectedOrderToFollow.shippingAddress.deliveryNotes && (
                  <p className="text-emerald-800 italic mt-1 font-medium">
                    Note: {selectedOrderToFollow.shippingAddress.deliveryNotes}
                  </p>
                )}
                <p className="text-slate-500 pt-1">
                  Payment: <strong>{selectedOrderToFollow.paymentMethod}</strong> (Total: PKR {selectedOrderToFollow.total})
                </p>
              </div>
            </div>

            {/* Medicine Packing Checklist */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider">
                  Medicine Packing & Verification Checklist ({selectedOrderToFollow.items.length} items)
                </h4>
                <span className="text-[11px] text-slate-400">Tick items as they are sealed</span>
              </div>

              <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl p-2 text-xs">
                {selectedOrderToFollow.items.map((item, idx) => {
                  const isChecked = Boolean(packedItems[item.productId]);

                  return (
                    <div
                      key={idx}
                      onClick={() => setPackedItems({ ...packedItems, [item.productId]: !isChecked })}
                      className="py-2.5 px-2 flex items-center justify-between hover:bg-slate-50 rounded-lg cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        {isChecked ? (
                          <CheckSquare className="w-5 h-5 text-emerald-600" />
                        ) : (
                          <Square className="w-5 h-5 text-slate-400" />
                        )}
                        <img src={item.image} alt={item.productName} className="w-9 h-9 rounded object-cover" />
                        <div>
                          <strong className={`block ${isChecked ? 'line-through text-slate-400' : 'text-slate-900'}`}>
                            {item.productName}
                          </strong>
                          <span className="text-[11px] text-slate-500">
                            Salt: {item.genericName} • {item.packSize}
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="font-black text-slate-900">Qty: {item.quantity}</span>
                        <span className="block text-[11px] text-slate-500">PKR {item.subtotal}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Add Custom Rider / Dispatch Checkpoint Form */}
            <form onSubmit={handleAddCheckpointLog} className="space-y-2 pt-2 border-t border-slate-100 text-xs">
              <label className="block font-bold text-slate-800">
                Log Rider / Dispatch Update (Appears in Customer Live Tracking):
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={checkpointNote}
                  onChange={(e) => setCheckpointNote(e.target.value)}
                  placeholder="e.g. Rider Irfan on bike ICT-892 dispatched to Sector F-10. Calling customer on arrival..."
                  className="flex-1 bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-800"
                />
                <button
                  type="submit"
                  className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-4 py-2.5 rounded-xl text-xs shrink-0"
                >
                  Log Update
                </button>
              </div>
            </form>

            {/* Timeline Audit Events */}
            <div className="space-y-2">
              <h4 className="font-bold text-slate-900 text-xs">Timeline History:</h4>
              <div className="bg-slate-50 rounded-2xl p-3 divide-y divide-slate-100 text-xs space-y-2 max-h-40 overflow-y-auto">
                {selectedOrderToFollow.timeline.map((ev, i) => (
                  <div key={i} className="pt-2 first:pt-0 flex items-start justify-between">
                    <div>
                      <strong className="text-emerald-900 font-semibold">{ev.status}: </strong>
                      <span className="text-slate-600">{ev.note}</span>
                      {ev.actor && <span className="block text-[10px] text-slate-400">By {ev.actor}</span>}
                    </div>
                    <span className="text-[10px] text-slate-400 shrink-0">
                      {new Date(ev.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Footer Buttons */}
            <div className="flex justify-between items-center pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => window.print()}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" /> Print Packing Slip
              </button>

              <button
                type="button"
                onClick={() => setSelectedOrderToFollow(null)}
                className="bg-slate-900 text-white font-bold px-5 py-2 rounded-xl text-xs"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Manage Medicines (Add, Edit, Remove) */}
      {activeTab === 'products' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                <Package className="w-5 h-5 text-emerald-600" />
                <span>Medicine Catalog Management</span>
              </h2>
              <p className="text-xs text-slate-500">
                Add new medicines with realistic presets, remove or archive discontinued drugs, and update Pakistani prices (PKR)
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search medicines, salt, SKU..."
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  className="bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-800"
                />
              </div>

              <button
                onClick={handleOpenAddProduct}
                className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 shadow-md"
              >
                <Plus className="w-4 h-4" /> Add New Medicine
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-y border-slate-200">
                <tr>
                  <th className="py-3 px-4">Medicine / Active Salt</th>
                  <th className="py-3 px-4">Brand / Manufacturer</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Price (PKR)</th>
                  <th className="py-3 px-4">Stock Level</th>
                  <th className="py-3 px-4">Rx Flag</th>
                  <th className="py-3 px-4 text-right">Actions (Edit / Remove)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {products
                  .filter(
                    (p) =>
                      !productSearch ||
                      p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
                      p.genericName.toLowerCase().includes(productSearch.toLowerCase()) ||
                      p.brand.toLowerCase().includes(productSearch.toLowerCase()) ||
                      p.sku.toLowerCase().includes(productSearch.toLowerCase())
                  )
                  .map((prod) => (
                    <tr key={prod.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2.5">
                          <img src={prod.image} alt={prod.name} className="w-10 h-10 rounded-lg object-cover" />
                          <div>
                            <strong className="text-slate-900 block text-xs font-bold">{prod.name}</strong>
                            <span className="text-[10px] text-slate-500">
                              Salt: <strong>{prod.genericName}</strong> • {prod.strength}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <strong className="text-slate-800 block">{prod.brand}</strong>
                        <span className="text-[10px] text-slate-400">{prod.manufacturer}</span>
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-700">{prod.category}</td>
                      <td className="py-3 px-4">
                        <span className="font-extrabold text-slate-900 text-xs">
                          PKR {prod.discountPrice ?? prod.price}
                        </span>
                        {prod.discountPrice && (
                          <span className="text-[10px] text-slate-400 line-through block">
                            PKR {prod.price}
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <div className="space-y-1">
                          <span
                            className={`font-black text-xs ${
                              prod.stock <= 0
                                ? 'text-rose-600'
                                : prod.stock <= prod.lowStockThreshold
                                ? 'text-amber-600'
                                : 'text-emerald-700'
                            }`}
                          >
                            {prod.stock} units
                          </span>
                          {/* Quick Stock steppers */}
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => updateProduct({ ...prod, stock: Math.max(0, prod.stock - 5) })}
                              className="px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded text-[10px]"
                              title="Decrease 5"
                            >
                              -5
                            </button>
                            <button
                              onClick={() => updateProduct({ ...prod, stock: prod.stock + 10 })}
                              className="px-1.5 py-0.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold rounded text-[10px]"
                              title="Add 10"
                            >
                              +10
                            </button>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        {prod.requiresPrescription ? (
                          <span className="bg-amber-100 text-amber-900 border border-amber-300 font-bold px-2 py-0.5 rounded text-[10px]">
                            Rx Required
                          </span>
                        ) : (
                          <span className="bg-emerald-50 text-emerald-800 border border-emerald-200 font-semibold px-2 py-0.5 rounded text-[10px]">
                            OTC
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleOpenEditProduct(prod)}
                            className="p-2 text-emerald-700 hover:bg-emerald-50 rounded-xl font-bold flex items-center gap-1 border border-emerald-200 text-xs"
                            title="Edit Product Details"
                          >
                            <Edit className="w-3.5 h-3.5" />
                            <span>Edit</span>
                          </button>
                          <button
                            onClick={() => setProductToDelete(prod)}
                            className="p-2 text-rose-600 hover:bg-rose-50 rounded-xl font-bold flex items-center gap-1 border border-rose-200 text-xs"
                            title="Remove Medicine"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Remove</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Remove Medicine Confirmation Dialog */}
      {productToDelete && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full space-y-4 shadow-2xl border border-slate-200 text-center">
            <div className="w-14 h-14 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-7 h-7" />
            </div>

            <h3 className="text-lg font-black text-slate-900">
              Remove Medicine from Catalog?
            </h3>

            <p className="text-xs text-slate-600">
              Are you sure you want to remove <strong>{productToDelete.name}</strong> (SKU: {productToDelete.sku})?
            </p>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-left text-xs space-y-1">
              <p><strong>Salt:</strong> {productToDelete.genericName}</p>
              <p><strong>Stock in Islamabad:</strong> {productToDelete.stock} units</p>
              <p><strong>Price:</strong> PKR {productToDelete.discountPrice ?? productToDelete.price}</p>
            </div>

            <div className="flex flex-col gap-2 pt-2">
              <button
                onClick={() => handleConfirmDeleteProduct(true)}
                className="w-full py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors"
              >
                Delete Permanently
              </button>
              <button
                onClick={() => handleConfirmDeleteProduct(false)}
                className="w-full py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors"
              >
                Archive & Deactivate (Hides from Store)
              </button>
              <button
                onClick={() => setProductToDelete(null)}
                className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Product Add / Edit Modal with Presets */}
      {isAddingProduct && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-3xl w-full max-h-[92vh] overflow-y-auto space-y-4 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-lg font-black text-slate-900">
                  {editingProduct ? 'Edit Medicine / Product' : 'Add New Medicine to Catalog'}
                </h3>
                <p className="text-xs text-slate-400">
                  Enter details or select a quick Pakistani pharmaceutical preset
                </p>
              </div>
              <button
                onClick={() => setIsAddingProduct(false)}
                className="text-slate-400 hover:text-slate-700 font-bold text-lg"
              >
                ✕
              </button>
            </div>

            {/* Quick Presets Bar (when adding a new product) */}
            {!editingProduct && (
              <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-900">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  <span>Click to Quick-Fill with Standard Pakistani Presets:</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {medicinePresets.map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleApplyPreset(preset)}
                      className="px-2.5 py-1 rounded-lg bg-white border border-emerald-300 text-emerald-950 text-[11px] font-bold hover:bg-emerald-100 transition-colors shadow-sm"
                    >
                      + {preset.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <form onSubmit={handleSaveProduct} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Product Brand Name *</label>
                  <input
                    type="text"
                    required
                    value={productForm.name || ''}
                    onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                    placeholder="e.g. Panadol Extra 500mg/65mg"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-bold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Generic Salt / Formula *</label>
                  <input
                    type="text"
                    required
                    value={productForm.genericName || ''}
                    onChange={(e) => setProductForm({ ...productForm, genericName: e.target.value })}
                    placeholder="e.g. Paracetamol + Caffeine"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-bold text-emerald-800"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Brand Name</label>
                  <input
                    type="text"
                    value={productForm.brand || ''}
                    onChange={(e) => setProductForm({ ...productForm, brand: e.target.value })}
                    placeholder="e.g. Panadol, Augmentin, Abbott..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Manufacturer</label>
                  <input
                    type="text"
                    value={productForm.manufacturer || ''}
                    onChange={(e) => setProductForm({ ...productForm, manufacturer: e.target.value })}
                    placeholder="e.g. GSK Pakistan, Getz Pharma, Abbott..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Category</label>
                  <select
                    value={productForm.category || 'Medicines'}
                    onChange={(e) => setProductForm({ ...productForm, category: e.target.value as any })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-semibold"
                  >
                    {[
                      'Medicines',
                      'Prescription Medicines',
                      'OTC Medicines',
                      'Vitamins & Supplements',
                      'Pain Relief',
                      'Cold & Flu',
                      'Digestive Health',
                      'Diabetes Care',
                      'Blood Pressure Care',
                      'Medical Devices',
                      'Baby Care',
                      'Personal Care',
                      'First Aid',
                    ].map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Dosage Form</label>
                  <input
                    type="text"
                    value={productForm.dosageForm || ''}
                    onChange={(e) => setProductForm({ ...productForm, dosageForm: e.target.value })}
                    placeholder="Tablet, Capsule, Syrup, Device..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Strength</label>
                  <input
                    type="text"
                    value={productForm.strength || ''}
                    onChange={(e) => setProductForm({ ...productForm, strength: e.target.value })}
                    placeholder="e.g. 500mg, 10mg/ml"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Pack Size</label>
                  <input
                    type="text"
                    value={productForm.packSize || ''}
                    onChange={(e) => setProductForm({ ...productForm, packSize: e.target.value })}
                    placeholder="e.g. Pack of 20 Tablets, 120ml Bottle"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Price (PKR) *</label>
                  <input
                    type="number"
                    required
                    value={productForm.price || ''}
                    onChange={(e) => setProductForm({ ...productForm, price: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-bold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Discount Price (PKR) Optional</label>
                  <input
                    type="number"
                    value={productForm.discountPrice || ''}
                    onChange={(e) =>
                      setProductForm({
                        ...productForm,
                        discountPrice: e.target.value ? Number(e.target.value) : undefined,
                      })
                    }
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Stock in Islamabad *</label>
                  <input
                    type="number"
                    required
                    value={productForm.stock ?? 0}
                    onChange={(e) => setProductForm({ ...productForm, stock: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-bold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Low Stock Alert Threshold</label>
                  <input
                    type="number"
                    value={productForm.lowStockThreshold || 10}
                    onChange={(e) =>
                      setProductForm({ ...productForm, lowStockThreshold: Number(e.target.value) })
                    }
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5"
                  />
                </div>

                {/* Preset Image Picker */}
                <div className="sm:col-span-2 space-y-1.5">
                  <label className="block font-bold text-slate-700">Choose Image or Paste URL:</label>
                  <div className="flex flex-wrap gap-2 mb-1">
                    {presetImages.map((img, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setProductForm({ ...productForm, image: img.url })}
                        className={`px-2 py-1 rounded-lg border text-[11px] font-semibold transition-colors ${
                          productForm.image === img.url
                            ? 'bg-emerald-700 text-white border-emerald-700'
                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {img.label}
                      </button>
                    ))}
                  </div>
                  <input
                    type="text"
                    value={productForm.image || ''}
                    onChange={(e) => setProductForm({ ...productForm, image: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-bold text-slate-700 mb-1">Description</label>
                  <textarea
                    rows={2}
                    value={productForm.description || ''}
                    onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5"
                  />
                </div>

                <div className="sm:col-span-2 flex flex-wrap gap-4 pt-2">
                  <label className="flex items-center gap-2 font-bold text-slate-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={Boolean(productForm.requiresPrescription)}
                      onChange={(e) =>
                        setProductForm({ ...productForm, requiresPrescription: e.target.checked })
                      }
                      className="w-4 h-4 rounded text-emerald-600 accent-emerald-600"
                    />
                    <span>Requires Doctor's Prescription (Rx)</span>
                  </label>

                  <label className="flex items-center gap-2 font-bold text-slate-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={Boolean(productForm.isFeatured)}
                      onChange={(e) =>
                        setProductForm({ ...productForm, isFeatured: e.target.checked })
                      }
                      className="w-4 h-4 rounded text-emerald-600 accent-emerald-600"
                    />
                    <span>Show as Featured on Homepage</span>
                  </label>

                  <label className="flex items-center gap-2 font-bold text-slate-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={productForm.isActive !== false}
                      onChange={(e) =>
                        setProductForm({ ...productForm, isActive: e.target.checked })
                      }
                      className="w-4 h-4 rounded text-emerald-600 accent-emerald-600"
                    />
                    <span>Active in Store</span>
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddingProduct(false)}
                  className="px-4 py-2 text-slate-600 font-bold hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-6 py-2 rounded-xl shadow-md"
                >
                  Save Medicine
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* TAB 3: Inventory Alerts */}
      {activeTab === 'inventory' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
              <span>Real-Time Inventory & Low-Stock Alerts</span>
            </h2>
            <p className="text-xs text-slate-500">
              Replenish batches, monitor sold units, and ensure stock availability across Islamabad
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-y border-slate-200">
                <tr>
                  <th className="py-3 px-4">Medicine / SKU</th>
                  <th className="py-3 px-4">Current Stock</th>
                  <th className="py-3 px-4">Threshold</th>
                  <th className="py-3 px-4">Sold Units</th>
                  <th className="py-3 px-4">Stock Status</th>
                  <th className="py-3 px-4 text-right">Instant Restock Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {products.map((p) => {
                  const isOut = p.stock <= 0;
                  const isLow = p.stock > 0 && p.stock <= p.lowStockThreshold;

                  return (
                    <tr key={p.id} className="hover:bg-slate-50/50">
                      <td className="py-3 px-4">
                        <strong className="text-slate-900 block font-bold">{p.name}</strong>
                        <span className="text-[10px] text-slate-400">SKU: {p.sku}</span>
                      </td>
                      <td className="py-3 px-4 font-black text-sm text-slate-900">{p.stock}</td>
                      <td className="py-3 px-4 text-slate-500">{p.lowStockThreshold}</td>
                      <td className="py-3 px-4 font-semibold text-slate-700">{p.soldCount || 0}</td>
                      <td className="py-3 px-4">
                        {isOut ? (
                          <span className="bg-rose-100 text-rose-800 font-bold px-2 py-0.5 rounded text-[10px]">
                            Out of Stock
                          </span>
                        ) : isLow ? (
                          <span className="bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded text-[10px]">
                            Low Stock Alert
                          </span>
                        ) : (
                          <span className="bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded text-[10px]">
                            Optimal Stock
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => updateProduct({ ...p, stock: Math.max(0, p.stock - 5) })}
                            className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-2 py-1 rounded"
                            title="Deduct 5"
                          >
                            -5
                          </button>
                          <button
                            onClick={() => updateProduct({ ...p, stock: p.stock + 10 })}
                            className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold px-2.5 py-1 rounded border border-emerald-200"
                            title="Add 10"
                          >
                            +10
                          </button>
                          <button
                            onClick={() => updateProduct({ ...p, stock: p.stock + 50 })}
                            className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-3 py-1 rounded shadow-sm"
                            title="Add 50"
                          >
                            +50 (1 Carton)
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: Prescriptions Verification */}
      {activeTab === 'prescriptions' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                <FileText className="w-5 h-5 text-emerald-600" />
                <span>Prescription Verification Center</span>
              </h2>
              <p className="text-xs text-slate-500">
                Authorized PharmD review desk to validate doctor credentials and dispense approvals
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-600">Filter:</span>
              <select
                value={prescriptionFilter}
                onChange={(e) => setPrescriptionFilter(e.target.value as any)}
                className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs text-slate-800 font-semibold"
              >
                <option value="All">All Statuses ({prescriptions.length})</option>
                <option value="Pending Review">Pending Review</option>
                <option value="Approved">Approved</option>
                <option value="Clarification Required">Clarification Required</option>
                <option value="Rejected">Rejected</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-y border-slate-200">
                <tr>
                  <th className="py-3 px-4">Ref Number</th>
                  <th className="py-3 px-4">Patient & Doctor</th>
                  <th className="py-3 px-4">Sector (Islamabad)</th>
                  <th className="py-3 px-4">Upload Date</th>
                  <th className="py-3 px-4">Attached Document</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {prescriptions
                  .filter((p) => prescriptionFilter === 'All' || p.status === prescriptionFilter)
                  .map((rx) => (
                    <tr key={rx.id} className="hover:bg-slate-50/50">
                      <td className="py-3 px-4 font-extrabold text-slate-900">
                        {rx.referenceNumber}
                      </td>
                      <td className="py-3 px-4">
                        <strong className="block text-slate-800">{rx.patientName}</strong>
                        <span className="text-slate-500 text-[11px]">{rx.patientPhone}</span>
                        {rx.doctorName && (
                          <span className="block text-[10px] text-emerald-800 italic mt-0.5">
                            Doc: {rx.doctorName}
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-700">{rx.sectorArea}</td>
                      <td className="py-3 px-4 text-slate-500">
                        {new Date(rx.uploadedAt).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4">
                        <a
                          href={rx.fileUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="bg-slate-100 hover:bg-slate-200 text-slate-800 px-2 py-1 rounded text-[11px] font-semibold inline-flex items-center gap-1"
                        >
                          <Eye className="w-3 h-3" /> View {rx.fileName}
                        </a>
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            rx.status === 'Approved'
                              ? 'bg-emerald-100 text-emerald-800'
                              : rx.status === 'Rejected'
                              ? 'bg-rose-100 text-rose-800'
                              : rx.status === 'Clarification Required'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {rx.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => {
                            setReviewingPrescription(rx);
                            setPharmacistNotes(rx.reviewNotes || '');
                          }}
                          className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-3 py-1.5 rounded-lg text-xs"
                        >
                          Review & Decide
                        </button>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Review Prescription Modal */}
      {reviewingPrescription && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto space-y-4 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="text-xs uppercase font-extrabold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                  {reviewingPrescription.referenceNumber}
                </span>
                <h3 className="text-lg font-black text-slate-900 mt-1">
                  Pharmacist Prescription Clearance
                </h3>
              </div>
              <button
                onClick={() => setReviewingPrescription(null)}
                className="text-slate-400 hover:text-slate-700 font-bold text-lg"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3 rounded-2xl border border-slate-200">
              <div>
                <span className="text-slate-400 block text-[10px]">Patient</span>
                <strong>{reviewingPrescription.patientName} ({reviewingPrescription.patientPhone})</strong>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Doctor / Clinic</span>
                <strong>{reviewingPrescription.doctorName || 'Not specified on form'}</strong>
              </div>
              <div className="col-span-2">
                <span className="text-slate-400 block text-[10px]">Customer Notes</span>
                <p className="text-slate-700 italic">{reviewingPrescription.additionalNotes || 'No notes provided'}</p>
              </div>
            </div>

            {/* Document preview */}
            <div className="border border-slate-200 rounded-2xl overflow-hidden bg-slate-100 p-2 text-center">
              <a
                href={reviewingPrescription.fileUrl}
                target="_blank"
                rel="noreferrer"
                className="block text-emerald-700 font-bold text-xs underline mb-2"
              >
                Open Full Document Image in New Tab ↗
              </a>
              <img
                src={reviewingPrescription.fileUrl}
                alt="Prescription Document"
                className="max-h-60 mx-auto object-contain rounded-lg"
              />
            </div>

            {/* Pharmacist Notes Input */}
            <div className="space-y-1 text-xs">
              <label className="block font-bold text-slate-800">
                Pharmacist Review Notes & Instructions:
              </label>
              <textarea
                rows={3}
                value={pharmacistNotes}
                onChange={(e) => setPharmacistNotes(e.target.value)}
                placeholder="e.g. Doctor registration verified. Dosage: 1 tab twice daily for 7 days. Customer approved dispatch..."
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5"
              />
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-2 pt-2 justify-end text-xs">
              <button
                onClick={() => handlePrescriptionReview('Clarification Required')}
                className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-4 py-2 rounded-xl"
              >
                Request Clarification
              </button>
              <button
                onClick={() => handlePrescriptionReview('Rejected')}
                className="bg-rose-600 hover:bg-rose-700 text-white font-bold px-4 py-2 rounded-xl"
              >
                Reject Prescription
              </button>
              <button
                onClick={() => handlePrescriptionReview('Approved')}
                className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-5 py-2 rounded-xl"
              >
                Approve & Authorize Order
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: Overview & Metrics */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm space-y-2">
              <span className="text-xs font-semibold text-slate-500 block">Total Sales (PKR)</span>
              <div className="flex items-baseline justify-between">
                <span className="text-2xl font-black text-slate-900">PKR {totalSalesPKR.toLocaleString()}</span>
                <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">All Orders</span>
              </div>
              <p className="text-[11px] text-slate-400">Total revenue across {totalOrdersCount} processed orders</p>
            </div>

            <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm space-y-2">
              <span className="text-xs font-semibold text-slate-500 block">Pending & Review Orders</span>
              <div className="flex items-baseline justify-between">
                <span className="text-2xl font-black text-amber-700">{pendingOrdersCount}</span>
                <span className="text-[11px] font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded">Action Needed</span>
              </div>
              <p className="text-[11px] text-slate-400">Orders requiring pharmacist clearance</p>
            </div>

            <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm space-y-2">
              <span className="text-xs font-semibold text-slate-500 block">Prescription Queue</span>
              <div className="flex items-baseline justify-between">
                <span className="text-2xl font-black text-slate-900">{pendingPrescriptionsCount}</span>
                <span className="text-[11px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">Pending Slips</span>
              </div>
              <p className="text-[11px] text-slate-400">Customer slips waiting for clinical review</p>
            </div>

            <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm space-y-2">
              <span className="text-xs font-semibold text-slate-500 block">Low / Out of Stock</span>
              <div className="flex items-baseline justify-between">
                <span className="text-2xl font-black text-rose-700">{lowStockCount + outOfStockCount}</span>
                <span className="text-[11px] font-bold text-rose-800 bg-rose-50 px-2 py-0.5 rounded">Inventory</span>
              </div>
              <p className="text-[11px] text-slate-400">{lowStockCount} low stock, {outOfStockCount} out of stock</p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: Medicine Sourcing Requests */}
      {activeTab === 'requests' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-lg font-black text-slate-900">
              Unlisted Medicine Customer Sourcing Requests
            </h2>
            <p className="text-xs text-slate-500">
              Customer inquiries for specialized or imported pharmaceuticals not in catalog
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-y border-slate-200">
                <tr>
                  <th className="py-3 px-4">Requested Medicine</th>
                  <th className="py-3 px-4">Customer Name & Phone</th>
                  <th className="py-3 px-4">Strength & Qty</th>
                  <th className="py-3 px-4">Doctor Notes</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Update</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {medicineRequests.map((req) => (
                  <tr key={req.id} className="hover:bg-slate-50/50">
                    <td className="py-3 px-4 font-bold text-slate-900">{req.medicineName}</td>
                    <td className="py-3 px-4">
                      <strong className="block text-slate-800">{req.customerName}</strong>
                      <span className="text-slate-500">{req.phone}</span>
                    </td>
                    <td className="py-3 px-4 text-slate-700">
                      {req.strengthRequired || 'N/A'} • {req.quantity}
                    </td>
                    <td className="py-3 px-4 text-slate-600 max-w-xs">{req.notes || '—'}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          req.status === 'Sourced'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {req.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <select
                        value={req.status}
                        onChange={(e) => updateMedicineRequestStatus(req.id, e.target.value as any)}
                        className="bg-slate-50 border border-slate-300 rounded px-2 py-1 text-xs"
                      >
                        <option value="Pending">Pending</option>
                        <option value="Sourced">Sourced</option>
                        <option value="Customer Contacted">Customer Contacted</option>
                        <option value="Unavailable">Unavailable</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 7: Customer Records */}
      {activeTab === 'customers' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-lg font-black text-slate-900">Customer & Staff Directory</h2>
            <p className="text-xs text-slate-500">
              Registered customers and pharmacy dispensary personnel in Islamabad
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-y border-slate-200">
                <tr>
                  <th className="py-3 px-4">User Name</th>
                  <th className="py-3 px-4">Email</th>
                  <th className="py-3 px-4">Contact Phone</th>
                  <th className="py-3 px-4">Role</th>
                  <th className="py-3 px-4">Saved Islamabad Addresses</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50/50">
                    <td className="py-3 px-4 font-bold text-slate-900">{u.name}</td>
                    <td className="py-3 px-4 text-slate-600">{u.email}</td>
                    <td className="py-3 px-4 text-slate-700">{u.phone}</td>
                    <td className="py-3 px-4">
                      <span className="uppercase text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                        {u.role}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-500">
                      {u.savedAddresses?.map((a) => a.sectorArea).join(', ') || 'Sector F-10, Islamabad'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB: Create Sub-Users & Staff */}
      {activeTab === 'subusers' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6 text-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-emerald-600" />
                <span>Create & Manage Sub-Users (Staff Portal)</span>
              </h2>
              <p className="text-xs text-slate-500">
                Add dispensary staff, order fulfillment riders, and pharmacists to follow orders and update catalog
              </p>
            </div>
            <button
              onClick={() => {
                setSubName('');
                setSubEmail('');
                setSubPhone('+92 333 ');
                setSubRole('pharmacist');
                setSubPassword('staff123');
                setIsCreatingSubUser(true);
              }}
              className="bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs px-4 py-2.5 rounded-xl shadow-md flex items-center gap-1.5 self-start"
            >
              <UserPlus className="w-4 h-4" /> Add New Sub-User
            </button>
          </div>

          {/* Sub-User List */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-y border-slate-200">
                <tr>
                  <th className="py-3 px-4">Staff Name</th>
                  <th className="py-3 px-4">Email (Login)</th>
                  <th className="py-3 px-4">Contact Phone</th>
                  <th className="py-3 px-4">Assigned Role</th>
                  <th className="py-3 px-4">Default Password</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users
                  .filter((u) => u.role === 'admin' || u.role === 'pharmacist' || u.role === 'super_admin')
                  .map((staff) => (
                    <tr key={staff.id} className="hover:bg-slate-50/50">
                      <td className="py-3 px-4 font-bold text-slate-900 flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs">
                          {staff.name.charAt(0)}
                        </div>
                        <span>{staff.name}</span>
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-600">{staff.email}</td>
                      <td className="py-3 px-4 text-slate-700">{staff.phone}</td>
                      <td className="py-3 px-4">
                        <span className="uppercase text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                          {staff.role}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-500">
                        {staff.password || '••••••••'}
                      </td>
                      <td className="py-3 px-4">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                          staff.isActive !== false ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                        }`}>
                          {staff.isActive !== false ? 'Active Staff' : 'Deactivated'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right space-x-2">
                        <button
                          onClick={() => {
                            setSubUserToReset(staff);
                            setResetPassInput('');
                          }}
                          className="text-[11px] font-bold text-emerald-700 hover:text-emerald-900 underline"
                        >
                          Reset Pass
                        </button>
                        {staff.email !== 'admin@binhayyanpharmacy.pk' && (
                          <button
                            onClick={() => {
                              if (confirm(`Remove staff access for ${staff.name}?`)) {
                                deleteSubUser(staff.id);
                              }
                            }}
                            className="text-[11px] font-bold text-rose-600 hover:text-rose-800"
                          >
                            Remove
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>

          {/* Create Sub User Modal */}
          {isCreatingSubUser && (
            <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
              <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h3 className="text-base font-black text-slate-900">Create New Staff Sub-User</h3>
                    <p className="text-[11px] text-slate-500">Add an assistant or dispensary clerk with login access</p>
                  </div>
                  <button onClick={() => setIsCreatingSubUser(false)} className="text-slate-400 hover:text-slate-700">
                    ✕
                  </button>
                </div>

                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (!subName.trim() || !subEmail.trim()) {
                      showToast('Name and email are required', 'error');
                      return;
                    }
                    createSubUser({
                      name: subName.trim(),
                      email: subEmail.trim(),
                      phone: subPhone.trim(),
                      role: subRole,
                      password: subPassword || 'staff123',
                      isActive: true,
                    });
                    setIsCreatingSubUser(false);
                  }}
                  className="space-y-3"
                >
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Staff Member Full Name *</label>
                    <input
                      type="text"
                      required
                      value={subName}
                      onChange={(e) => setSubName(e.target.value)}
                      placeholder="e.g. Usman Tariq (Pharmacist)"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-semibold text-xs"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Official Email (For Admin Login) *</label>
                    <input
                      type="email"
                      required
                      value={subEmail}
                      onChange={(e) => setSubEmail(e.target.value)}
                      placeholder="usman@binhayyanpharmacy.pk"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-semibold text-xs"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Mobile Contact Phone *</label>
                    <input
                      type="text"
                      required
                      value={subPhone}
                      onChange={(e) => setSubPhone(e.target.value)}
                      placeholder="+92 333 1234567"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-semibold text-xs"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Role & Authority</label>
                    <select
                      value={subRole}
                      onChange={(e) => setSubRole(e.target.value as any)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-bold text-xs"
                    >
                      <option value="pharmacist">Dispensary Pharmacist (Can Follow Orders & Stock)</option>
                      <option value="admin">Administrator (Full Access)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Temporary Initial Password</label>
                    <input
                      type="text"
                      value={subPassword}
                      onChange={(e) => setSubPassword(e.target.value)}
                      placeholder="staff123"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-mono text-xs"
                    />
                  </div>

                  <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setIsCreatingSubUser(false)}
                      className="px-4 py-2 font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold px-5 py-2 rounded-xl shadow-md"
                    >
                      Create Staff Account
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* Reset Sub-User Password Modal */}
          {subUserToReset && (
            <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
              <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-sm w-full shadow-2xl border border-slate-200 space-y-4">
                <div className="border-b border-slate-100 pb-3">
                  <h3 className="text-base font-black text-slate-900">Set Password for Staff</h3>
                  <p className="text-xs text-slate-500">{subUserToReset.name} ({subUserToReset.email})</p>
                </div>

                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (!resetPassInput || resetPassInput.length < 5) {
                      showToast('Password must be at least 5 characters', 'error');
                      return;
                    }
                    changePassword(subUserToReset.id, subUserToReset.password || 'admin123', resetPassInput);
                    setSubUserToReset(null);
                  }}
                  className="space-y-3"
                >
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">New Password</label>
                    <input
                      type="text"
                      required
                      value={resetPassInput}
                      onChange={(e) => setResetPassInput(e.target.value)}
                      placeholder="Enter new password"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-mono text-xs"
                    />
                  </div>

                  <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setSubUserToReset(null)}
                      className="px-4 py-2 font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-4 py-2 rounded-xl"
                    >
                      Save Password
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB: Change Admin Password */}
      {activeTab === 'password' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6 text-xs max-w-xl">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
              <KeyRound className="w-5 h-5 text-emerald-600" />
              <span>Change Admin Account Password</span>
            </h2>
            <p className="text-xs text-slate-500">
              Default credentials: <code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-emerald-800">admin@binhayyanpharmacy.pk</code> / <code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-emerald-800">admin123</code>
            </p>
          </div>

          <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-emerald-950 space-y-1">
            <strong className="block font-bold text-emerald-900">Current Logged-in Account:</strong>
            <p><strong>Name:</strong> {currentUser?.name}</p>
            <p><strong>Email:</strong> {currentUser?.email}</p>
            <p><strong>Role:</strong> {currentUser?.role}</p>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!currentUser) return;
              if (newPasswordInput !== confirmPasswordInput) {
                showToast('New passwords do not match!', 'error');
                return;
              }
              if (newPasswordInput.length < 5) {
                showToast('New password must be at least 5 characters', 'error');
                return;
              }
              const ok = changePassword(currentUser.id, currPasswordInput, newPasswordInput);
              if (ok) {
                setCurrPasswordInput('');
                setNewPasswordInput('');
                setConfirmPasswordInput('');
              }
            }}
            className="space-y-4"
          >
            <div>
              <label className="block font-bold text-slate-700 mb-1">Current Password *</label>
              <input
                type="password"
                required
                value={currPasswordInput}
                onChange={(e) => setCurrPasswordInput(e.target.value)}
                placeholder="Enter current password (e.g. admin123)"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-semibold text-xs"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">New Password *</label>
              <input
                type="password"
                required
                value={newPasswordInput}
                onChange={(e) => setNewPasswordInput(e.target.value)}
                placeholder="Enter strong new password"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-semibold text-xs"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Confirm New Password *</label>
              <input
                type="password"
                required
                value={confirmPasswordInput}
                onChange={(e) => setConfirmPasswordInput(e.target.value)}
                placeholder="Re-enter new password"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-semibold text-xs"
              />
            </div>

            <div className="pt-2 space-y-2">
              <button
                type="submit"
                className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
              >
                <KeyRound className="w-4 h-4" />
                <span>Update Admin Password</span>
              </button>

              <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                <span className="text-[11px] text-slate-500">Need to restore original default?</span>
                <button
                  type="button"
                  onClick={() => {
                    if (currentUser) {
                      changePassword(currentUser.id, currentUser.password || '', 'admin123');
                      setCurrPasswordInput('admin123');
                      setNewPasswordInput('');
                      setConfirmPasswordInput('');
                    }
                  }}
                  className="text-[11px] text-emerald-700 hover:text-emerald-900 font-bold underline"
                >
                  Reset password to default (admin123)
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* TAB 8: Islamabad Delivery Zones */}
      {activeTab === 'zones' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-lg font-black text-slate-900">
              Islamabad Delivery Zones & Dispatch Charges
            </h2>
            <p className="text-xs text-slate-500">
              Adjust sector delivery rates, estimated courier delivery windows, and coverage areas
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {deliveryZones.map((zone, idx) => (
              <div key={zone.id} className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4 text-xs">
                <div>
                  <strong className="block text-slate-900 font-extrabold text-sm">{zone.name}</strong>
                  <span className="text-[11px] text-slate-500">{zone.estimatedTime}</span>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Delivery Charge (PKR):</label>
                  <input
                    type="number"
                    value={zone.fee}
                    onChange={(e) => {
                      const updated = [...deliveryZones];
                      updated[idx].fee = Number(e.target.value);
                      updateDeliveryZones(updated);
                    }}
                    className="w-full bg-white border border-slate-300 rounded-xl p-2 font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Estimated Window:</label>
                  <input
                    type="text"
                    value={zone.estimatedTime}
                    onChange={(e) => {
                      const updated = [...deliveryZones];
                      updated[idx].estimatedTime = e.target.value;
                      updateDeliveryZones(updated);
                    }}
                    className="w-full bg-white border border-slate-300 rounded-xl p-2 text-slate-900"
                  />
                </div>

                <div>
                  <span className="block font-bold text-slate-700 mb-1">Covered Sectors:</span>
                  <p className="text-[11px] text-slate-600 bg-white p-2 rounded-lg border border-slate-200">
                    {zone.sectors.join(', ')}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 9: Dispensary Settings */}
      {activeTab === 'settings' && (
        <form
          onSubmit={handleSaveSettings}
          className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6 text-xs"
        >
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-lg font-black text-slate-900">
              Bin Hayyan Dispensary Configuration
            </h2>
            <p className="text-xs text-slate-500">
              Configure pharmacy credentials, WhatsApp hotline, free delivery threshold, and Pakistani bank details
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Pharmacy Name</label>
              <input
                type="text"
                value={localSettings.pharmacyName}
                onChange={(e) => setLocalSettings({ ...localSettings, pharmacyName: e.target.value })}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-bold"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">DRAP License Number</label>
              <input
                type="text"
                value={localSettings.licenseNumber}
                onChange={(e) => setLocalSettings({ ...localSettings, licenseNumber: e.target.value })}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-bold"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Pharmacy Phone Helpline</label>
              <input
                type="text"
                value={localSettings.phone}
                onChange={(e) => setLocalSettings({ ...localSettings, phone: e.target.value })}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-bold"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">WhatsApp Hotline Number</label>
              <input
                type="text"
                value={localSettings.whatsapp}
                onChange={(e) => setLocalSettings({ ...localSettings, whatsapp: e.target.value })}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-bold"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Dispensary Email</label>
              <input
                type="email"
                value={localSettings.email}
                onChange={(e) => setLocalSettings({ ...localSettings, email: e.target.value })}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Opening Hours</label>
              <input
                type="text"
                value={localSettings.openingHours}
                onChange={(e) => setLocalSettings({ ...localSettings, openingHours: e.target.value })}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-bold text-slate-700 mb-1">Physical Address in Islamabad</label>
              <input
                type="text"
                value={localSettings.address}
                onChange={(e) => setLocalSettings({ ...localSettings, address: e.target.value })}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Free Delivery Threshold (PKR)</label>
              <input
                type="number"
                value={localSettings.freeDeliveryThreshold}
                onChange={(e) =>
                  setLocalSettings({ ...localSettings, freeDeliveryThreshold: Number(e.target.value) })
                }
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-bold text-emerald-800"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Minimum Order Value (PKR)</label>
              <input
                type="number"
                value={localSettings.minOrderValue}
                onChange={(e) =>
                  setLocalSettings({ ...localSettings, minOrderValue: Number(e.target.value) })
                }
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-bold"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-bold text-slate-700 mb-1">Announcement Bar Banner Text</label>
              <input
                type="text"
                value={localSettings.announcementText}
                onChange={(e) =>
                  setLocalSettings({ ...localSettings, announcementText: e.target.value })
                }
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5"
              />
            </div>
          </div>

          <div className="border-t border-slate-100 pt-4 flex justify-end">
            <button
              type="submit"
              className="bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs px-6 py-2.5 rounded-xl shadow-md"
            >
              Save Dispensary Settings
            </button>
          </div>
        </form>
      )}

      {/* GitHub Pages Modal */}
      <GitHubPagesModal
        isOpen={githubModalOpen}
        onClose={() => setGithubModalOpen(false)}
      />
    </div>
  );
};
