import React, { useState } from 'react';
import {
  Home,
  ShoppingBag,
  Pill,
  ShieldAlert,
  Sparkles,
  HeartPulse,
  Baby,
  Smile,
  FileText,
  Search,
  MapPin,
  Phone,
  HelpCircle,
  FileQuestion,
  ShieldCheck,
  ChevronRight,
  ChevronLeft,
  X,
  Lock,
  Layers,
  Activity,
  PackagePlus,
  Clock,
  Sparkle,
  SlidersHorizontal,
  Github,
  Download,
} from 'lucide-react';
import { usePharmacy } from '../../context/PharmacyContext';
import { ProductCategory } from '../../types/pharmacy';
import { BinHayyanLogo } from './BinHayyanLogo';
import { GitHubPagesModal } from './GitHubPagesModal';

interface LeftSidebarProps {
  isMobileOpen: boolean;
  onMobileClose: () => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

export const LeftSidebar: React.FC<LeftSidebarProps> = ({
  isMobileOpen,
  onMobileClose,
  collapsed,
  onToggleCollapse,
}) => {
  const {
    navigateTo,
    currentPage,
    categories,
    selectedCategory,
    setSelectedCategory,
    currentUser,
    prescriptions,
    orders,
    settings,
  } = usePharmacy();

  const [categoriesOpen, setCategoriesOpen] = useState(true);
  const [githubModalOpen, setGithubModalOpen] = useState(false);

  const pendingPrescriptionsCount = prescriptions.filter((p) => p.status === 'Pending Review').length;
  const pendingOrdersCount = orders.filter(
    (o) => o.orderStatus === 'Pending' || o.orderStatus === 'Prescription Review'
  ).length;

  const handleNav = (page: any, params?: any) => {
    navigateTo(page, params);
    if (onMobileClose) onMobileClose();
  };

  const handleCategoryNav = (cat: ProductCategory | 'All') => {
    setSelectedCategory(cat);
    navigateTo('shop', { category: cat });
    if (onMobileClose) onMobileClose();
  };

  // Quick category list with icons & badge highlights
  const mainCategories: { name: ProductCategory; icon: any; badge?: string }[] = [
    { name: 'Medicines', icon: Pill },
    { name: 'Prescription Medicines', icon: ShieldAlert, badge: 'Rx' },
    { name: 'OTC Medicines', icon: Pill },
    { name: 'Vitamins & Supplements', icon: Sparkles },
    { name: 'Pain Relief', icon: HeartPulse },
    { name: 'Cold & Flu', icon: Activity },
    { name: 'Digestive Health', icon: HeartPulse },
    { name: 'Diabetes Care', icon: HeartPulse },
    { name: 'Blood Pressure Care', icon: HeartPulse },
    { name: 'Medical Devices', icon: Activity },
    { name: 'Baby Care', icon: Baby },
    { name: 'Personal Care', icon: Smile },
    { name: 'Skin Care', icon: Smile },
    { name: 'First Aid', icon: ShieldCheck },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-40 lg:hidden transition-opacity"
          onClick={onMobileClose}
          aria-hidden="true"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 bg-slate-900 text-slate-100 flex flex-col transition-all duration-300 ease-in-out shadow-2xl border-r border-slate-800 ${
          isMobileOpen ? 'translate-x-0 w-72' : '-translate-x-full lg:translate-x-0'
        } ${collapsed ? 'lg:w-20' : 'lg:w-72'}`}
      >
        {/* Brand / Logo Header */}
        <div className="h-20 shrink-0 px-4 border-b border-slate-800 flex items-center justify-between gap-3 bg-slate-950/60">
          <div
            onClick={() => handleNav('home')}
            className="flex items-center gap-3 cursor-pointer group select-none min-w-0"
            title="Bin-Hayyan Pharmacy"
          >
            <div className="bg-white p-1 rounded-xl shadow-xs border border-slate-700/60 shrink-0">
              <BinHayyanLogo size={collapsed ? 'sm' : 'md'} showText={!collapsed} />
            </div>
          </div>

          {/* Desktop Collapse Toggle / Mobile Close Button */}
          <div className="flex items-center">
            <button
              onClick={onToggleCollapse}
              className="hidden lg:flex p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title={collapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
              aria-label="Toggle sidebar"
            >
              {collapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
            </button>
            <button
              onClick={onMobileClose}
              className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              aria-label="Close sidebar"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Navigation Area */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6 scrollbar-thin scrollbar-thumb-slate-700">
          {/* 1. PRIMARY STORE NAVIGATION */}
          <div className="space-y-1">
            {!collapsed && (
              <p className="px-3 text-[10px] font-black tracking-wider text-slate-400 uppercase mb-1">
                Main Menu
              </p>
            )}

            {/* Home */}
            <button
              onClick={() => handleNav('home')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-xs transition-all ${
                currentPage === 'home'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-700/30'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
              title="Home"
            >
              <Home className="w-4 h-4 shrink-0" />
              {!collapsed && <span>Home</span>}
            </button>

            {/* Shop All */}
            <button
              onClick={() => handleCategoryNav('All')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-xs transition-all ${
                currentPage === 'shop' && selectedCategory === 'All'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
              title="All Medicines & Products"
            >
              <ShoppingBag className="w-4 h-4 shrink-0" />
              {!collapsed && <span>All Products</span>}
            </button>

            {/* Upload Prescription */}
            <button
              onClick={() => handleNav('prescription-upload')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-xs transition-all border ${
                currentPage === 'prescription-upload'
                  ? 'bg-teal-600 text-white border-teal-500 shadow-md'
                  : 'bg-emerald-950/40 text-emerald-300 border-emerald-500/30 hover:bg-emerald-900/60'
              }`}
              title="Upload Doctor's Prescription"
            >
              <FileText className="w-4 h-4 text-emerald-400 shrink-0" />
              {!collapsed && (
                <div className="flex-1 flex items-center justify-between text-left">
                  <span>Upload Prescription</span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-black">
                    Rx
                  </span>
                </div>
              )}
            </button>

            {/* Request Unlisted Medicine */}
            <button
              onClick={() => handleNav('request-medicine')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-xs transition-all ${
                currentPage === 'request-medicine'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
              title="Request Unlisted / Rare Medicine"
            >
              <PackagePlus className="w-4 h-4 shrink-0 text-amber-400" />
              {!collapsed && <span>Request Medicine</span>}
            </button>

            {/* Track Order */}
            <button
              onClick={() => handleNav('order-tracking')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-xs transition-all ${
                currentPage === 'order-tracking'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
              title="Track Islamabad Order"
            >
              <MapPin className="w-4 h-4 shrink-0 text-rose-400" />
              {!collapsed && <span>Track Order Status</span>}
            </button>
          </div>

          {/* 2. ADMIN & STAFF PORTAL ACCESS */}
          <div className="pt-2 border-t border-slate-800 space-y-1">
            {!collapsed && (
              <p className="px-3 text-[10px] font-black tracking-wider text-emerald-400 uppercase mb-1 flex items-center justify-between">
                <span>Dispensary Staff</span>
                <span className="text-[9px] text-slate-500 lowercase font-mono">/admin</span>
              </p>
            )}

            {/* Direct Admin Portal Button */}
            <button
              onClick={() => handleNav('admin')}
              className={`w-full flex items-center gap-3 px-3 py-3 rounded-2xl font-black text-xs transition-all border ${
                currentPage === 'admin'
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white border-emerald-400 shadow-lg shadow-emerald-950/60'
                  : 'bg-emerald-950/70 hover:bg-emerald-900/90 text-emerald-200 border-emerald-500/40 hover:border-emerald-400 shadow-sm'
              }`}
              title="Admin & Pharmacist Portal (/admin)"
            >
              <ShieldCheck className="w-5 h-5 shrink-0 text-emerald-400" />
              {!collapsed && (
                <div className="flex-1 flex items-center justify-between text-left">
                  <div>
                    <span className="block text-white font-extrabold text-xs">
                      Admin Portal
                    </span>
                    <span className="text-[10px] text-emerald-300 font-normal">
                      Orders, Stock & Rx
                    </span>
                  </div>
                  {(pendingOrdersCount > 0 || pendingPrescriptionsCount > 0) && (
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping"></span>
                  )}
                </div>
              )}
            </button>
          </div>

          {/* 3. PRODUCT CATEGORIES */}
          <div className="pt-2 border-t border-slate-800 space-y-1">
            {!collapsed ? (
              <div
                onClick={() => setCategoriesOpen(!categoriesOpen)}
                className="px-3 py-1 flex items-center justify-between text-[10px] font-black tracking-wider text-slate-400 uppercase cursor-pointer hover:text-white select-none"
              >
                <span>Healthcare Categories</span>
                <span>{categoriesOpen ? '−' : '+'}</span>
              </div>
            ) : null}

            {(categoriesOpen || collapsed) && (
              <div className="space-y-0.5">
                {mainCategories.map((cat) => {
                  const Icon = cat.icon;
                  const isSelected = currentPage === 'shop' && selectedCategory === cat.name;

                  return (
                    <button
                      key={cat.name}
                      onClick={() => handleCategoryNav(cat.name)}
                      className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                        isSelected
                          ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 font-bold'
                          : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100'
                      }`}
                      title={cat.name}
                    >
                      <Icon className="w-4 h-4 shrink-0 text-slate-400 group-hover:text-white" />
                      {!collapsed && (
                        <div className="flex-1 flex items-center justify-between text-left truncate">
                          <span className="truncate">{cat.name}</span>
                          {cat.badge && (
                            <span className="text-[9px] px-1 py-0.2 rounded font-black bg-amber-500/20 text-amber-300 border border-amber-500/30">
                              {cat.badge}
                            </span>
                          )}
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* 4. CUSTOMER SERVICES & INFORMATION */}
          <div className="pt-2 border-t border-slate-800 space-y-1">
            {!collapsed && (
              <p className="px-3 text-[10px] font-black tracking-wider text-slate-400 uppercase mb-1">
                Help & Info
              </p>
            )}

            <button
              onClick={() => handleNav('contact')}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                currentPage === 'contact'
                  ? 'bg-emerald-600 text-white'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100'
              }`}
              title="Store Location & Contact"
            >
              <Phone className="w-4 h-4 shrink-0" />
              {!collapsed && <span>Contact & Helpline</span>}
            </button>

            <button
              onClick={() => handleNav('about')}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                currentPage === 'about'
                  ? 'bg-emerald-600 text-white'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100'
              }`}
              title="About Bin Hayyan"
            >
              <HelpCircle className="w-4 h-4 shrink-0" />
              {!collapsed && <span>About Pharmacy</span>}
            </button>

            <button
              onClick={() => handleNav('faqs')}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                currentPage === 'faqs'
                  ? 'bg-emerald-600 text-white'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100'
              }`}
              title="FAQs"
            >
              <FileQuestion className="w-4 h-4 shrink-0" />
              {!collapsed && <span>FAQs</span>}
            </button>

            <button
              onClick={() => handleNav('policies', { tab: 'delivery' })}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                currentPage === 'policies'
                  ? 'bg-emerald-600 text-white'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100'
              }`}
              title="Islamabad Delivery Info & Policies"
            >
              <Clock className="w-4 h-4 shrink-0" />
              {!collapsed && <span>Delivery & Policies</span>}
            </button>

            {/* Export & Drag-and-Drop to GitHub button */}
            <button
              onClick={() => {
                setGithubModalOpen(true);
                if (onMobileClose) onMobileClose();
              }}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-all text-slate-300 hover:bg-slate-800 hover:text-emerald-300 border border-slate-800/80 hover:border-emerald-600/40"
              title="Download Project ZIP / Drag & Drop to GitHub"
            >
              <Github className="w-4 h-4 shrink-0 text-emerald-400" />
              {!collapsed && (
                <div className="flex-1 flex items-center justify-between text-left">
                  <span>Drag & Drop to GitHub</span>
                  <Download className="w-3.5 h-3.5 text-slate-400" />
                </div>
              )}
            </button>
          </div>
        </div>

        {/* Footer info card */}
        {!collapsed && (
          <div className="p-3 m-3 bg-slate-950/70 border border-slate-800/80 rounded-2xl text-[11px] text-slate-400">
            <div className="flex items-center gap-2 text-emerald-400 font-bold mb-1">
              <ShieldCheck className="w-4 h-4" />
              <span>DRAP Licensed</span>
            </div>
            <p className="text-[10px] text-slate-500 leading-tight">
              Markaz F-7 & Blue Area, Islamabad
            </p>
            <p className="text-[10px] text-emerald-400 font-mono mt-1 font-semibold">
              Helpline: {settings.phone}
            </p>
          </div>
        )}
      </aside>

      {/* GitHub Pages & Drag-and-Drop Export Modal */}
      <GitHubPagesModal
        isOpen={githubModalOpen}
        onClose={() => setGithubModalOpen(false)}
      />
    </>
  );
};
