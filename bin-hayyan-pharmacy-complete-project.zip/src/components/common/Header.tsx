import React, { useState } from 'react';
import {
  Search,
  ShoppingCart,
  Heart,
  User as UserIcon,
  Phone,
  FileText,
  Menu,
  ShieldCheck,
  MapPin,
  Clock,
  LogOut,
  ChevronDown,
  Pill,
  LogIn,
} from 'lucide-react';
import { usePharmacy } from '../../context/PharmacyContext';
import { CustomerAuthModal } from './CustomerAuthModal';
import { BinHayyanLogo } from './BinHayyanLogo';

interface HeaderProps {
  onOpenMobileSidebar?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenMobileSidebar }) => {
  const {
    navigateTo,
    cartItemCount,
    wishlist,
    currentUser,
    logout,
    searchQuery,
    setSearchQuery,
    settings,
    authModalOpen,
    setAuthModalOpen,
  } = usePharmacy();

  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigateTo('shop', { q: searchQuery.trim() });
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md shadow-xs border-b border-slate-200/90 transition-all">
      {/* Top Notification Announcement Bar */}
      {settings.announcementActive && (
        <div className="bg-emerald-800 text-emerald-50 text-xs py-1.5 px-4 font-medium border-b border-emerald-900/40">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              <span className="truncate">{settings.announcementText}</span>
            </div>
            <div className="hidden md:flex items-center gap-4 text-emerald-200 text-xs">
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-emerald-300" /> Markaz F-7 & Blue Area, Islamabad
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-emerald-300" /> {settings.openingHours.split('(')[0]}
              </span>
              <span className="flex items-center gap-1 font-semibold text-emerald-100">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" /> DRAP Licensed Pharmacy
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Main Top Header Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex items-center justify-between gap-3 sm:gap-4">
          {/* Left: Mobile Sidebar Trigger + Brand Logo */}
          <div className="flex items-center gap-3">
            {/* Sidebar toggle button (Mobile & small screens) */}
            <button
              onClick={onOpenMobileSidebar}
              className="lg:hidden p-2 rounded-xl text-slate-700 hover:text-emerald-800 hover:bg-slate-100 transition-colors border border-slate-200"
              aria-label="Open sidebar menu"
              title="Open all categories and menu"
            >
              <Menu className="w-5 h-5 text-slate-800" />
            </button>

            {/* Official Brand Logo from Uploaded Image */}
            <div
              onClick={() => navigateTo('home')}
              className="cursor-pointer group select-none"
              title="Bin-Hayyan Pharmacy - Go to Homepage"
            >
              <BinHayyanLogo size="md" />
            </div>
          </div>

          {/* Search Bar (Fast & Typo-Tolerant) */}
          <div className="hidden md:block flex-1 max-w-xl mx-2 lg:mx-4">
            <form onSubmit={handleSearchSubmit} className="relative">
              <input
                type="text"
                placeholder="Search medicines, active salts, blood pressure, diabetes, baby care..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50/90 border border-slate-300 rounded-full pl-11 pr-24 py-2.5 text-xs sm:text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600 focus:bg-white transition-all shadow-inner"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
              <button
                type="submit"
                className="absolute right-1.5 top-1/2 -translate-y-1/2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold px-4 py-1.5 rounded-full transition-colors shadow-xs"
              >
                Search
              </button>
            </form>
          </div>

          {/* Right Header Actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Direct Admin Portal Button for easy 1-click access */}
            <button
              onClick={() => navigateTo('admin')}
              className="inline-flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-emerald-300 hover:text-white text-xs font-black px-3.5 py-2 rounded-xl border border-emerald-500/30 shadow-xs transition-all hover:-translate-y-0.5"
              title="Dispensary Staff & Operations Portal (/admin)"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Admin Portal</span>
            </button>

            {/* Upload Prescription */}
            <button
              onClick={() => navigateTo('prescription-upload')}
              className="hidden sm:inline-flex items-center gap-1.5 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white text-xs font-bold px-3.5 py-2 rounded-xl shadow-xs shadow-emerald-700/20 transition-all hover:-translate-y-0.5"
            >
              <FileText className="w-4 h-4 text-emerald-200" />
              <span>Upload Rx</span>
            </button>

            {/* Helpline (Hidden on small mobile) */}
            <div className="hidden xl:flex items-center gap-2 border-l border-slate-200 pl-3">
              <div className="w-8 h-8 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center">
                <Phone className="w-4 h-4" />
              </div>
              <div className="text-left text-xs leading-tight">
                <span className="text-slate-400 block text-[10px]">Pharmacist Hotline</span>
                <a
                  href={`tel:${settings.phone}`}
                  className="font-bold text-slate-800 hover:text-emerald-700 transition-colors"
                >
                  {settings.phone}
                </a>
              </div>
            </div>

            {/* Customer Sign In / Register if guest */}
            {!currentUser ? (
              <button
                onClick={() => setAuthModalOpen(true)}
                className="hidden sm:inline-flex items-center gap-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold px-3 py-2 rounded-xl border border-emerald-200 shadow-2xs transition-all"
                title="Customer Sign In or Register"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign In</span>
              </button>
            ) : null}

            {/* Wishlist Icon */}
            <button
              onClick={() => navigateTo('account', { tab: 'wishlist' })}
              aria-label="Wishlist"
              className="relative p-2 text-slate-600 hover:text-emerald-700 hover:bg-slate-100 rounded-full transition-colors"
              title="My Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlist.length > 0 && (
                <span className="absolute top-1 right-1 bg-rose-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Cart Icon */}
            <button
              onClick={() => navigateTo('cart')}
              aria-label="Shopping Cart"
              className="relative p-2 text-slate-600 hover:text-emerald-700 hover:bg-slate-100 rounded-full transition-colors"
              title="View Cart"
            >
              <ShoppingCart className="w-5 h-5" />
              {cartItemCount > 0 && (
                <span className="absolute top-1 right-1 bg-emerald-600 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center animate-bounce">
                  {cartItemCount}
                </span>
              )}
            </button>

            {/* User Account Menu */}
            <div className="relative">
              <button
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                className="flex items-center gap-1.5 p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl text-slate-700 hover:bg-slate-100 text-xs font-semibold border border-transparent hover:border-slate-200 transition-all"
              >
                <div className="w-7 h-7 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center font-bold">
                  <UserIcon className="w-4 h-4" />
                </div>
                <span className="hidden md:inline max-w-[90px] truncate">
                  {currentUser ? currentUser.name.split(' ')[0] : 'Account'}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {userMenuOpen && (
                <div
                  className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-50 text-xs"
                  onMouseLeave={() => setUserMenuOpen(false)}
                >
                  <div className="px-4 py-2 border-b border-slate-100">
                    <p className="text-xs font-bold text-slate-900 truncate">
                      {currentUser?.name || 'Guest Customer'}
                    </p>
                    <p className="text-[11px] text-slate-500 truncate">
                      {currentUser?.email || 'Not signed in'}
                    </p>
                    <span className="inline-block mt-1 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                      {currentUser?.role || 'Guest'}
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      setUserMenuOpen(false);
                      navigateTo('account', { tab: 'profile' });
                    }}
                    className="w-full text-left px-4 py-2 text-slate-700 hover:bg-emerald-50 hover:text-emerald-800 flex items-center gap-2 font-medium"
                  >
                    <UserIcon className="w-4 h-4 text-slate-400" /> My Account & Addresses
                  </button>
                  <button
                    onClick={() => {
                      setUserMenuOpen(false);
                      navigateTo('account', { tab: 'orders' });
                    }}
                    className="w-full text-left px-4 py-2 text-slate-700 hover:bg-emerald-50 hover:text-emerald-800 flex items-center gap-2 font-medium"
                  >
                    <ShoppingCart className="w-4 h-4 text-slate-400" /> My Orders
                  </button>
                  <button
                    onClick={() => {
                      setUserMenuOpen(false);
                      navigateTo('account', { tab: 'prescriptions' });
                    }}
                    className="w-full text-left px-4 py-2 text-slate-700 hover:bg-emerald-50 hover:text-emerald-800 flex items-center gap-2 font-medium"
                  >
                    <FileText className="w-4 h-4 text-slate-400" /> My Prescriptions
                  </button>
                  <button
                    onClick={() => {
                      setUserMenuOpen(false);
                      navigateTo('order-tracking');
                    }}
                    className="w-full text-left px-4 py-2 text-slate-700 hover:bg-emerald-50 hover:text-emerald-800 flex items-center gap-2 font-medium"
                  >
                    <MapPin className="w-4 h-4 text-slate-400" /> Track Order Status
                  </button>

                  {/* Admin Portal in Dropdown */}
                  <div className="border-t border-slate-100 pt-1 mt-1">
                    <button
                      onClick={() => {
                        setUserMenuOpen(false);
                        navigateTo('admin');
                      }}
                      className="w-full text-left px-4 py-2 font-bold text-emerald-800 bg-emerald-50/70 hover:bg-emerald-100 flex items-center gap-2"
                    >
                      <ShieldCheck className="w-4 h-4 text-emerald-600" /> Admin & Staff Portal
                    </button>
                  </div>

                  {currentUser ? (
                    <div className="border-t border-slate-100 pt-1 mt-1">
                      <button
                        onClick={() => {
                          setUserMenuOpen(false);
                          logout();
                        }}
                        className="w-full text-left px-4 py-2 text-rose-600 hover:bg-rose-50 flex items-center gap-2 font-medium"
                      >
                        <LogOut className="w-4 h-4" /> Sign Out
                      </button>
                    </div>
                  ) : (
                    <div className="border-t border-slate-100 pt-1 mt-1">
                      <button
                        onClick={() => {
                          setUserMenuOpen(false);
                          setAuthModalOpen(true);
                        }}
                        className="w-full text-left px-4 py-2 text-emerald-700 hover:bg-emerald-50 flex items-center gap-2 font-bold"
                      >
                        <LogIn className="w-4 h-4" /> Sign In / Register
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Mobile Search Input */}
        <div className="mt-2.5 md:hidden">
          <form onSubmit={handleSearchSubmit} className="relative">
            <input
              type="text"
              placeholder="Search medicines, salts, health products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-20 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <button
              type="submit"
              className="absolute right-1 top-1/2 -translate-y-1/2 bg-emerald-700 text-white text-[11px] font-bold px-3 py-1 rounded-lg"
            >
              Search
            </button>
          </form>
        </div>
      </div>

      {/* Customer Registration & Login Modal */}
      <CustomerAuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
      />
    </header>
  );
};
