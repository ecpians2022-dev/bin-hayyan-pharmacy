import React from 'react';

interface BinHayyanLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  textColor?: string;
}

export const BinHayyanLogo: React.FC<BinHayyanLogoProps> = ({
  className = '',
  size = 'md',
  showText = true,
  textColor = 'text-slate-900',
}) => {
  // Dimensions
  const emblemSizes = {
    sm: 'w-8 h-8',
    md: 'w-11 h-11',
    lg: 'w-14 h-14',
    xl: 'w-20 h-20',
  };

  const textSizes = {
    sm: 'text-sm',
    md: 'text-xl',
    lg: 'text-2xl',
    xl: 'text-3xl',
  };

  return (
    <div className={`flex items-center gap-2.5 sm:gap-3 select-none ${className}`}>
      {/* Official Emblem: Circular constellation of medicine molecules/spheres in royal blue (#1e3a8a / #1d4ed8) */}
      <div className={`relative shrink-0 ${emblemSizes[size]} flex items-center justify-center`}>
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full drop-shadow-sm transition-transform duration-300 hover:scale-105"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Constellation of molecular dots forming a cohesive circle like Bin Hayyan Pharmacy's official brand mark */}
          {/* Center clusters */}
          <circle cx="50" cy="50" r="5" fill="#1e3a8a" />
          <circle cx="43" cy="46" r="4.2" fill="#1e3a8a" />
          <circle cx="57" cy="46" r="4.5" fill="#1e3a8a" />
          <circle cx="48" cy="40" r="3.8" fill="#1e3a8a" />
          <circle cx="54" cy="56" r="4.2" fill="#1e3a8a" />
          <circle cx="45" cy="55" r="3.5" fill="#1e3a8a" />
          <circle cx="39" cy="51" r="3.2" fill="#1e3a8a" />
          <circle cx="61" cy="52" r="3.4" fill="#1e3a8a" />

          {/* Inner ring */}
          <circle cx="42" cy="38" r="3.6" fill="#1e3a8a" />
          <circle cx="58" cy="38" r="3.8" fill="#1e3a8a" />
          <circle cx="65" cy="45" r="3.2" fill="#1e3a8a" />
          <circle cx="63" cy="59" r="4.0" fill="#1e3a8a" />
          <circle cx="52" cy="64" r="3.8" fill="#1e3a8a" />
          <circle cx="41" cy="62" r="4.2" fill="#1e3a8a" />
          <circle cx="35" cy="44" r="3.6" fill="#1e3a8a" />
          <circle cx="36" cy="58" r="3.4" fill="#1e3a8a" />
          <circle cx="50" cy="32" r="4.4" fill="#1e3a8a" />

          {/* Mid ring */}
          <circle cx="33" cy="35" r="3.0" fill="#1e3a8a" />
          <circle cx="67" cy="35" r="3.2" fill="#1e3a8a" />
          <circle cx="45" cy="27" r="3.8" fill="#1e3a8a" />
          <circle cx="56" cy="27" r="3.5" fill="#1e3a8a" />
          <circle cx="70" cy="40" r="2.8" fill="#1e3a8a" />
          <circle cx="72" cy="50" r="3.4" fill="#1e3a8a" />
          <circle cx="68" cy="65" r="3.6" fill="#1e3a8a" />
          <circle cx="59" cy="71" r="4.2" fill="#1e3a8a" />
          <circle cx="49" cy="73" r="5.0" fill="#1e3a8a" />
          <circle cx="39" cy="71" r="4.0" fill="#1e3a8a" />
          <circle cx="30" cy="64" r="3.5" fill="#1e3a8a" />
          <circle cx="27" cy="53" r="3.2" fill="#1e3a8a" />
          <circle cx="28" cy="43" r="3.0" fill="#1e3a8a" />

          {/* Outer circle perimeter dots creating the distinct sphere shape */}
          <circle cx="50" cy="21" r="3.6" fill="#1e3a8a" />
          <circle cx="40" cy="23" r="3.2" fill="#1e3a8a" />
          <circle cx="60" cy="23" r="3.2" fill="#1e3a8a" />
          <circle cx="31" cy="28" r="3.4" fill="#1e3a8a" />
          <circle cx="69" cy="28" r="3.5" fill="#1e3a8a" />
          <circle cx="23" cy="37" r="3.0" fill="#1e3a8a" />
          <circle cx="77" cy="37" r="3.0" fill="#1e3a8a" />
          <circle cx="20" cy="48" r="3.6" fill="#1e3a8a" />
          <circle cx="80" cy="48" r="3.4" fill="#1e3a8a" />
          <circle cx="22" cy="60" r="3.5" fill="#1e3a8a" />
          <circle cx="78" cy="60" r="3.2" fill="#1e3a8a" />
          <circle cx="27" cy="70" r="3.8" fill="#1e3a8a" />
          <circle cx="73" cy="69" r="3.6" fill="#1e3a8a" />
          <circle cx="36" cy="79" r="4.2" fill="#1e3a8a" />
          <circle cx="64" cy="78" r="4.0" fill="#1e3a8a" />
          <circle cx="45" cy="81" r="4.6" fill="#1e3a8a" />
          <circle cx="55" cy="81" r="4.6" fill="#1e3a8a" />
        </svg>
      </div>

      {/* Official Typography from image: Serif/Bold "Bin-Hayyan" in Royal Blue + "Pharmacy" in Emerald Green */}
      {showText && (
        <div className="flex flex-col leading-none">
          <span
            className={`font-serif font-black tracking-tight ${textSizes[size]} text-[#1e3a8a]`}
            style={{ fontFamily: 'Georgia, Cambria, "Times New Roman", serif' }}
          >
            Bin-Hayyan
          </span>
          <span
            className={`font-sans font-extrabold tracking-tight text-emerald-700 ${
              size === 'sm' ? 'text-xs' : size === 'md' ? 'text-base' : size === 'lg' ? 'text-lg' : 'text-xl'
            }`}
          >
            Pharmacy
          </span>
        </div>
      )}
    </div>
  );
};
