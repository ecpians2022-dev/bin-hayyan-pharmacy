import React, { useState } from 'react';
import {
  Download,
  Github,
  Check,
  Copy,
  ExternalLink,
  X,
  FileCode,
  ShieldCheck,
  Sparkles,
  Terminal,
  MousePointer,
  FolderArchive,
  KeyRound,
  Lock,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { downloadGitHubPagesZip } from '../../utils/githubProjectExporter';
import { usePharmacy } from '../../context/PharmacyContext';

interface GitHubPagesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GitHubPagesModal: React.FC<GitHubPagesModalProps> = ({ isOpen, onClose }) => {
  const { showToast, navigateTo } = usePharmacy();
  const [activeTab, setActiveTab] = useState<'dragdrop' | 'cli' | 'admin'>('dragdrop');
  const [copied, setCopied] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  if (!isOpen) return null;

  const gitCommands = `git init
git add .
git commit -m "Deploy Bin Hayyan Pharmacy to GitHub Pages"
git branch -M main
git remote add origin https://github.com/<YOUR-USERNAME>/bin-hayyan-pharmacy.git
git push -u origin main`;

  const handleCopyCommands = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(gitCommands);
      setCopied(true);
      showToast('Git commands copied to clipboard!', 'success');
      setTimeout(() => setCopied(false), 3000);
    }
  };

  const handleDownloadZip = async (mode: 'drag-drop' | 'complete' = 'complete') => {
    setIsDownloading(true);
    try {
      await downloadGitHubPagesZip({ mode });
      showToast(
        mode === 'drag-drop'
          ? 'Downloading Drag & Drop Website package with complete index.html!'
          : 'Downloading Complete Project ZIP with pre-built index.html & source code!',
        'success'
      );
    } catch {
      showToast('Failed to trigger download.', 'error');
    } finally {
      setTimeout(() => setIsDownloading(false), 800);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-3xl p-5 sm:p-8 max-w-2xl w-full max-h-[92vh] overflow-y-auto space-y-6 shadow-2xl border border-slate-200">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-slate-950 text-white flex items-center justify-center shadow-md shrink-0">
              <Github className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-lg sm:text-xl font-black text-slate-900">
                  Export & Deploy to GitHub Pages
                </h3>
                <span className="text-[10px] uppercase font-black tracking-wider px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                  Complete index.html Included
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Drag & drop ready • No command line or npm required to host online
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex items-center gap-2 border-b border-slate-200 pb-2 text-xs font-bold">
          <button
            onClick={() => setActiveTab('dragdrop')}
            className={`px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition-all ${
              activeTab === 'dragdrop'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <MousePointer className="w-4 h-4" />
            <span>Drag & Drop to GitHub (No CLI)</span>
          </button>

          <button
            onClick={() => setActiveTab('admin')}
            className={`px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition-all ${
              activeTab === 'admin'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <KeyRound className="w-4 h-4" />
            <span>Admin Password Info</span>
          </button>

          <button
            onClick={() => setActiveTab('cli')}
            className={`px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition-all ${
              activeTab === 'cli'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>Command Line (Git)</span>
          </button>
        </div>

        {/* TAB 1: DRAG & DROP METHOD (DEFAULT) */}
        {activeTab === 'dragdrop' && (
          <div className="space-y-5">
            {/* Download Buttons Section */}
            <div className="bg-gradient-to-br from-emerald-900 via-teal-950 to-slate-900 rounded-3xl p-5 sm:p-6 text-white shadow-lg space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h4 className="font-black text-sm sm:text-base flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    <span>Download Ready-To-Upload Package</span>
                  </h4>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    This archive contains a <strong>complete, fully built <code className="text-emerald-300 bg-emerald-950/60 px-1 py-0.5 rounded">index.html</code></strong> and compiled <code className="text-emerald-300 bg-emerald-950/60 px-1 py-0.5 rounded">assets/</code> folder so you can simply drag & drop the files straight into GitHub.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <button
                  onClick={() => handleDownloadZip('drag-drop')}
                  disabled={isDownloading}
                  className="w-full py-3 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs rounded-xl shadow-md transition-all hover:scale-[1.01] active:scale-[0.99] flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  <span>{isDownloading ? 'Preparing ZIP...' : 'Download Drag & Drop ZIP'}</span>
                </button>

                <button
                  onClick={() => handleDownloadZip('complete')}
                  disabled={isDownloading}
                  className="w-full py-3 px-4 bg-slate-800 hover:bg-slate-700 text-emerald-200 border border-emerald-500/30 font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <FolderArchive className="w-4 h-4" />
                  <span>Download Full Project (All Files)</span>
                </button>
              </div>

              <div className="flex items-center gap-2 text-[11px] text-emerald-300/90 pt-1 border-t border-emerald-800/60">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Includes <code className="text-white">index.html</code>, <code className="text-white">assets/</code>, <code className="text-white">404.html</code>, and <code className="text-white">.nojekyll</code></span>
              </div>
            </div>

            {/* 4 Simple Drag & Drop Steps */}
            <div className="space-y-3 text-xs">
              <h4 className="font-extrabold text-slate-900 uppercase tracking-wider text-[11px] flex items-center gap-2">
                <span>How to Upload & Publish on GitHub Without Any Command Line:</span>
              </h4>

              <div className="space-y-3">
                <div className="flex items-start gap-3 bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                  <span className="w-6 h-6 rounded-full bg-slate-900 text-white font-black flex items-center justify-center text-xs shrink-0 mt-0.5">
                    1
                  </span>
                  <div>
                    <strong className="block text-slate-900 font-bold text-xs">
                      Extract the Downloaded ZIP
                    </strong>
                    <span className="text-slate-600 leading-relaxed text-[11px] block mt-0.5">
                      Double-click and extract the downloaded <code className="bg-slate-200 px-1 py-0.5 rounded text-slate-800">.zip</code> archive on your computer. You will see <code className="font-bold text-slate-800">index.html</code>, the <code className="font-bold text-slate-800">assets</code> folder, and <code className="font-bold text-slate-800">404.html</code>.
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                  <span className="w-6 h-6 rounded-full bg-slate-900 text-white font-black flex items-center justify-center text-xs shrink-0 mt-0.5">
                    2
                  </span>
                  <div>
                    <strong className="block text-slate-900 font-bold text-xs">
                      Create a Repository on GitHub.com
                    </strong>
                    <span className="text-slate-600 leading-relaxed text-[11px] block mt-0.5">
                      Go to <a href="https://github.com/new" target="_blank" rel="noreferrer" className="text-emerald-700 underline font-bold inline-flex items-center gap-1">github.com/new <ExternalLink className="w-3 h-3" /></a> in your browser. Name it <code className="bg-white px-1.5 py-0.5 rounded border border-slate-200 text-slate-800 font-mono">bin-hayyan-pharmacy</code> (Public) and click <strong>Create repository</strong>.
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                  <span className="w-6 h-6 rounded-full bg-slate-900 text-white font-black flex items-center justify-center text-xs shrink-0 mt-0.5">
                    3
                  </span>
                  <div>
                    <strong className="block text-slate-900 font-bold text-xs">
                      Drag & Drop the Files into GitHub
                    </strong>
                    <span className="text-slate-600 leading-relaxed text-[11px] block mt-0.5">
                      On your new repository page, click the link: <strong>"uploading an existing file"</strong> (or <strong>Add file → Upload files</strong>). Select all the extracted files (<code className="font-bold">index.html</code>, <code className="font-bold">assets</code> folder, <code className="font-bold">404.html</code>, <code className="font-bold">.nojekyll</code>) and <strong>drag & drop them into the browser window</strong>. Click the green <strong>"Commit changes"</strong> button!
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-emerald-50 p-3.5 rounded-2xl border border-emerald-200 text-emerald-950">
                  <span className="w-6 h-6 rounded-full bg-emerald-700 text-white font-black flex items-center justify-center text-xs shrink-0 mt-0.5">
                    4
                  </span>
                  <div>
                    <strong className="block font-bold text-xs text-emerald-950">
                      Enable GitHub Pages & Go Live!
                    </strong>
                    <span className="text-emerald-900 leading-relaxed text-[11px] block mt-0.5">
                      In your GitHub repository, click <strong>Settings → Pages</strong>. Under <strong>Build and deployment</strong>, set Source to <strong>"Deploy from a branch"</strong>, select <strong>main</strong> / <strong>/ (root)</strong>, and click <strong>Save</strong>. In 1 minute your website will be live at:
                      <code className="block mt-1 bg-white/90 p-1.5 rounded-lg text-emerald-950 font-mono text-[11px] font-bold border border-emerald-300">
                        https://&lt;your-username&gt;.github.io/bin-hayyan-pharmacy/
                      </code>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: ADMIN PASSWORD GUIDE */}
        {activeTab === 'admin' && (
          <div className="space-y-4 text-xs">
            <div className="bg-emerald-50 border border-emerald-200 rounded-3xl p-5 space-y-3">
              <div className="flex items-center gap-2 text-emerald-900 font-black text-sm">
                <Lock className="w-4 h-4 text-emerald-700" />
                <span>Default Admin Portal Credentials</span>
              </div>
              <p className="text-emerald-800 text-[11px] leading-relaxed">
                The dispensary management system comes with pre-configured default credentials for the Lead Administrator and staff pharmacists:
              </p>

              <div className="bg-white rounded-2xl p-4 border border-emerald-200 space-y-2.5 font-mono text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <div>
                    <span className="font-sans font-bold text-slate-500 text-[10px] uppercase block">
                      Lead Pharmacist / Owner
                    </span>
                    <span className="text-slate-900 font-bold">admin@binhayyanpharmacy.pk</span>
                  </div>
                  <div className="text-right">
                    <span className="font-sans font-bold text-slate-500 text-[10px] uppercase block">
                      Default Password
                    </span>
                    <span className="bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded font-black">
                      admin123
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <div>
                    <span className="font-sans font-bold text-slate-500 text-[10px] uppercase block">
                      Dispensary Verification Staff
                    </span>
                    <span className="text-slate-900 font-bold">pharmacist@binhayyanpharmacy.pk</span>
                  </div>
                  <div className="text-right">
                    <span className="font-sans font-bold text-slate-500 text-[10px] uppercase block">
                      Default Password
                    </span>
                    <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded font-black">
                      pharmacist123
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* How to Change Password Steps */}
            <div className="bg-white border border-slate-200 rounded-3xl p-5 space-y-3">
              <h4 className="font-black text-slate-900 text-sm flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-emerald-600" />
                <span>How to Change the Admin Password:</span>
              </h4>

              <ol className="list-decimal list-inside space-y-2 text-slate-700 leading-relaxed text-[11px]">
                <li>
                  Click <strong>"Admin Portal"</strong> in the permanent left sidebar (or go to <code className="bg-slate-100 px-1 py-0.5 rounded text-emerald-800">/admin</code>).
                </li>
                <li>
                  Sign in using <code className="bg-slate-100 px-1 py-0.5 rounded">admin@binhayyanpharmacy.pk</code> and <code className="bg-slate-100 px-1 py-0.5 rounded">admin123</code> (or click the quick 1-Click "Lead Admin" login button).
                </li>
                <li>
                  In the top navigation tabs of the Admin Dashboard, click the <strong>"Change Admin Password"</strong> tab (Key icon 🔑).
                </li>
                <li>
                  Enter current password (<code className="bg-slate-100 px-1 py-0.5 rounded">admin123</code>), then enter and confirm your new password.
                </li>
                <li>
                  Click <strong>"Update Admin Password"</strong>. The new password is saved immediately in your browser storage!
                </li>
              </ol>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-slate-500">
                  Want to go directly to the Admin Portal now?
                </span>
                <button
                  onClick={() => {
                    onClose();
                    navigateTo('admin');
                  }}
                  className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl flex items-center gap-1 shadow-sm"
                >
                  <span>Open Admin Portal</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: COMMAND LINE (GIT CLI) */}
        {activeTab === 'cli' && (
          <div className="space-y-4 text-xs">
            <div className="flex items-center justify-between mb-1">
              <strong className="block text-slate-900 font-bold">
                Git Terminal Commands:
              </strong>
              <button
                onClick={handleCopyCommands}
                className="text-[11px] text-emerald-700 hover:text-emerald-800 font-bold flex items-center gap-1"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Copied!' : 'Copy Commands'}</span>
              </button>
            </div>
            <pre className="bg-slate-900 text-emerald-400 p-3 rounded-2xl text-[11px] font-mono overflow-x-auto leading-relaxed shadow-inner">
              {gitCommands}
            </pre>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-slate-600 text-[11px] leading-relaxed space-y-2">
              <p className="font-bold text-slate-800">
                Automated GitHub Actions CI/CD:
              </p>
              <p>
                The project includes <code className="bg-white px-1 py-0.5 rounded text-emerald-800 border">.github/workflows/deploy.yml</code>. In your GitHub repository under <strong>Settings → Pages → Source</strong>, simply select <strong>"GitHub Actions"</strong> and GitHub will automatically build and publish the site on every push!
              </p>
            </div>
          </div>
        )}

        {/* Modal Footer */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-100 text-xs">
          <button
            onClick={() => handleDownloadZip('drag-drop')}
            disabled={isDownloading}
            className="text-emerald-700 hover:text-emerald-800 font-bold flex items-center gap-1.5"
          >
            <Download className="w-4 h-4" />
            <span>Download ZIP Archive</span>
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
