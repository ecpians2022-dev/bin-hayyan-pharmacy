import React from 'react';
import {
  Pill,
  MapPin,
  Phone,
  Mail,
  Clock,
  ShieldCheck,
  Truck,
  Heart,
  ArrowRight,
  MessageCircle,
} from 'lucide-react';
import { usePharmacy } from '../../context/PharmacyContext';
import { BinHayyanLogo } from './BinHayyanLogo';

export const Footer: React.FC = () => {
  const { navigateTo, settings } = usePharmacy();

  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800 text-sm">
      {/* Trust & Guarantee Banner */}
      <div className="border-b border-slate-800 bg-slate-950/60 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-emerald-900/60 border border-emerald-700/50 flex items-center justify-center text-emerald-400 shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">100% Sourced from Licensed Suppliers</h4>
              <p className="text-xs text-slate-400">Strictly verified Pakistani supply chain with DRAP compliance</p>
            </div>
          </div>

          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-emerald-900/60 border border-emerald-700/50 flex items-center justify-center text-emerald-400 shrink-0">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">Fast Islamabad Delivery</h4>
              <p className="text-xs text-slate-400">45-90 min door delivery across F, G, I sectors & Blue Area</p>
            </div>
          </div>

          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-emerald-900/60 border border-emerald-700/50 flex items-center justify-center text-emerald-400 shrink-0">
              <Pill className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">PharmD Pharmacist on Duty</h4>
              <p className="text-xs text-slate-400">Qualified drug verification before dispatch</p>
            </div>
          </div>

          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-emerald-900/60 border border-emerald-700/50 flex items-center justify-center text-emerald-400 shrink-0">
              <Heart className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">Cold-Chain Temperature Control</h4>
              <p className="text-xs text-slate-400">2°C–8°C refrigerated storage for insulin & vaccines</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Pharmacy Profile */}
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-white p-2 rounded-2xl w-fit shadow-md border border-slate-700/60">
              <BinHayyanLogo size="md" />
            </div>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Bin Hayyan Pharmacy is a trusted local pharmacy in Islamabad providing authentic medicines,
              medical devices, personal care, and specialized cold-chain pharmaceutical dispensing.
              Operating under license number: <strong className="text-slate-300">{settings.licenseNumber}</strong>.
            </p>

            <div className="space-y-2 text-xs text-slate-300 pt-2">
              <p className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>{settings.address}, {settings.city}, Pakistan</span>
              </p>
              <p className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <a href={`tel:${settings.phone}`} className="hover:text-emerald-400 transition-colors">
                  {settings.phone}
                </a>
              </p>
              <p className="flex items-center gap-2.5">
                <MessageCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <a
                  href={`https://wa.me/${settings.whatsapp.replace(/[^0-9]/g, '')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-emerald-400 transition-colors"
                >
                  WhatsApp: {settings.whatsapp}
                </a>
              </p>
              <p className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-emerald-400 shrink-0" />
                <a href={`mailto:${settings.email}`} className="hover:text-emerald-400 transition-colors">
                  {settings.email}
                </a>
              </p>
              <p className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{settings.openingHours}</span>
              </p>
            </div>
          </div>

          {/* Quick Categories */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4 border-l-2 border-emerald-500 pl-2">
              Departments
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>
                <button
                  onClick={() => navigateTo('shop', { category: 'Prescription Medicines' })}
                  className="hover:text-emerald-400 transition-colors flex items-center gap-1.5"
                >
                  <ArrowRight className="w-3 h-3 text-emerald-500" /> Prescription Medicines
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('shop', { category: 'OTC Medicines' })}
                  className="hover:text-emerald-400 transition-colors flex items-center gap-1.5"
                >
                  <ArrowRight className="w-3 h-3 text-emerald-500" /> OTC Medicines
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('shop', { category: 'Vitamins & Supplements' })}
                  className="hover:text-emerald-400 transition-colors flex items-center gap-1.5"
                >
                  <ArrowRight className="w-3 h-3 text-emerald-500" /> Vitamins & Supplements
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('shop', { category: 'Medical Devices' })}
                  className="hover:text-emerald-400 transition-colors flex items-center gap-1.5"
                >
                  <ArrowRight className="w-3 h-3 text-emerald-500" /> Medical Devices
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('shop', { category: 'Baby Care' })}
                  className="hover:text-emerald-400 transition-colors flex items-center gap-1.5"
                >
                  <ArrowRight className="w-3 h-3 text-emerald-500" /> Baby & Infant Care
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('shop', { category: 'Personal Care' })}
                  className="hover:text-emerald-400 transition-colors flex items-center gap-1.5"
                >
                  <ArrowRight className="w-3 h-3 text-emerald-500" /> Personal & Skin Care
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('request-medicine')}
                  className="text-emerald-400 hover:text-emerald-300 font-semibold transition-colors flex items-center gap-1.5"
                >
                  <ArrowRight className="w-3 h-3 text-emerald-400" /> Request Unlisted Medicine
                </button>
              </li>
            </ul>
          </div>

          {/* Customer Support */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4 border-l-2 border-emerald-500 pl-2">
              Customer Services
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>
                <button
                  onClick={() => navigateTo('prescription-upload')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Upload Prescription
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('order-tracking')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Track Islamabad Order
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('account', { tab: 'orders' })}
                  className="hover:text-emerald-400 transition-colors"
                >
                  My Orders & Invoices
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('account', { tab: 'prescriptions' })}
                  className="hover:text-emerald-400 transition-colors"
                >
                  My Prescription Records
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('faqs')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Frequently Asked Questions
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('about')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  About Bin Hayyan Pharmacy
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('contact')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Store Location & Hours
                </button>
              </li>
            </ul>
          </div>

          {/* Islamabad Delivery Areas & Policies */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4 border-l-2 border-emerald-500 pl-2">
              Islamabad Zones
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              Serving Sectors F-6, F-7, F-8, F-10, F-11, G-6 to G-11, I-8, I-9, I-10, Blue Area, Bani Gala, Bahria Town & DHA Islamabad.
            </p>
            <div className="pt-2 border-t border-slate-800 space-y-2 text-xs">
              <div>
                <button
                  onClick={() => navigateTo('policies', { tab: 'delivery' })}
                  className="hover:text-emerald-400 transition-colors block text-slate-400"
                >
                  Delivery Policy & Charges
                </button>
              </div>
              <div>
                <button
                  onClick={() => navigateTo('policies', { tab: 'refund' })}
                  className="hover:text-emerald-400 transition-colors block text-slate-400"
                >
                  Refund & Return Policy
                </button>
              </div>
              <div>
                <button
                  onClick={() => navigateTo('policies', { tab: 'privacy' })}
                  className="hover:text-emerald-400 transition-colors block text-slate-400"
                >
                  Privacy Policy & Patient Data
                </button>
              </div>
              <div>
                <button
                  onClick={() => navigateTo('policies', { tab: 'terms' })}
                  className="hover:text-emerald-400 transition-colors block text-slate-400"
                >
                  Terms & Conditions
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Pharmacy Medical Safety Disclaimer */}
        <div className="mt-10 pt-6 border-t border-slate-800 text-slate-400 text-xs leading-relaxed bg-slate-950/40 p-4 rounded-xl border border-slate-800/80">
          <div className="flex items-start gap-2.5">
            <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-200 block mb-1">
                Important Pharmacy & Medical Safety Notice:
              </strong>
              <p>
                {settings.disclaimer}
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Bar: Copyright & Payment Badges */}
        <div className="mt-8 pt-6 border-t border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>
            © {new Date().getFullYear()} Bin Hayyan Pharmacy. Islamabad, Pakistan. All Rights Reserved.
          </p>

          <div className="flex items-center gap-3">
            <span className="text-[11px] text-slate-400 font-medium">Accepted Payments:</span>
            <span className="px-2 py-0.5 rounded bg-slate-800 text-emerald-400 text-[11px] font-semibold border border-slate-700">
              Cash on Delivery (COD)
            </span>
            <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[11px] font-semibold border border-slate-700">
              Direct Bank Transfer (Meezan Bank)
            </span>
            <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-400 text-[11px] font-semibold border border-slate-700">
              JazzCash / Easypaisa
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
