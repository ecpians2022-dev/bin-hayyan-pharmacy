import React from 'react';
import { MessageCircle, Phone } from 'lucide-react';
import { usePharmacy } from '../../context/PharmacyContext';

export const FloatingWhatsApp: React.FC = () => {
  const { settings } = usePharmacy();
  const cleanPhone = settings.whatsapp.replace(/[^0-9]/g, '');

  const whatsappMessage = encodeURIComponent(
    'Salam Bin Hayyan Pharmacy, I would like to inquire about medicine availability and doorstep delivery in Islamabad.'
  );

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col gap-3">
      {/* Mobile call button */}
      <a
        href={`tel:${settings.phone}`}
        className="md:hidden flex items-center justify-center w-12 h-12 bg-emerald-800 text-white rounded-full shadow-lg hover:bg-emerald-900 transition-transform active:scale-95"
        aria-label="Call Pharmacist"
      >
        <Phone className="w-5 h-5" />
      </a>

      {/* WhatsApp Floating button */}
      <a
        href={`https://wa.me/${cleanPhone}?text=${whatsappMessage}`}
        target="_blank"
        rel="noreferrer"
        className="group flex items-center gap-2.5 bg-emerald-600 hover:bg-emerald-700 text-white pl-3.5 pr-4 py-2.5 rounded-full shadow-xl shadow-emerald-900/30 transition-all hover:scale-105 active:scale-95"
        aria-label="Order or Ask on WhatsApp"
      >
        <div className="relative">
          <MessageCircle className="w-6 h-6 fill-white text-emerald-600" />
          <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-lime-400 rounded-full border-2 border-white animate-pulse"></span>
        </div>
        <span className="text-xs font-bold tracking-tight whitespace-nowrap hidden sm:inline">
          Order / Ask on WhatsApp
        </span>
      </a>
    </div>
  );
};
