import React, { useState } from 'react';
import {
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  ArrowRight,
  ShieldCheck,
  FileText,
  AlertTriangle,
  Truck,
  Sparkles,
} from 'lucide-react';
import { usePharmacy } from '../../context/PharmacyContext';

export const CartPage: React.FC = () => {
  const {
    cart,
    removeFromCart,
    updateCartQuantity,
    clearCart,
    cartSubtotal,
    deliveryZones,
    settings,
    navigateTo,
  } = usePharmacy();

  const [selectedZoneId, setSelectedZoneId] = useState(deliveryZones[0]?.id || 'zone-1');

  const selectedZone = deliveryZones.find((z) => z.id === selectedZoneId) || deliveryZones[0];
  const isFreeDelivery = cartSubtotal >= settings.freeDeliveryThreshold;
  const deliveryFee = isFreeDelivery ? 0 : (selectedZone?.fee || 150);
  const grandTotal = cartSubtotal + deliveryFee;

  const hasPrescriptionItems = cart.some((item) => item.product.requiresPrescription);

  const amountNeededForFreeDelivery = Math.max(0, settings.freeDeliveryThreshold - cartSubtotal);
  const freeDeliveryPercent = Math.min(100, (cartSubtotal / settings.freeDeliveryThreshold) * 100);

  if (cart.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center space-y-6">
        <div className="w-20 h-20 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto shadow-inner">
          <ShoppingBag className="w-10 h-10" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            Your Shopping Cart is Empty
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto">
            You don't have any medicines or healthcare items in your cart. Browse our catalog to add
            daily essentials or upload your doctor's slip.
          </p>
        </div>
        <div className="flex flex-wrap justify-center gap-3 pt-2">
          <button
            onClick={() => navigateTo('shop')}
            className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs sm:text-sm px-6 py-3 rounded-xl shadow-md transition-all"
          >
            Browse All Medicines
          </button>
          <button
            onClick={() => navigateTo('prescription-upload')}
            className="bg-emerald-50 text-emerald-800 border border-emerald-300 hover:bg-emerald-100 font-bold text-xs sm:text-sm px-6 py-3 rounded-xl transition-all flex items-center gap-2"
          >
            <FileText className="w-4 h-4 text-emerald-600" />
            <span>Upload Doctor's Slip</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Title */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <ShoppingBag className="w-6 h-6 text-emerald-700" />
            <span>Shopping Cart ({cart.length} items)</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">Review your items before proceeding to Islamabad delivery</p>
        </div>
        <button
          onClick={clearCart}
          className="text-xs text-rose-600 hover:underline font-semibold"
        >
          Clear Cart
        </button>
      </div>

      {/* Free Delivery Goal Bar */}
      <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 space-y-2">
        <div className="flex items-center justify-between text-xs">
          <span className="font-semibold text-emerald-950 flex items-center gap-1.5">
            <Truck className="w-4 h-4 text-emerald-700" />
            {isFreeDelivery ? (
              <span className="font-bold text-emerald-800">
                🎉 Congratulations! You unlocked FREE Doorstep Delivery in Islamabad!
              </span>
            ) : (
              <span>
                Add <strong>PKR {amountNeededForFreeDelivery}</strong> more to get <strong>FREE delivery</strong> (Orders over PKR {settings.freeDeliveryThreshold})
              </span>
            )}
          </span>
          <span className="font-extrabold text-emerald-800 text-xs">
            {Math.round(freeDeliveryPercent)}%
          </span>
        </div>
        <div className="w-full bg-emerald-200/60 rounded-full h-2.5 overflow-hidden">
          <div
            className="bg-emerald-600 h-2.5 rounded-full transition-all duration-500"
            style={{ width: `${freeDeliveryPercent}%` }}
          ></div>
        </div>
      </div>

      {/* Prescription Notice if applicable */}
      {hasPrescriptionItems && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-xs text-amber-900 flex items-start gap-3">
          <FileText className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <strong className="block font-bold text-amber-950">
              Prescription (Rx) Items Detected:
            </strong>
            <span>
              One or more medicines in your cart require a valid doctor’s prescription. You can complete
              checkout, but please ensure you upload your slip so our pharmacist can verify and release the order.
            </span>
            <button
              onClick={() => navigateTo('prescription-upload')}
              className="mt-1 block font-bold text-amber-900 underline hover:text-amber-950"
            >
              Upload Prescription Now →
            </button>
          </div>
        </div>
      )}

      {/* Cart Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Cart Items List */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-3xl p-6 shadow-sm divide-y divide-slate-100">
          {cart.map((item) => {
            const unitPrice = item.product.discountPrice ?? item.product.price;
            const subtotal = unitPrice * item.quantity;

            return (
              <div key={item.product.id} className="py-4 first:pt-0 last:pb-0 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-xl bg-slate-50 border border-slate-200 overflow-hidden shrink-0">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] uppercase font-bold text-emerald-800">
                        {item.product.brand}
                      </span>
                      {item.product.requiresPrescription && (
                        <span className="text-[9px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
                          Rx
                        </span>
                      )}
                    </div>
                    <h4 className="font-bold text-slate-900 text-sm leading-snug">
                      {item.product.name}
                    </h4>
                    <p className="text-xs text-slate-500">
                      Salt: {item.product.genericName} • {item.product.packSize}
                    </p>
                    <p className="text-xs font-semibold text-slate-700">
                      PKR {unitPrice} each
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-6 w-full sm:w-auto pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                  {/* Quantity controls */}
                  <div className="flex items-center border border-slate-200 rounded-xl bg-slate-50">
                    <button
                      onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                      className="p-1.5 text-slate-600 hover:text-slate-900"
                      aria-label="Decrease quantity"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="px-3 text-xs font-bold text-slate-800 min-w-[28px] text-center">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                      disabled={item.quantity >= item.product.stock}
                      className="p-1.5 text-slate-600 hover:text-slate-900 disabled:opacity-40"
                      aria-label="Increase quantity"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Subtotal */}
                  <div className="text-right min-w-[90px]">
                    <span className="font-extrabold text-slate-900 text-sm">
                      PKR {subtotal}
                    </span>
                  </div>

                  {/* Remove Button */}
                  <button
                    onClick={() => removeFromCart(item.product.id)}
                    className="p-2 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                    title="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Order Summary & Delivery Estimator */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-3xl p-6 shadow-md space-y-6">
          <h3 className="font-extrabold text-slate-900 text-base border-b border-slate-100 pb-3">
            Order Summary
          </h3>

          {/* Delivery Zone Selector for Islamabad */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-700">
              Estimated Delivery Zone (Islamabad)
            </label>
            <select
              value={selectedZoneId}
              onChange={(e) => setSelectedZoneId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-600"
            >
              {deliveryZones.map((zone) => (
                <option key={zone.id} value={zone.id}>
                  {zone.name} ({zone.estimatedTime})
                </option>
              ))}
            </select>
            <p className="text-[11px] text-slate-500">
              Sectors: {selectedZone?.sectors.slice(0, 5).join(', ')}...
            </p>
          </div>

          {/* Pricing breakdown */}
          <div className="space-y-2.5 text-xs border-t border-slate-100 pt-4">
            <div className="flex justify-between text-slate-600">
              <span>Items Subtotal</span>
              <span className="font-bold text-slate-900">PKR {cartSubtotal}</span>
            </div>

            <div className="flex justify-between text-slate-600">
              <span>Islamabad Delivery Fee</span>
              {deliveryFee === 0 ? (
                <span className="font-bold text-emerald-700 uppercase text-[11px]">
                  FREE
                </span>
              ) : (
                <span className="font-bold text-slate-900">PKR {deliveryFee}</span>
              )}
            </div>

            <div className="flex justify-between text-slate-600">
              <span>Tax / GST</span>
              <span className="font-medium text-slate-500">Included in prices</span>
            </div>

            <div className="border-t border-slate-200 pt-3 flex justify-between items-baseline text-slate-900">
              <span className="font-extrabold text-sm">Estimated Total</span>
              <span className="font-black text-xl text-emerald-900">
                PKR {grandTotal}
              </span>
            </div>
          </div>

          {/* Checkout CTA */}
          <div className="space-y-3 pt-2">
            <button
              onClick={() => navigateTo('checkout')}
              className="w-full py-3.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-sm shadow-md shadow-emerald-700/20 transition-all hover:scale-[1.01] active:scale-[0.99] flex items-center justify-center gap-2"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => navigateTo('shop')}
              className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors"
            >
              ← Continue Shopping
            </button>
          </div>

          <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-500 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Pay securely via Cash on Delivery or Meezan Bank transfer upon receipt.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
