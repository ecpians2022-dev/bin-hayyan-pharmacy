import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Truck,
  Building,
  CreditCard,
  Banknote,
  CheckCircle2,
  AlertCircle,
  FileText,
  MapPin,
  ArrowRight,
  Info,
  UserPlus,
  LogIn,
  Lock,
  User as UserIcon,
  Phone,
  Mail,
  Sparkles,
} from 'lucide-react';
import { usePharmacy } from '../../context/PharmacyContext';
import { DeliveryMethod, PaymentMethod, Address, OrderItem } from '../../types/pharmacy';

export const CheckoutPage: React.FC = () => {
  const {
    cart,
    cartSubtotal,
    deliveryZones,
    settings,
    currentUser,
    placeOrder,
    navigateTo,
    showToast,
    login,
    register,
  } = usePharmacy();

  // Registration / Login sub-tab state if guest
  const [authTab, setAuthTab] = useState<'register' | 'login'>('register');
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('+92 300 ');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');

  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Form states
  const [customerName, setCustomerName] = useState(currentUser?.name || '');
  const [customerPhone, setCustomerPhone] = useState(currentUser?.phone || '+92 300 ');
  const [customerEmail, setCustomerEmail] = useState(currentUser?.email || '');
  const [deliveryMethod, setDeliveryMethod] = useState<DeliveryMethod>('Home Delivery');

  // Keep customer fields in sync when currentUser changes
  useEffect(() => {
    if (currentUser) {
      setCustomerName(currentUser.name);
      setCustomerPhone(currentUser.phone);
      setCustomerEmail(currentUser.email);
    }
  }, [currentUser]);

  // Islamabad Address
  const [sectorArea, setSectorArea] = useState('F-7');
  const [streetAddress, setStreetAddress] = useState('');
  const [deliveryNotes, setDeliveryNotes] = useState('');

  // Payment method
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Cash on Delivery');
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);

  // Determine delivery zone fee
  const allSectors = deliveryZones.flatMap((z) => z.sectors);
  const matchedZone = deliveryZones.find((z) => z.sectors.includes(sectorArea)) || deliveryZones[0];

  const isFreeDelivery = cartSubtotal >= settings.freeDeliveryThreshold;
  const deliveryFee =
    deliveryMethod === 'Pharmacy Pickup'
      ? 0
      : isFreeDelivery
      ? 0
      : (matchedZone?.fee || 150);

  const grandTotal = cartSubtotal + deliveryFee;
  const hasPrescriptionItems = cart.some((i) => i.product.requiresPrescription);

  const handleRegisterCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName.trim()) {
      showToast('Please enter your full name.', 'error');
      return;
    }
    if (!regPhone.trim() || regPhone.length < 9) {
      showToast('Please enter a valid Pakistani mobile number.', 'error');
      return;
    }
    if (!regEmail.trim() || !regEmail.includes('@')) {
      showToast('Please enter a valid email address.', 'error');
      return;
    }
    if (!regPassword || regPassword.length < 4) {
      showToast('Password should be at least 4 characters long.', 'error');
      return;
    }

    const success = register(regName, regEmail, regPhone, regPassword);
    if (success) {
      setCustomerName(regName);
      setCustomerPhone(regPhone);
      setCustomerEmail(regEmail);
    }
  };

  const handleLoginCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail.trim()) {
      showToast('Please enter your email.', 'error');
      return;
    }

    const success = login(loginEmail, loginPassword, 'customer');
    if (success) {
      const user = currentUser;
      if (user) {
        setCustomerName(user.name);
        setCustomerPhone(user.phone);
        setCustomerEmail(user.email);
      }
    }
  };

  const handleQuickDemoCustomer = () => {
    login('tariq.mehmood@example.com', undefined, 'customer');
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();

    if (!currentUser) {
      showToast('Please register or sign in first to place your order.', 'error');
      return;
    }

    if (cart.length === 0) {
      showToast('Your cart is empty.', 'error');
      navigateTo('shop');
      return;
    }

    if (!customerName.trim()) {
      showToast('Please enter your full name.', 'error');
      return;
    }

    if (!customerPhone.trim() || customerPhone.length < 9) {
      showToast('Please enter a valid Pakistani contact number.', 'error');
      return;
    }

    if (deliveryMethod === 'Home Delivery' && !streetAddress.trim()) {
      showToast('Please provide your street address in Islamabad.', 'error');
      return;
    }

    setIsPlacingOrder(true);

    try {
      const orderItems: OrderItem[] = cart.map((item) => {
        const unitPrice = item.product.discountPrice ?? item.product.price;
        return {
          productId: item.product.id,
          productName: item.product.name,
          genericName: item.product.genericName,
          strength: item.product.strength,
          packSize: item.product.packSize,
          unitPrice,
          quantity: item.quantity,
          subtotal: unitPrice * item.quantity,
          requiresPrescription: item.product.requiresPrescription,
          image: item.product.image,
        };
      });

      const shippingAddress: Address = {
        id: `addr-${Date.now()}`,
        title: deliveryMethod === 'Pharmacy Pickup' ? 'Store Pickup' : 'Islamabad Delivery',
        recipientName: customerName,
        recipientPhone: customerPhone,
        sectorArea: deliveryMethod === 'Pharmacy Pickup' ? 'F-7 / Blue Area' : sectorArea,
        streetAddress:
          deliveryMethod === 'Pharmacy Pickup'
            ? `${settings.address}, ${settings.city}`
            : streetAddress,
        city: 'Islamabad',
        postalCode: '44000',
        deliveryNotes,
      };

      const placed = placeOrder({
        userId: currentUser?.id,
        customerName,
        customerPhone,
        customerEmail,
        deliveryMethod,
        shippingAddress,
        items: orderItems,
        subtotal: cartSubtotal,
        discount: 0,
        deliveryFee,
        total: grandTotal,
        paymentMethod,
        paymentStatus: paymentMethod === 'Cash on Delivery' ? 'Cash on Hand' : 'Pending',
        orderStatus: hasPrescriptionItems ? 'Prescription Review' : 'Pending',
        prescriptionRequired: hasPrescriptionItems,
        prescriptionStatus: hasPrescriptionItems ? 'Pending Review' : 'None',
        notes: deliveryNotes,
        estimatedDelivery:
          deliveryMethod === 'Pharmacy Pickup'
            ? 'Ready for pickup in 20-30 minutes'
            : matchedZone?.estimatedTime || '45 - 90 mins',
      });

      showToast(`Order ${placed.orderNumber} placed successfully!`, 'success');
      navigateTo('order-confirmation', { orderId: placed.id, orderNumber: placed.orderNumber });
    } catch {
      showToast('Failed to complete order. Please try again.', 'error');
    } finally {
      setIsPlacingOrder(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Title */}
      <div className="text-center max-w-xl mx-auto space-y-1">
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
          Secure Islamabad Checkout
        </h1>
        <p className="text-xs sm:text-sm text-slate-500">
          Fast doorstep delivery across Islamabad sectors or convenient pickup at Markaz F-7
        </p>
      </div>

      <form onSubmit={handlePlaceOrder}>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Customer & Delivery Information */}
          <div className="lg:col-span-7 space-y-6">
            {/* 1. Customer Account & Registration */}
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
              <h3 className="font-extrabold text-slate-900 text-sm flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white text-xs flex items-center justify-center font-bold">
                    1
                  </span>
                  <span>Customer Account & Contact</span>
                </div>
                {currentUser ? (
                  <span className="text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Verified Customer</span>
                  </span>
                ) : (
                  <span className="text-[11px] font-bold text-amber-800 bg-amber-100 px-2.5 py-0.5 rounded-full">
                    Registration Required to Order
                  </span>
                )}
              </h3>

              {!currentUser ? (
                /* Unregistered Guest: Registration / Login form */
                <div className="space-y-4 bg-emerald-50/60 p-4 rounded-2xl border border-emerald-200">
                  <div className="flex items-start gap-2.5 text-xs text-emerald-950">
                    <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                    <div>
                      <strong className="block text-emerald-900 font-bold">
                        Please register your customer account to place an online order.
                      </strong>
                      <p className="text-[11px] text-emerald-800">
                        In accordance with healthcare safety and Drug Regulatory Authority of Pakistan (DRAP) requirements, registered accounts ensure safe medicine dispensing, prescription verification, and live SMS/WhatsApp dispatch updates.
                      </p>
                    </div>
                  </div>

                  {/* Tabs */}
                  <div className="grid grid-cols-2 p-1 bg-white rounded-xl text-xs font-bold border border-emerald-200">
                    <button
                      type="button"
                      onClick={() => setAuthTab('register')}
                      className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                        authTab === 'register'
                          ? 'bg-emerald-700 text-white shadow-sm'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                      <span>Create Account (Register)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setAuthTab('login')}
                      className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                        authTab === 'login'
                          ? 'bg-emerald-700 text-white shadow-sm'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <LogIn className="w-3.5 h-3.5" />
                      <span>Sign In to Existing</span>
                    </button>
                  </div>

                  {authTab === 'register' ? (
                    <div className="space-y-3 text-xs">
                      <div>
                        <label className="block font-bold text-slate-800 mb-1">Full Name *</label>
                        <input
                          type="text"
                          required
                          value={regName}
                          onChange={(e) => setRegName(e.target.value)}
                          placeholder="e.g. Tariq Mehmood / Dr. Bilal"
                          className="w-full bg-white border border-slate-300 rounded-xl p-2.5 font-semibold"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block font-bold text-slate-800 mb-1">Pakistani Mobile Number *</label>
                          <input
                            type="tel"
                            required
                            value={regPhone}
                            onChange={(e) => setRegPhone(e.target.value)}
                            placeholder="+92 300 1234567"
                            className="w-full bg-white border border-slate-300 rounded-xl p-2.5 font-semibold"
                          />
                        </div>

                        <div>
                          <label className="block font-bold text-slate-800 mb-1">Email Address *</label>
                          <input
                            type="email"
                            required
                            value={regEmail}
                            onChange={(e) => setRegEmail(e.target.value)}
                            placeholder="name@example.com"
                            className="w-full bg-white border border-slate-300 rounded-xl p-2.5 font-semibold"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block font-bold text-slate-800 mb-1">Create Password *</label>
                        <input
                          type="password"
                          required
                          value={regPassword}
                          onChange={(e) => setRegPassword(e.target.value)}
                          placeholder="••••••••"
                          className="w-full bg-white border border-slate-300 rounded-xl p-2.5 font-semibold"
                        />
                      </div>

                      <button
                        type="button"
                        onClick={handleRegisterCustomer}
                        className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5"
                      >
                        <UserPlus className="w-4 h-4" />
                        <span>Register Customer Account & Continue</span>
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-3 text-xs">
                      <div>
                        <label className="block font-bold text-slate-800 mb-1">Email Address *</label>
                        <input
                          type="email"
                          required
                          value={loginEmail}
                          onChange={(e) => setLoginEmail(e.target.value)}
                          placeholder="name@example.com"
                          className="w-full bg-white border border-slate-300 rounded-xl p-2.5 font-semibold"
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-800 mb-1">Password</label>
                        <input
                          type="password"
                          value={loginPassword}
                          onChange={(e) => setLoginPassword(e.target.value)}
                          placeholder="••••••••"
                          className="w-full bg-white border border-slate-300 rounded-xl p-2.5 font-semibold"
                        />
                      </div>

                      <button
                        type="button"
                        onClick={handleLoginCustomer}
                        className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5"
                      >
                        <LogIn className="w-4 h-4" />
                        <span>Sign In & Continue</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleQuickDemoCustomer}
                        className="w-full py-2 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-xl border border-slate-200 transition-colors flex items-center justify-between px-3"
                      >
                        <span>Demo Account: Tariq Mehmood (F-10)</span>
                        <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                /* Registered Customer: Details display with change/logout option */
                <div className="space-y-4">
                  <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 flex items-center justify-between text-xs">
                    <div>
                      <p className="font-extrabold text-emerald-950 text-sm">{currentUser.name}</p>
                      <p className="text-emerald-800 font-medium">
                        {currentUser.phone} • {currentUser.email}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setAuthTab('login');
                      }}
                      className="text-xs text-emerald-800 hover:underline font-bold"
                    >
                      Change Details
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Recipient Name <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder="Recipient full name"
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs sm:text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Mobile Number (For rider call) <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="tel"
                        required
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        placeholder="+92 3XX-XXXXXXX"
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs sm:text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Email Address (For electronic invoice)
                      </label>
                      <input
                        type="email"
                        value={customerEmail}
                        onChange={(e) => setCustomerEmail(e.target.value)}
                        placeholder="name@example.com"
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* 2. Delivery Option & Islamabad Address */}
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
              <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2 border-b border-slate-100 pb-3">
                <span className="w-5 h-5 rounded-full bg-emerald-600 text-white text-xs flex items-center justify-center font-bold">
                  2
                </span>
                <span>Delivery or Pickup Option</span>
              </h3>

              {/* Delivery Mode Tabs */}
              <div className="grid grid-cols-2 gap-3">
                <div
                  onClick={() => setDeliveryMethod('Home Delivery')}
                  className={`cursor-pointer p-4 rounded-2xl border text-xs flex items-center gap-3 transition-all ${
                    deliveryMethod === 'Home Delivery'
                      ? 'border-emerald-600 bg-emerald-50/60 text-emerald-950 font-bold shadow-sm'
                      : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <div className={`p-2 rounded-xl ${deliveryMethod === 'Home Delivery' ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-700'}`}>
                    <Truck className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block font-bold">Home Delivery</span>
                    <span className="text-[11px] text-slate-500 font-normal">
                      45 - 90 mins to your address
                    </span>
                  </div>
                </div>

                <div
                  onClick={() => setDeliveryMethod('Pharmacy Pickup')}
                  className={`cursor-pointer p-4 rounded-2xl border text-xs flex items-center gap-3 transition-all ${
                    deliveryMethod === 'Pharmacy Pickup'
                      ? 'border-emerald-600 bg-emerald-50/60 text-emerald-950 font-bold shadow-sm'
                      : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <div className={`p-2 rounded-xl ${deliveryMethod === 'Pharmacy Pickup' ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-700'}`}>
                    <Building className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block font-bold">Pharmacy Pickup</span>
                    <span className="text-[11px] text-slate-500 font-normal">
                      Beverly Centre, F-7 / Blue Area
                    </span>
                  </div>
                </div>
              </div>

              {/* Address inputs for Home Delivery */}
              {deliveryMethod === 'Home Delivery' ? (
                <div className="space-y-4 pt-2">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Islamabad Sector / Area <span className="text-rose-500">*</span>
                      </label>
                      <select
                        value={sectorArea}
                        onChange={(e) => setSectorArea(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                      >
                        {allSectors.map((sector) => (
                          <option key={sector} value={sector}>
                            {sector} (Islamabad)
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        City
                      </label>
                      <input
                        type="text"
                        disabled
                        value="Islamabad, Pakistan"
                        className="w-full bg-slate-100 border border-slate-300 rounded-xl p-2.5 text-xs sm:text-sm text-slate-600 cursor-not-allowed"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Street Address / House # / Apartment <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={streetAddress}
                        onChange={(e) => setStreetAddress(e.target.value)}
                        placeholder="House # 142, Street 35, Sector F-10/1..."
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Delivery Notes or Nearby Landmark (Optional)
                      </label>
                      <input
                        type="text"
                        value={deliveryNotes}
                        onChange={(e) => setDeliveryNotes(e.target.value)}
                        placeholder="e.g. Near Markaz Mosque, ring bell twice, call on arrival..."
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white"
                      />
                    </div>
                  </div>
                </div>
              ) : (
                /* Pickup Branch Info */
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-xs space-y-2">
                  <p className="font-bold text-slate-900 flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-emerald-600" />
                    Pickup Location:
                  </p>
                  <p className="text-slate-700">
                    <strong>Bin Hayyan Pharmacy</strong>
                    <br />
                    {settings.address}, {settings.city}, Pakistan
                  </p>
                  <p className="text-slate-500 text-[11px]">
                    Operating Hours: {settings.openingHours}
                  </p>
                </div>
              )}
            </div>

            {/* 3. Payment Methods */}
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
              <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2 border-b border-slate-100 pb-3">
                <span className="w-5 h-5 rounded-full bg-emerald-600 text-white text-xs flex items-center justify-center font-bold">
                  3
                </span>
                <span>Select Payment Method</span>
              </h3>

              <div className="space-y-3">
                {/* Cash on Delivery */}
                <label
                  className={`flex items-start gap-3 p-4 rounded-2xl border cursor-pointer transition-all ${
                    paymentMethod === 'Cash on Delivery'
                      ? 'border-emerald-600 bg-emerald-50/50 shadow-sm'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="paymentMethod"
                    checked={paymentMethod === 'Cash on Delivery'}
                    onChange={() => setPaymentMethod('Cash on Delivery')}
                    className="mt-1 accent-emerald-600"
                  />
                  <div className="text-xs">
                    <strong className="block text-slate-900 font-bold text-sm flex items-center gap-2">
                      <Banknote className="w-4 h-4 text-emerald-600" /> Cash on Delivery (COD)
                    </strong>
                    <span className="text-slate-500">
                      Pay in cash directly to our delivery rider upon receipt of your medicine parcel.
                    </span>
                  </div>
                </label>

                {/* Direct Bank Transfer */}
                <label
                  className={`flex items-start gap-3 p-4 rounded-2xl border cursor-pointer transition-all ${
                    paymentMethod === 'Bank Transfer'
                      ? 'border-emerald-600 bg-emerald-50/50 shadow-sm'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="paymentMethod"
                    checked={paymentMethod === 'Bank Transfer'}
                    onChange={() => setPaymentMethod('Bank Transfer')}
                    className="mt-1 accent-emerald-600"
                  />
                  <div className="text-xs">
                    <strong className="block text-slate-900 font-bold text-sm flex items-center gap-2">
                      <CreditCard className="w-4 h-4 text-emerald-600" /> Direct Bank Transfer (Meezan Bank)
                    </strong>
                    <span className="text-slate-500">
                      Transfer directly via Raast or online mobile banking to our Islamabad corporate account.
                    </span>

                    {paymentMethod === 'Bank Transfer' && (
                      <div className="mt-3 bg-white border border-slate-200 rounded-xl p-3 text-[11px] text-slate-700 space-y-1">
                        <p><strong>Bank:</strong> {settings.bankDetails.bankName}</p>
                        <p><strong>Account Title:</strong> {settings.bankDetails.accountTitle}</p>
                        <p><strong>Account Number:</strong> {settings.bankDetails.accountNumber}</p>
                        <p><strong>IBAN:</strong> {settings.bankDetails.iban}</p>
                        <p><strong>Branch:</strong> {settings.bankDetails.branch}</p>
                        <p className="text-emerald-800 text-[10px] pt-1">
                          * Please send screenshot of transaction via WhatsApp to {settings.whatsapp} with your Order ID.
                        </p>
                      </div>
                    )}
                  </div>
                </label>

                {/* Card on Delivery */}
                <label
                  className={`flex items-start gap-3 p-4 rounded-2xl border cursor-pointer transition-all ${
                    paymentMethod === 'Card on Delivery'
                      ? 'border-emerald-600 bg-emerald-50/50 shadow-sm'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="paymentMethod"
                    checked={paymentMethod === 'Card on Delivery'}
                    onChange={() => setPaymentMethod('Card on Delivery')}
                    className="mt-1 accent-emerald-600"
                  />
                  <div className="text-xs">
                    <strong className="block text-slate-900 font-bold text-sm flex items-center gap-2">
                      <CreditCard className="w-4 h-4 text-emerald-600" /> Card on Delivery (POS Machine)
                    </strong>
                    <span className="text-slate-500">
                      Swipe debit/credit card via wireless POS terminal with our rider in Islamabad.
                    </span>
                  </div>
                </label>
              </div>
            </div>
          </div>

          {/* Right Column: Order Review & Placement */}
          <div className="lg:col-span-5 bg-white border border-slate-200 rounded-3xl p-6 shadow-md space-y-6">
            <h3 className="font-extrabold text-slate-900 text-base border-b border-slate-100 pb-3">
              Order Review ({cart.length} items)
            </h3>

            {/* Items summary */}
            <div className="space-y-3 max-h-60 overflow-y-auto pr-1 divide-y divide-slate-100">
              {cart.map((item) => {
                const price = item.product.discountPrice ?? item.product.price;
                return (
                  <div key={item.product.id} className="pt-2.5 first:pt-0 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2.5 max-w-[70%]">
                      <div className="w-9 h-9 rounded-lg bg-slate-50 border border-slate-200 overflow-hidden shrink-0">
                        <img src={item.product.image} alt={item.product.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="truncate">
                        <p className="font-bold text-slate-900 truncate">{item.product.name}</p>
                        <span className="text-[10px] text-slate-400">Qty: {item.quantity} × PKR {price}</span>
                      </div>
                    </div>
                    <span className="font-extrabold text-slate-800">PKR {price * item.quantity}</span>
                  </div>
                );
              })}
            </div>

            {/* Prescription Warning */}
            {hasPrescriptionItems && (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl text-xs text-amber-900 space-y-1">
                <div className="flex items-center gap-1.5 font-bold">
                  <FileText className="w-4 h-4 text-amber-600" />
                  <span>Prescription Verification Required</span>
                </div>
                <p className="text-[11px] leading-relaxed">
                  Your order contains prescription items. Our licensed pharmacist will hold dispatch
                  until your valid doctor slip is verified.
                </p>
              </div>
            )}

            {/* Calculations */}
            <div className="space-y-2.5 text-xs border-t border-slate-100 pt-4">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal</span>
                <span className="font-bold text-slate-900">PKR {cartSubtotal}</span>
              </div>

              <div className="flex justify-between text-slate-600">
                <span>Delivery Charges ({sectorArea})</span>
                {deliveryFee === 0 ? (
                  <span className="font-bold text-emerald-700 uppercase text-[11px]">FREE</span>
                ) : (
                  <span className="font-bold text-slate-900">PKR {deliveryFee}</span>
                )}
              </div>

              <div className="border-t border-slate-200 pt-3 flex justify-between items-baseline text-slate-900">
                <span className="font-extrabold text-sm">Total Payable</span>
                <span className="font-black text-2xl text-emerald-900">PKR {grandTotal}</span>
              </div>
            </div>

            {/* Submit Button */}
            <div>
              <button
                type="submit"
                disabled={isPlacingOrder}
                className="w-full py-4 px-6 rounded-2xl bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-sm sm:text-base shadow-xl shadow-emerald-700/20 transition-all hover:scale-[1.01] active:scale-[0.99] flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-5 h-5" />
                <span>{isPlacingOrder ? 'Confirming Order...' : `Confirm & Place Order (PKR ${grandTotal})`}</span>
              </button>
            </div>

            <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-400 space-y-1">
              <p>✓ Quality medicines and cold-chain handling</p>
              <p>✓ Dispensed under licensed PharmD pharmacist supervision</p>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};
