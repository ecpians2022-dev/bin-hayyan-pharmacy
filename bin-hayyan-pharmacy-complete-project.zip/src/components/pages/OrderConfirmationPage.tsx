import React from 'react';
import {
  CheckCircle2,
  Clock,
  MapPin,
  Phone,
  FileText,
  Printer,
  ArrowRight,
  MessageCircle,
  Truck,
  ShieldCheck,
} from 'lucide-react';
import { usePharmacy } from '../../context/PharmacyContext';

export const OrderConfirmationPage: React.FC = () => {
  const { pageParams, getOrder, navigateTo, settings } = usePharmacy();
  const orderId = pageParams.orderId || pageParams.orderNumber;
  const order = getOrder(orderId);

  if (!order) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-2xl font-bold text-slate-900">Order Information Not Found</h2>
        <p className="text-xs text-slate-500">
          We could not locate this order. Please check your order reference number or view your account history.
        </p>
        <button
          onClick={() => navigateTo('home')}
          className="bg-emerald-700 text-white text-xs font-bold px-5 py-2.5 rounded-xl hover:bg-emerald-800"
        >
          Return to Home
        </button>
      </div>
    );
  }

  const handlePrint = () => {
    window.print();
  };

  const cleanPhone = settings.whatsapp.replace(/[^0-9]/g, '');
  const whatsappMsg = encodeURIComponent(
    `Salam Bin Hayyan Pharmacy, I just placed order ${order.orderNumber} for ${order.shippingAddress.sectorArea}, Islamabad. Please confirm dispatch timing.`
  );

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
      {/* Top Success Badge */}
      <div className="bg-white border border-emerald-200 rounded-3xl p-8 sm:p-10 shadow-xl text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-inner">
          <CheckCircle2 className="w-10 h-10" />
        </div>

        <div className="space-y-1">
          <span className="text-xs uppercase font-extrabold tracking-widest text-emerald-800 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            Order Reference: {order.orderNumber}
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 mt-2">
            Thank You for Your Order!
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Your order has been recorded at Bin Hayyan Pharmacy. Our dispensary team is reviewing it now.
          </p>
        </div>

        {/* Prescription Required Alert */}
        {order.prescriptionRequired && (
          <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl text-xs text-amber-900 text-left flex items-start gap-3 mt-4">
            <FileText className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <strong className="block font-bold text-amber-950 mb-0.5">
                Doctor's Prescription Verification Required:
              </strong>
              <span>
                This order includes prescription medication. If you haven't uploaded your doctor’s slip yet,
                please upload it now or send a photo via WhatsApp to allow dispatch.
              </span>
              <button
                onClick={() => navigateTo('prescription-upload')}
                className="mt-2 block font-extrabold text-amber-900 underline hover:text-amber-950"
              >
                Upload Prescription Now →
              </button>
            </div>
          </div>
        )}

        {/* Order Details & Summary Box */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-200 text-left text-xs">
          <div>
            <span className="text-slate-400 block text-[10px]">Order Date</span>
            <strong className="text-slate-800">
              {new Date(order.createdAt).toLocaleDateString('en-PK', {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              })}
            </strong>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px]">Delivery Mode & Sector</span>
            <strong className="text-slate-800">
              {order.deliveryMethod} ({order.shippingAddress.sectorArea})
            </strong>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px]">Total Amount</span>
            <strong className="text-emerald-800 font-extrabold text-sm">
              PKR {order.total} ({order.paymentMethod})
            </strong>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          <button
            onClick={() => navigateTo('order-tracking', { orderNumber: order.orderNumber })}
            className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-md transition-colors flex items-center gap-2"
          >
            <Truck className="w-4 h-4" />
            <span>Track Live Delivery Status</span>
          </button>

          <a
            href={`https://wa.me/${cleanPhone}?text=${whatsappMsg}`}
            target="_blank"
            rel="noreferrer"
            className="bg-emerald-50 text-emerald-800 border border-emerald-300 hover:bg-emerald-100 font-bold text-xs px-5 py-2.5 rounded-xl transition-colors flex items-center gap-2"
          >
            <MessageCircle className="w-4 h-4 text-emerald-600" />
            <span>Send Details to WhatsApp</span>
          </a>

          <button
            onClick={handlePrint}
            className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs px-4 py-2.5 rounded-xl transition-colors flex items-center gap-1.5"
          >
            <Printer className="w-4 h-4" />
            <span>Print Invoice</span>
          </button>
        </div>
      </div>

      {/* Ordered Items Table */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-4">
        <h3 className="font-extrabold text-slate-900 text-sm border-b border-slate-100 pb-3">
          Ordered Medicines & Items
        </h3>

        <div className="divide-y divide-slate-100 text-xs">
          {order.items.map((item, idx) => (
            <div key={idx} className="py-3 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg bg-slate-50 border border-slate-200 overflow-hidden shrink-0">
                  <img src={item.image} alt={item.productName} className="w-full h-full object-cover" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900">{item.productName}</h4>
                  <p className="text-slate-500 text-[11px]">
                    Salt: {item.genericName} • {item.packSize}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-slate-500 block text-[11px]">
                  {item.quantity} × PKR {item.unitPrice}
                </span>
                <strong className="text-slate-900 font-extrabold">PKR {item.subtotal}</strong>
              </div>
            </div>
          ))}
        </div>

        {/* Pricing Summary */}
        <div className="border-t border-slate-100 pt-4 space-y-1.5 text-xs text-slate-600 max-w-xs ml-auto">
          <div className="flex justify-between">
            <span>Subtotal:</span>
            <span className="font-bold text-slate-900">PKR {order.subtotal}</span>
          </div>
          <div className="flex justify-between">
            <span>Delivery Fee:</span>
            <span className="font-bold text-slate-900">
              {order.deliveryFee === 0 ? 'FREE' : `PKR ${order.deliveryFee}`}
            </span>
          </div>
          <div className="flex justify-between pt-2 border-t border-slate-200 text-slate-900 text-sm font-extrabold">
            <span>Total Payable:</span>
            <span className="text-emerald-800 font-black">PKR {order.total}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
