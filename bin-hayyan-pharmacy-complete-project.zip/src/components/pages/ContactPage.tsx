import React, { useState } from 'react';
import {
  MapPin,
  Phone,
  MessageCircle,
  Mail,
  Clock,
  ShieldCheck,
  Send,
  Building,
} from 'lucide-react';
import { usePharmacy } from '../../context/PharmacyContext';

export const ContactPage: React.FC = () => {
  const { settings, showToast } = usePharmacy();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    showToast('Your message has been sent to our pharmacy team.', 'success');
  };

  const cleanPhone = settings.whatsapp.replace(/[^0-9]/g, '');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto space-y-2">
        <span className="text-xs font-extrabold uppercase tracking-widest text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
          Islamabad Pharmacy Desk
        </span>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
          Contact Bin Hayyan Pharmacy
        </h1>
        <p className="text-xs sm:text-sm text-slate-500">
          Have an inquiry about medicine availability, prescription verification, or delivery timing?
          Reach our licensed pharmacy team directly.
        </p>
      </div>

      {/* Main Grid: Details & Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Contact Info Column */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
            <h3 className="font-extrabold text-slate-900 text-lg border-b border-slate-100 pb-3">
              Pharmacy Store Details
            </h3>

            <div className="space-y-4 text-xs">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <strong className="block text-slate-900 text-sm">Physical Address:</strong>
                  <p className="text-slate-600 mt-0.5 leading-relaxed">
                    {settings.address}, {settings.city}, Pakistan
                  </p>
                  <span className="text-[11px] text-emerald-800 font-semibold block mt-1">
                    Markaz F-7 / Blue Area commercial axis
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <strong className="block text-slate-900 text-sm">Pharmacy Helpline:</strong>
                  <a
                    href={`tel:${settings.phone}`}
                    className="text-emerald-700 font-bold hover:underline block mt-0.5"
                  >
                    {settings.phone}
                  </a>
                  <span className="text-[11px] text-slate-400">Available 7 days a week</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
                  <MessageCircle className="w-5 h-5" />
                </div>
                <div>
                  <strong className="block text-slate-900 text-sm">WhatsApp Orders & Verification:</strong>
                  <a
                    href={`https://wa.me/${cleanPhone}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-emerald-700 font-bold hover:underline block mt-0.5"
                  >
                    {settings.whatsapp}
                  </a>
                  <span className="text-[11px] text-slate-400">Instant prescription upload & chat</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <strong className="block text-slate-900 text-sm">Email Address:</strong>
                  <a
                    href={`mailto:${settings.email}`}
                    className="text-slate-600 hover:text-emerald-700 block mt-0.5"
                  >
                    {settings.email}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <strong className="block text-slate-900 text-sm">Dispensary Hours:</strong>
                  <p className="text-slate-600 mt-0.5 font-medium">{settings.openingHours}</p>
                </div>
              </div>
            </div>

            {/* Direct CTAs */}
            <div className="pt-4 border-t border-slate-100 flex gap-3">
              <a
                href={`tel:${settings.phone}`}
                className="flex-1 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors"
              >
                <Phone className="w-3.5 h-3.5" /> Call Pharmacist
              </a>
              <a
                href={`https://wa.me/${cleanPhone}`}
                target="_blank"
                rel="noreferrer"
                className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors shadow-sm"
              >
                <MessageCircle className="w-3.5 h-3.5" /> Order on WhatsApp
              </a>
            </div>
          </div>

          {/* DRAP License Badge */}
          <div className="bg-emerald-950 text-emerald-100 p-5 rounded-3xl border border-emerald-800 text-xs space-y-2">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <strong className="text-white text-sm">Regulatory Licensing</strong>
            </div>
            <p className="text-emerald-200/80 leading-relaxed text-[11px]">
              Drug Regulatory Authority of Pakistan (DRAP) & Islamabad Capital Territory Health Department:
              <br />
              Registration No: <span className="font-bold text-white">{settings.licenseNumber}</span>
            </p>
          </div>
        </div>

        {/* Contact Form & Map Column */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
            <h3 className="font-extrabold text-slate-900 text-lg border-b border-slate-100 pb-3">
              Send an Online Inquiry
            </h3>

            {sent ? (
              <div className="p-8 text-center bg-emerald-50 rounded-2xl border border-emerald-200 space-y-2">
                <ShieldCheck className="w-10 h-10 text-emerald-700 mx-auto" />
                <h4 className="font-bold text-slate-900">Message Received</h4>
                <p className="text-xs text-slate-600">
                  Thank you, {name}. Our on-duty pharmacist will contact you shortly.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Your Full Name *</label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Asim Raza"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Mobile / WhatsApp *</label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+92 3XX-XXXXXXX"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Email Address (Optional)</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Your Inquiry or Medicine Requirement *</label>
                  <textarea
                    required
                    rows={4}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Please specify your query regarding medicines, brand pricing, delivery sectors, or clinical devices..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-sm rounded-xl shadow-md transition-colors flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Inquiry to Dispensary</span>
                </button>
              </form>
            )}
          </div>

          {/* Interactive Google Maps Placeholder for Islamabad Markaz F-7 / Blue Area */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-3">
            <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <MapPin className="w-4 h-4 text-emerald-600" />
              Islamabad Location Map (Markaz F-7 / Blue Area)
            </h4>
            <div className="w-full h-56 rounded-2xl bg-slate-100 overflow-hidden relative border border-slate-200 flex items-center justify-center">
              <div className="text-center p-6 space-y-2">
                <Building className="w-10 h-10 text-emerald-700 mx-auto" />
                <p className="font-bold text-slate-800 text-xs">
                  Bin Hayyan Pharmacy — Islamabad Branch
                </p>
                <p className="text-[11px] text-slate-500 max-w-sm mx-auto">
                  Beverly Centre, Ground Floor, Markaz F-7 / Jinnah Avenue Axis, Islamabad Capital Territory
                </p>
                <a
                  href={`https://maps.google.com/?q=${encodeURIComponent('Beverly Centre Blue Area Islamabad')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-block bg-emerald-700 text-white text-[11px] font-bold px-3 py-1.5 rounded-lg shadow-sm hover:bg-emerald-800 transition-colors"
                >
                  Open in Google Maps
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
