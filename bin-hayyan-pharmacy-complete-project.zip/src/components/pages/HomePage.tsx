import React, { useState } from 'react';
import {
  FileText,
  ShoppingBag,
  Truck,
  Building,
  PhoneCall,
  ShieldCheck,
  ArrowRight,
  Thermometer,
  Clock,
  Sparkles,
  Search,
  CheckCircle,
  HelpCircle,
  ChevronRight,
  Stethoscope,
} from 'lucide-react';
import { usePharmacy } from '../../context/PharmacyContext';
import { ProductCard } from '../products/ProductCard';
import { ProductDetailModal } from '../products/ProductDetailModal';
import { Product, ProductCategory } from '../../types/pharmacy';

export const HomePage: React.FC = () => {
  const {
    products,
    navigateTo,
    setSelectedCategory,
    settings,
    searchQuery,
    setSearchQuery,
  } = usePharmacy();

  const [activeModalProduct, setActiveModalProduct] = useState<Product | null>(null);

  const featuredProducts = products.filter((p) => p.isFeatured && p.isActive).slice(0, 8);
  const prescriptionMedicines = products
    .filter((p) => p.requiresPrescription && p.isActive)
    .slice(0, 4);

  const categoriesList: { name: ProductCategory; icon: string; count: number; desc: string }[] = [
    { name: 'Medicines', icon: '💊', count: products.filter((p) => p.category.includes('Medicine') || p.category === 'Medicines').length, desc: 'General & specialized pharmaceuticals' },
    { name: 'Vitamins & Supplements', icon: '🌿', count: products.filter((p) => p.category === 'Vitamins & Supplements').length, desc: 'Immunity, zinc, bone health' },
    { name: 'Pain Relief', icon: '⚡', count: products.filter((p) => p.category === 'Pain Relief').length, desc: 'Analgesics, paracetamol, ibuprofen' },
    { name: 'Cold & Flu', icon: '☕', count: products.filter((p) => p.category === 'Cold & Flu').length, desc: 'Syrups, decongestants, inhalers' },
    { name: 'Digestive Health', icon: '🌱', count: products.filter((p) => p.category === 'Digestive Health').length, desc: 'Antacids, PPIs, stomach relief' },
    { name: 'Diabetes Care', icon: '🩸', count: products.filter((p) => p.category === 'Diabetes Care').length, desc: 'Meters, strips, oral hypoglycemics' },
    { name: 'Blood Pressure Care', icon: '❤️', count: products.filter((p) => p.category === 'Blood Pressure Care').length, desc: 'Monitors, antihypertensive drugs' },
    { name: 'Baby Care', icon: '🍼', count: products.filter((p) => p.category === 'Baby Care').length, desc: 'Infant drops, diapers, nutrition' },
    { name: 'Medical Devices', icon: '🩺', count: products.filter((p) => p.category === 'Medical Devices').length, desc: 'Nebulizers, BP units, diagnostics' },
    { name: 'Personal Care', icon: '✨', count: products.filter((p) => p.category === 'Personal Care').length, desc: 'Skin barrier, antiseptics, hygiene' },
    { name: 'First Aid', icon: '🩹', count: products.filter((p) => p.category === 'First Aid').length, desc: 'Bandages, Dettol, wound healing' },
  ];

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigateTo('shop', { q: searchQuery.trim() });
    } else {
      navigateTo('shop');
    }
  };

  const handleCategoryClick = (cat: ProductCategory) => {
    setSelectedCategory(cat);
    navigateTo('shop', { category: cat });
  };

  return (
    <div className="space-y-16 pb-16">
      {/* 1. Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-emerald-950 to-slate-900 text-white pt-12 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:20px_20px] pointer-events-none"></div>

        <div className="max-w-7xl mx-auto relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 bg-emerald-900/60 border border-emerald-500/30 text-emerald-300 text-xs font-bold px-3.5 py-1.5 rounded-full shadow-inner">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>DRAP Licensed Healthcare Facility • Markaz F-7, Islamabad</span>
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-[1.15] text-white">
              Your Trusted Pharmacy <br className="hidden sm:inline" />
              in <span className="text-emerald-400">Islamabad</span>
            </h1>

            <p className="text-sm sm:text-lg text-slate-300 leading-relaxed max-w-2xl">
              Quality medicines, healthcare products and convenient online ordering — delivered
              to your doorstep across Islamabad with strict cold-chain and pharmacist verification.
            </p>

            {/* Quick Hero Search Input */}
            <form
              onSubmit={handleHeroSearch}
              className="max-w-xl mx-auto lg:mx-0 flex items-center bg-white rounded-2xl p-1.5 shadow-2xl border border-emerald-500/20"
            >
              <div className="pl-3 text-slate-400">
                <Search className="w-5 h-5" />
              </div>
              <input
                type="text"
                placeholder="Search medicines, health products & more..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-none"
              />
              <button
                type="submit"
                className="bg-emerald-700 hover:bg-emerald-800 text-white text-xs sm:text-sm font-bold px-5 py-2.5 rounded-xl transition-all shadow-md shrink-0"
              >
                Find Medicine
              </button>
            </form>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                onClick={() => navigateTo('shop')}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm px-6 py-3.5 rounded-xl shadow-lg shadow-emerald-700/30 flex items-center gap-2 transition-all hover:scale-105 active:scale-95"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Shop Catalog</span>
              </button>

              <button
                onClick={() => navigateTo('prescription-upload')}
                className="bg-white/10 hover:bg-white/20 text-white border border-white/20 font-bold text-sm px-6 py-3.5 rounded-xl backdrop-blur flex items-center gap-2 transition-all hover:scale-105 active:scale-95"
              >
                <FileText className="w-4 h-4 text-emerald-300" />
                <span>Upload Prescription</span>
              </button>

              <button
                onClick={() => navigateTo('request-medicine')}
                className="text-xs text-emerald-300 hover:text-white font-semibold underline underline-offset-4"
              >
                Can't find your medicine? Request it here →
              </button>
            </div>
          </div>

          {/* Hero Feature Visual Card */}
          <div className="lg:col-span-5">
            <div className="relative bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-6 sm:p-8 shadow-2xl text-slate-200 space-y-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <div>
                  <span className="text-xs uppercase tracking-widest text-emerald-400 font-extrabold">
                    Live Dispatch Desk
                  </span>
                  <h3 className="text-lg font-bold text-white">Islamabad Local Delivery</h3>
                </div>
                <div className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] font-bold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                  Active Now
                </div>
              </div>

              <div className="space-y-3.5 text-xs">
                <div className="flex items-start gap-3 bg-white/5 p-3 rounded-xl border border-white/5">
                  <Truck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block font-semibold">45 - 90 Minutes Express Delivery</strong>
                    <span className="text-slate-400">
                      Covers F-6, F-7, F-8, F-10, F-11, G-6 to G-11, I Sectors & Blue Area
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-white/5 p-3 rounded-xl border border-white/5">
                  <Building className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block font-semibold">In-Store Pharmacy Pickup</strong>
                    <span className="text-slate-400">
                      Beverly Centre / Markaz F-7 Axis. Packaged ready in 20 minutes.
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-white/5 p-3 rounded-xl border border-white/5">
                  <Thermometer className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block font-semibold">Cold-Chain Refrigerator Guaranteed</strong>
                    <span className="text-slate-400">
                      Safe thermal pouches used for insulins, hormones, and pediatric vaccines.
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-white/10 flex items-center justify-between text-xs">
                <span className="text-slate-400">Helpline: {settings.phone}</span>
                <span className="text-emerald-400 font-bold">Open till 12:00 Midnight</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Important Homepage Feature Cards */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          <div
            onClick={() => navigateTo('shop')}
            className="cursor-pointer bg-white rounded-2xl p-4 border border-slate-200 shadow-md hover:border-emerald-500 hover:shadow-xl transition-all group text-center flex flex-col items-center justify-center"
          >
            <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center mb-2.5 group-hover:scale-110 transition-transform">
              <ShoppingBag className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-xs sm:text-sm text-slate-900 group-hover:text-emerald-700">
              Order Medicines Online
            </h4>
            <p className="text-[10px] text-slate-500 mt-0.5">Verified catalog</p>
          </div>

          <div
            onClick={() => navigateTo('prescription-upload')}
            className="cursor-pointer bg-white rounded-2xl p-4 border border-emerald-300 shadow-md hover:border-emerald-600 hover:shadow-xl transition-all group text-center flex flex-col items-center justify-center bg-gradient-to-b from-emerald-50/40 to-white"
          >
            <div className="w-12 h-12 rounded-xl bg-emerald-700 text-white flex items-center justify-center mb-2.5 group-hover:scale-110 transition-transform shadow-md">
              <FileText className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-xs sm:text-sm text-emerald-950 group-hover:text-emerald-700">
              Upload Prescription
            </h4>
            <p className="text-[10px] text-slate-500 mt-0.5">Pharmacist review</p>
          </div>

          <div
            onClick={() => navigateTo('policies', { tab: 'delivery' })}
            className="cursor-pointer bg-white rounded-2xl p-4 border border-slate-200 shadow-md hover:border-emerald-500 hover:shadow-xl transition-all group text-center flex flex-col items-center justify-center"
          >
            <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center mb-2.5 group-hover:scale-110 transition-transform">
              <Truck className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-xs sm:text-sm text-slate-900 group-hover:text-emerald-700">
              Fast Local Delivery
            </h4>
            <p className="text-[10px] text-slate-500 mt-0.5">Islamabad sectors</p>
          </div>

          <div
            onClick={() => navigateTo('contact')}
            className="cursor-pointer bg-white rounded-2xl p-4 border border-slate-200 shadow-md hover:border-emerald-500 hover:shadow-xl transition-all group text-center flex flex-col items-center justify-center"
          >
            <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center mb-2.5 group-hover:scale-110 transition-transform">
              <Building className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-xs sm:text-sm text-slate-900 group-hover:text-emerald-700">
              Pharmacy Pickup
            </h4>
            <p className="text-[10px] text-slate-500 mt-0.5">Markaz F-7 / Blue Area</p>
          </div>

          <div
            onClick={() => navigateTo('contact')}
            className="cursor-pointer bg-white rounded-2xl p-4 border border-slate-200 shadow-md hover:border-emerald-500 hover:shadow-xl transition-all group text-center flex flex-col items-center justify-center"
          >
            <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center mb-2.5 group-hover:scale-110 transition-transform">
              <Stethoscope className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-xs sm:text-sm text-slate-900 group-hover:text-emerald-700">
              Talk to Pharmacist
            </h4>
            <p className="text-[10px] text-slate-500 mt-0.5">Expert guidance</p>
          </div>

          <div
            onClick={() => navigateTo('policies', { tab: 'terms' })}
            className="cursor-pointer bg-white rounded-2xl p-4 border border-slate-200 shadow-md hover:border-emerald-500 hover:shadow-xl transition-all group text-center flex flex-col items-center justify-center"
          >
            <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center mb-2.5 group-hover:scale-110 transition-transform">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-xs sm:text-sm text-slate-900 group-hover:text-emerald-700">
              Secure Ordering
            </h4>
            <p className="text-[10px] text-slate-500 mt-0.5">COD & Bank Transfer</p>
          </div>
        </div>
      </section>

      {/* 3. Shop by Category Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-baseline justify-between mb-8 gap-2">
          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Shop by Category
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Explore authentic medicines, diagnostic tools, infant care, and personal wellness
            </p>
          </div>
          <button
            onClick={() => navigateTo('shop')}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 group"
          >
            <span>View All Categories</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {categoriesList.map((cat) => (
            <div
              key={cat.name}
              onClick={() => handleCategoryClick(cat.name)}
              className="cursor-pointer bg-white border border-slate-200 rounded-2xl p-4 text-center hover:border-emerald-500 hover:shadow-lg transition-all group flex flex-col justify-between"
            >
              <div>
                <span className="text-3xl block mb-2 group-hover:scale-110 transition-transform">
                  {cat.icon}
                </span>
                <h4 className="font-bold text-xs text-slate-900 group-hover:text-emerald-700 leading-snug">
                  {cat.name}
                </h4>
              </div>
              <p className="text-[10px] text-slate-400 mt-2 bg-slate-50 rounded-full py-0.5">
                {cat.count} items
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* 4. Prescription Upload Dedicated Feature Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-emerald-800 via-teal-900 to-slate-900 rounded-3xl p-8 sm:p-12 text-white shadow-xl relative overflow-hidden">
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-8 space-y-4">
              <span className="inline-block px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-400/30">
                Safe & Regulated Prescription Handling
              </span>

              <h3 className="text-2xl sm:text-4xl font-extrabold tracking-tight">
                Have a Doctor's Prescription Slip?
              </h3>

              <p className="text-slate-300 text-xs sm:text-sm leading-relaxed max-w-2xl">
                Upload your prescription easily via photo or PDF. Our qualified Islamabad pharmacist
                team reviews dosage, checks genuine inventory, verifies doctor instructions, and contacts
                you for immediate confirmation before packaging.
              </p>

              {/* 3 Step Process */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3">
                <div className="bg-white/10 backdrop-blur rounded-xl p-3 border border-white/10">
                  <span className="text-emerald-300 font-bold text-xs block mb-1">01. Upload</span>
                  <p className="text-[11px] text-slate-300">
                    Snap a phone photo or attach PDF of doctor prescription
                  </p>
                </div>
                <div className="bg-white/10 backdrop-blur rounded-xl p-3 border border-white/10">
                  <span className="text-emerald-300 font-bold text-xs block mb-1">02. Review</span>
                  <p className="text-[11px] text-slate-300">
                    Registered pharmacist checks dosage & calls for confirmation
                  </p>
                </div>
                <div className="bg-white/10 backdrop-blur rounded-xl p-3 border border-white/10">
                  <span className="text-emerald-300 font-bold text-xs block mb-1">03. Doorstep Delivery</span>
                  <p className="text-[11px] text-slate-300">
                    Temperature-controlled delivery right to your Islamabad address
                  </p>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => navigateTo('prescription-upload')}
                  className="bg-white text-emerald-900 hover:bg-emerald-50 font-extrabold text-sm px-6 py-3.5 rounded-xl shadow-lg transition-transform hover:scale-105 active:scale-95 flex items-center gap-2"
                >
                  <FileText className="w-4 h-4 text-emerald-700" />
                  <span>Upload Your Prescription Now</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="lg:col-span-4 hidden lg:flex justify-center">
              <div className="w-64 h-64 rounded-full bg-emerald-500/10 border-8 border-white/10 flex items-center justify-center p-6 text-center">
                <div className="space-y-2">
                  <ShieldCheck className="w-12 h-12 text-emerald-400 mx-auto" />
                  <p className="font-bold text-sm text-white">DRAP Compliant</p>
                  <p className="text-[11px] text-emerald-200">
                    No prescription medicine dispensed without pharmacist authorization
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Featured Authentic Medicines & Devices */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-baseline justify-between mb-8 gap-2">
          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Featured Products & Medical Essentials
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Popular medicines, daily vitamins, and home medical devices in stock in Islamabad
            </p>
          </div>
          <button
            onClick={() => navigateTo('shop')}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 group"
          >
            <span>View Full Catalog</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onQuickView={(p) => setActiveModalProduct(p)}
            />
          ))}
        </div>
      </section>

      {/* 6. Prescription Medicines Spotlight (Rx) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 bg-amber-50/60 rounded-3xl p-8 border border-amber-200/70">
        <div className="flex flex-col sm:flex-row items-baseline justify-between mb-6 gap-2">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
              <span className="text-xs font-bold text-amber-900 uppercase tracking-wider">
                Doctor Prescription (Rx) Required
              </span>
            </div>
            <h3 className="text-2xl font-black text-slate-900">
              Prescription Medicines Catalog
            </h3>
            <p className="text-xs text-slate-600 mt-0.5">
              Available for checkout. Dispensed only upon verified doctor prescription upload.
            </p>
          </div>
          <button
            onClick={() => handleCategoryClick('Prescription Medicines')}
            className="text-xs font-bold text-amber-900 hover:underline flex items-center gap-1"
          >
            <span>Browse All Prescription Drugs</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          {prescriptionMedicines.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onQuickView={(p) => setActiveModalProduct(p)}
            />
          ))}
        </div>
      </section>

      {/* 7. Why Bin Hayyan Pharmacy - Trust Pillars */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-extrabold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            Healthcare Standards
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-3">
            Why Islamabad Trusts Bin Hayyan Pharmacy
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-2">
            We adhere strictly to Pakistani drug safety protocols, cold-chain preservation, and registered
            pharmacist oversight for every single medicine we dispense.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-3">
            <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <Thermometer className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Cold-Chain Temperature Precision</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Biological medications, insulins, vaccines, and eye suspensions require steady 2°C to 8°C.
              Our pharmacy operates commercial pharmaceutical cooling units with digital data logging and
              insulated dispatch boxes.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-3">
            <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center">
              <Stethoscope className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">PharmD Qualified Consultations</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Every prescription order is reviewed by a registered PharmD pharmacist to cross-examine
              active salt strengths, drug interactions, and correct dosage schedules before releasing.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-3">
            <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
              <Truck className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Dedicated Islamabad Dispatch</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Direct riders operating across Islamabad sectors ensure rapid, discreet doorstep delivery
              within 45–90 minutes, eliminating long pharmacy queues.
            </p>
          </div>
        </div>
      </section>

      {/* 8. Local Islamabad Community Testimonials */}
      <section className="bg-slate-100/80 py-12 px-4 sm:px-6 lg:px-8 border-y border-slate-200">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8">
            <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900">
              Verified Feedback from Islamabad Customers
            </h3>
            <p className="text-xs text-slate-500 mt-1">Real reviews from local families and clinics</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm text-xs space-y-3">
              <div className="flex items-center gap-1 text-amber-400">
                {'★★★★★'}
              </div>
              <p className="text-slate-600 italic">
                “Living in F-10/1, getting authentic insulin in Islamabad with proper cold-chain packing
                used to be stressful. Bin Hayyan delivered it with an ice pack within 45 minutes.”
              </p>
              <div className="border-t border-slate-100 pt-2 text-slate-800 font-semibold">
                — Kamran Abbasi <span className="text-slate-400 font-normal">| Sector F-10, Islamabad</span>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm text-xs space-y-3">
              <div className="flex items-center gap-1 text-amber-400">
                {'★★★★★'}
              </div>
              <p className="text-slate-600 italic">
                “I uploaded my father’s cardiac prescription slip. The pharmacist called back within 15
                minutes to verify the exact milligram strength and dispatched it smoothly to Blue Area.”
              </p>
              <div className="border-t border-slate-100 pt-2 text-slate-800 font-semibold">
                — Dr. Naila Qureshi <span className="text-slate-400 font-normal">| Blue Area Axis</span>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm text-xs space-y-3">
              <div className="flex items-center gap-1 text-amber-400">
                {'★★★★★'}
              </div>
              <p className="text-slate-600 italic">
                “The Beurer BP monitor and diabetic test strips were 100% genuine with warranty cards.
                Cash on delivery checkout was effortless.”
              </p>
              <div className="border-t border-slate-100 pt-2 text-slate-800 font-semibold">
                — Salman Tareen <span className="text-slate-400 font-normal">| Sector G-11 Markaz</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Product Detail Modal */}
      <ProductDetailModal
        product={activeModalProduct}
        onClose={() => setActiveModalProduct(null)}
      />
    </div>
  );
};
