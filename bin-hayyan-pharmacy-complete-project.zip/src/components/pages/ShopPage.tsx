import React, { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, ArrowUpDown, Pill, FileText, Check, AlertCircle } from 'lucide-react';
import { usePharmacy } from '../../context/PharmacyContext';
import { ProductCard } from '../products/ProductCard';
import { ProductFilters } from '../products/ProductFilters';
import { ProductDetailModal } from '../products/ProductDetailModal';
import { Product, ProductCategory } from '../../types/pharmacy';

export const ShopPage: React.FC = () => {
  const {
    products,
    categories,
    selectedCategory,
    setSelectedCategory,
    searchQuery,
    setSearchQuery,
    pageParams,
    navigateTo,
  } = usePharmacy();

  const [activeModalProduct, setActiveModalProduct] = useState<Product | null>(null);
  const [filterPrescription, setFilterPrescription] = useState<'all' | 'otc' | 'rx'>('all');
  const [inStockOnly, setInStockOnly] = useState(false);
  const [maxPrice, setMaxPrice] = useState(15000);
  const [selectedBrand, setSelectedBrand] = useState('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-low' | 'price-high' | 'name' | 'popular'>('featured');
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  // Extract all unique brands
  const brands = useMemo(() => {
    const set = new Set<string>();
    products.forEach((p) => {
      if (p.brand) set.add(p.brand);
    });
    return Array.from(set).sort();
  }, [products]);

  // Filtered and sorted products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      if (!p.isActive) return false;

      // Category check
      if (selectedCategory !== 'All') {
        if (p.category !== selectedCategory && p.subcategory !== selectedCategory) {
          return false;
        }
      }

      // Prescription check
      if (filterPrescription === 'otc' && p.requiresPrescription) return false;
      if (filterPrescription === 'rx' && !p.requiresPrescription) return false;

      // Stock check
      if (inStockOnly && p.stock <= 0) return false;

      // Brand check
      if (selectedBrand && p.brand !== selectedBrand) return false;

      // Price check
      const currentPrice = p.discountPrice ?? p.price;
      if (currentPrice > maxPrice) return false;

      // Search query check (Search brand, generic name, product name, category, SKU, tags)
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchName = p.name.toLowerCase().includes(q);
        const matchGeneric = p.genericName.toLowerCase().includes(q);
        const matchBrand = p.brand.toLowerCase().includes(q);
        const matchCat = p.category.toLowerCase().includes(q);
        const matchSku = p.sku.toLowerCase().includes(q);
        const matchTags = p.tags.some((t) => t.toLowerCase().includes(q));
        if (!matchName && !matchGeneric && !matchBrand && !matchCat && !matchSku && !matchTags) {
          return false;
        }
      }

      return true;
    }).sort((a, b) => {
      const priceA = a.discountPrice ?? a.price;
      const priceB = b.discountPrice ?? b.price;

      if (sortBy === 'price-low') return priceA - priceB;
      if (sortBy === 'price-high') return priceB - priceA;
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      if (sortBy === 'popular') return (b.soldCount || 0) - (a.soldCount || 0);
      return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
    });
  }, [
    products,
    selectedCategory,
    filterPrescription,
    inStockOnly,
    selectedBrand,
    maxPrice,
    searchQuery,
    sortBy,
  ]);

  const handleResetFilters = () => {
    setSelectedCategory('All');
    setFilterPrescription('all');
    setInStockOnly(false);
    setMaxPrice(15000);
    setSelectedBrand('');
    setSearchQuery('');
    setSortBy('featured');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Page Title & Breadcrumb */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Pill className="w-6 h-6 text-emerald-600" />
            <span>Pharmacy Catalog & Medicines</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Browse authentic medicines, prescription items, health devices & nutrition in Islamabad
          </p>
        </div>

        {/* Quick Prescription Upload CTA */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigateTo('prescription-upload')}
            className="bg-emerald-50 text-emerald-800 border border-emerald-300 hover:bg-emerald-100 text-xs font-bold px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-sm transition-colors"
          >
            <FileText className="w-4 h-4 text-emerald-600" />
            <span>Upload Doctor's Slip</span>
          </button>
          <button
            onClick={() => navigateTo('request-medicine')}
            className="bg-slate-100 text-slate-700 hover:bg-slate-200 text-xs font-semibold px-4 py-2.5 rounded-xl transition-colors"
          >
            Request Unlisted
          </button>
        </div>
      </div>

      {/* Search & Active Tag Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by brand name, active salt, generic formula, or category..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
            >
              Clear
            </button>
          )}
        </div>

        {/* Sort & Filter controls */}
        <div className="flex items-center gap-2">
          {/* Mobile Filter Toggle */}
          <button
            onClick={() => setMobileFiltersOpen(!mobileFiltersOpen)}
            className="lg:hidden px-3 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Filters</span>
          </button>

          {/* Sort Dropdown */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-500 font-medium hidden sm:inline">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-transparent font-semibold text-slate-800 focus:outline-none cursor-pointer"
            >
              <option value="featured">Featured First</option>
              <option value="popular">Most Popular</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="name">Alphabetical (A-Z)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Catalog Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Desktop Filters Column */}
        <div className="hidden lg:block lg:col-span-1">
          <ProductFilters
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
            filterPrescription={filterPrescription}
            setFilterPrescription={setFilterPrescription}
            inStockOnly={inStockOnly}
            setInStockOnly={setInStockOnly}
            maxPrice={maxPrice}
            setMaxPrice={setMaxPrice}
            selectedBrand={selectedBrand}
            setSelectedBrand={setSelectedBrand}
            brands={brands}
            onReset={handleResetFilters}
          />
        </div>

        {/* Mobile Filters Drawer */}
        {mobileFiltersOpen && (
          <div className="lg:hidden col-span-1">
            <ProductFilters
              selectedCategory={selectedCategory}
              onSelectCategory={(cat) => {
                setSelectedCategory(cat);
                setMobileFiltersOpen(false);
              }}
              filterPrescription={filterPrescription}
              setFilterPrescription={setFilterPrescription}
              inStockOnly={inStockOnly}
              setInStockOnly={setInStockOnly}
              maxPrice={maxPrice}
              setMaxPrice={setMaxPrice}
              selectedBrand={selectedBrand}
              setSelectedBrand={setSelectedBrand}
              brands={brands}
              onReset={handleResetFilters}
            />
          </div>
        )}

        {/* Product Grid Column */}
        <div className="lg:col-span-3 space-y-4">
          {/* Active status bar */}
          <div className="flex items-center justify-between text-xs text-slate-500 px-1">
            <span>
              Showing <strong className="text-slate-900">{filteredProducts.length}</strong> products
              {selectedCategory !== 'All' && <span> in <strong className="text-emerald-700">{selectedCategory}</strong></span>}
            </span>

            {(selectedCategory !== 'All' || filterPrescription !== 'all' || selectedBrand || inStockOnly || searchQuery) && (
              <button
                onClick={handleResetFilters}
                className="text-emerald-700 hover:underline font-semibold"
              >
                Clear all filters
              </button>
            )}
          </div>

          {/* Grid of Products */}
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onQuickView={(p) => setActiveModalProduct(p)}
                />
              ))}
            </div>
          ) : (
            /* Empty state */
            <div className="bg-white border border-slate-200 rounded-3xl p-12 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                <AlertCircle className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">
                No matching medicines or products found
              </h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                We couldn't find any products matching your current filters or search term.
                You can reset your filters or request our pharmacy team to source this medicine for you.
              </p>
              <div className="flex justify-center gap-3 pt-2">
                <button
                  onClick={handleResetFilters}
                  className="bg-emerald-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl hover:bg-emerald-800 transition-colors"
                >
                  Reset All Filters
                </button>
                <button
                  onClick={() => navigateTo('request-medicine')}
                  className="bg-slate-100 text-slate-700 text-xs font-semibold px-4 py-2.5 rounded-xl hover:bg-slate-200 transition-colors"
                >
                  Request Unlisted Medicine
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Product Detail Modal */}
      <ProductDetailModal
        product={activeModalProduct}
        onClose={() => setActiveModalProduct(null)}
      />
    </div>
  );
};
