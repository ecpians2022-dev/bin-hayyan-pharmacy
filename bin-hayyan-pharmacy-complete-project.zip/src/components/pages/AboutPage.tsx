import React from 'react';
import {
  ShieldCheck,
  Award,
  Thermometer,
  Clock,
  Heart,
  CheckCircle,
  Stethoscope,
  Building,
} from 'lucide-react';
import { usePharmacy } from '../../context/PharmacyContext';

export const AboutPage: React.FC = () => {
  const { settings, navigateTo } = usePharmacy();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      {/* Hero Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-extrabold uppercase tracking-widest text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
          Rooted in Clinical Integrity
        </span>
        <h1 className="text-3xl sm:text-5xl font-black text-slate-900 tracking-tight">
          About Bin Hayyan Pharmacy
        </h1>
        <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
          Inspired by Jabir ibn Hayyan, the father of modern chemistry and pharmacology,
          Bin Hayyan Pharmacy was established in Islamabad with an uncompromising commitment to authentic
          medicines, precision cold-chain storage, and qualified patient care.
        </p>
      </div>

      {/* Narrative Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-4 text-xs sm:text-sm text-slate-600 leading-relaxed">
          <h2 className="text-xl sm:text-2xl font-black text-slate-900">
            A Trusted Healthcare Institution in the Capital
          </h2>
          <p>
            Operating in the heart of Islamabad, Pakistan, Bin Hayyan Pharmacy bridges the gap between traditional
            community pharmacies and modern digital healthcare delivery. In an era where counterfeit drugs and
            unregulated storage pose real risks to public health, we operate strictly under the regulatory oversight
            of the Drug Regulatory Authority of Pakistan (DRAP).
          </p>
          <p>
            Every product in our inventory is procured directly from licensed multinational and national
            manufacturers — including GlaxoSmithKline (GSK), Abbott Laboratories, Getz Pharma, Merck, Searle,
            and Roche. We refuse third-party gray-market goods and inspect batch expiration certificates for every consignment.
          </p>

          <div className="pt-2">
            <h4 className="font-bold text-slate-900 text-sm mb-2">Our Operating Principles:</h4>
            <ul className="space-y-2 text-xs">
              <li className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Zero tolerance for counterfeit medications or expired batches</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Licensed PharmD pharmacists on duty for all prescription reviews</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Digital temperature logging for insulin, vaccines, and biologics</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Dedicated express motorcycle delivery network across Islamabad</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Visual Box */}
        <div className="bg-gradient-to-br from-emerald-900 to-slate-900 text-white p-8 rounded-3xl shadow-xl space-y-6">
          <div className="space-y-2">
            <span className="text-xs uppercase font-extrabold tracking-wider text-emerald-400">
              Dispensary Standards
            </span>
            <h3 className="text-xl font-bold">State-of-the-Art Pharmacy Infrastructure</h3>
          </div>

          <div className="space-y-4 text-xs text-slate-300">
            <div className="flex items-start gap-3 bg-white/10 p-3.5 rounded-xl border border-white/10">
              <Thermometer className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white block font-semibold">24/7 Monitored Cold-Chain Refrigerator</strong>
                <p className="text-[11px] text-slate-300 mt-0.5">
                  Commercial pharmaceutical chillers backed by uninterruptible generators ensure vaccines and insulins
                  never experience thermal deviation.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 bg-white/10 p-3.5 rounded-xl border border-white/10">
              <Stethoscope className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white block font-semibold">Pharmacist Verification Protocol</strong>
                <p className="text-[11px] text-slate-300 mt-0.5">
                  Prescription orders require doctor slip validation, cross-checking dosage and interactions before release.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 bg-white/10 p-3.5 rounded-xl border border-white/10">
              <Building className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white block font-semibold">Islamabad Hub Location</strong>
                <p className="text-[11px] text-slate-300 mt-0.5">
                  Located strategically on the Beverly Centre / F-7 Blue Area axis for rapid dispatch across all sectors.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Box */}
      <div className="bg-emerald-50 border border-emerald-200 rounded-3xl p-8 text-center space-y-4">
        <h3 className="text-xl sm:text-2xl font-black text-slate-900">
          Need Guidance from Our Clinical Pharmacist?
        </h3>
        <p className="text-xs sm:text-sm text-slate-600 max-w-xl mx-auto">
          Whether you need to confirm drug availability, inquire about generic equivalents, or schedule
          monthly refills for elderly parents in Islamabad, we are here to assist.
        </p>
        <div className="flex justify-center gap-3 pt-2">
          <button
            onClick={() => navigateTo('prescription-upload')}
            className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs sm:text-sm px-6 py-3 rounded-xl shadow-md transition-colors"
          >
            Upload Doctor's Prescription
          </button>
          <button
            onClick={() => navigateTo('contact')}
            className="bg-white text-slate-800 border border-slate-300 font-semibold text-xs sm:text-sm px-6 py-3 rounded-xl hover:bg-slate-50 transition-colors"
          >
            Contact Dispensary
          </button>
        </div>
      </div>
    </div>
  );
};
