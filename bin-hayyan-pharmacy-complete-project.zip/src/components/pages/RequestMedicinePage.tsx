import React, { useState } from 'react';
import { Pill, Send, CheckCircle2, Phone, AlertCircle, MessageCircle } from 'lucide-react';
import { usePharmacy } from '../../context/PharmacyContext';

export const RequestMedicinePage: React.FC = () => {
  const { submitMedicineRequest, currentUser, settings, navigateTo, showToast } = usePharmacy();

  const [customerName, setCustomerName] = useState(currentUser?.name || '');
  const [phone, setPhone] = useState(currentUser?.phone || '+92 300 ');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [medicineName, setMedicineName] = useState('');
  const [strengthRequired, setStrengthRequired] = useState('');
  const [quantity, setQuantity] = useState('1 Pack');
  const [doctorPrescribed, setDoctorPrescribed] = useState(true);
  const [notes, setNotes] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!medicineName.trim()) {
      showToast('Please specify the medicine name.', 'error');
      return;
    }
    if (!phone.trim()) {
      showToast('Please provide your phone number.', 'error');
      return;
    }

    submitMedicineRequest({
      customerName,
      phone,
      email,
      medicineName,
      strengthRequired,
      quantity,
      doctorPrescribed,
      notes,
    });

    setSubmitted(true);
  };

  const cleanPhone = settings.whatsapp.replace(/[^0-9]/g, '');
  const whatsappMsg = encodeURIComponent(
    `Salam Bin Hayyan Pharmacy, I am searching for an unlisted medicine: ${medicineName} (${strengthRequired}). Is it available with your Islamabad suppliers?`
  );

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
      {/* Title */}
      <div className="text-center max-w-xl mx-auto space-y-2">
        <div className="inline-flex items-center gap-1.5 bg-emerald-50 text-emerald-800 text-xs font-bold px-3 py-1 rounded-full border border-emerald-200">
          <Pill className="w-4 h-4 text-emerald-600" />
          <span>Medicine Sourcing Desk</span>
        </div>
        <h1 className="text-3xl font-black text-slate-900 tracking-tight">
          Request Unlisted Medicine
        </h1>
        <p className="text-xs sm:text-sm text-slate-500">
          Can't find a specialized medicine or imported brand? Let our Islamabad procurement team source it
          from authorized pharmaceutical distributors.
        </p>
      </div>

      {submitted ? (
        <div className="bg-white border border-emerald-200 rounded-3xl p-8 sm:p-10 shadow-xl text-center space-y-6">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-inner">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <h2 className="text-2xl font-black text-slate-900">
              Request Received Successfully
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
              Our inventory officer is contacting authorized pharmaceutical distributors across Islamabad and Rawalpindi.
              We will inform you via call or WhatsApp at <strong>{phone}</strong> regarding availability, batch expiry, and pricing.
            </p>
          </div>

          <div className="flex justify-center gap-3 pt-2">
            <button
              onClick={() => navigateTo('shop')}
              className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs sm:text-sm px-6 py-3 rounded-xl shadow-md transition-colors"
            >
              Back to Catalog
            </button>
            <a
              href={`https://wa.me/${cleanPhone}?text=${whatsappMsg}`}
              target="_blank"
              rel="noreferrer"
              className="bg-emerald-50 text-emerald-800 border border-emerald-300 font-bold text-xs sm:text-sm px-6 py-3 rounded-xl transition-colors flex items-center gap-2"
            >
              <MessageCircle className="w-4 h-4 text-emerald-600" />
              <span>Inquire on WhatsApp</span>
            </a>
          </div>
        </div>
      ) : (
        <form
          onSubmit={handleSubmit}
          className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-md space-y-6 text-xs"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Your Full Name *</label>
              <input
                type="text"
                required
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="e.g. Tariq Mehmood"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Phone / WhatsApp Number *</label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+92 3XX-XXXXXXX"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-bold text-slate-700 mb-1">Medicine Name & Brand *</label>
              <input
                type="text"
                required
                value={medicineName}
                onChange={(e) => setMedicineName(e.target.value)}
                placeholder="e.g. Salofalk, Nexium, Keppra, specialized insulin..."
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Required Strength / Dosage</label>
              <input
                type="text"
                value={strengthRequired}
                onChange={(e) => setStrengthRequired(e.target.value)}
                placeholder="e.g. 500mg, 10mg/ml, Granules..."
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Quantity Needed</label>
              <input
                type="text"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                placeholder="e.g. 2 Boxes, 30 Tablets..."
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="flex items-center gap-2 font-semibold text-slate-800 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={doctorPrescribed}
                  onChange={(e) => setDoctorPrescribed(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 accent-emerald-600"
                />
                <span>I have a valid doctor prescription for this medicine</span>
              </label>
            </div>

            <div className="sm:col-span-2">
              <label className="block font-bold text-slate-700 mb-1">Additional Notes / Doctor Name</label>
              <textarea
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Indicate urgency or hospital / doctor prescription details..."
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-sm rounded-xl shadow-md transition-colors flex items-center justify-center gap-2"
          >
            <Send className="w-4 h-4" />
            <span>Submit Sourcing Request</span>
          </button>
        </form>
      )}
    </div>
  );
};
