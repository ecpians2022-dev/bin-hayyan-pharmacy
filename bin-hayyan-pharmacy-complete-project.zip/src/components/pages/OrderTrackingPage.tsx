import React, { useState, useEffect } from 'react';
import {
  Search,
  MapPin,
  Clock,
  CheckCircle2,
  Circle,
  Truck,
  Package,
  FileCheck,
  ShieldAlert,
  ArrowRight,
  Phone,
} from 'lucide-react';
import { usePharmacy } from '../../context/PharmacyContext';
import { Order, OrderStatus } from '../../types/pharmacy';

export const OrderTrackingPage: React.FC = () => {
  const { orders, pageParams, settings, navigateTo } = usePharmacy();
  const [searchCode, setSearchCode] = useState(pageParams.orderNumber || pageParams.orderId || '');
  const [matchedOrder, setMatchedOrder] = useState<Order | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  useEffect(() => {
    if (pageParams.orderNumber || pageParams.orderId) {
      const code = (pageParams.orderNumber || pageParams.orderId).trim();
      setSearchCode(code);
      handleSearch(code);
    }
  }, [pageParams]);

  const handleSearch = (codeToSearch?: string) => {
    const q = (codeToSearch ?? searchCode).trim().toLowerCase();
    setHasSearched(true);

    if (!q) {
      setMatchedOrder(null);
      return;
    }

    const found = orders.find(
      (o) =>
        o.orderNumber.toLowerCase() === q ||
        o.id.toLowerCase() === q ||
        o.customerPhone.replace(/[^0-9]/g, '').includes(q.replace(/[^0-9]/g, ''))
    );
    setMatchedOrder(found || null);
  };

  const statusSteps: { status: OrderStatus; label: string; desc: string }[] = [
    { status: 'Pending', label: 'Order Received', desc: 'Received at Bin Hayyan dispensary' },
    { status: 'Confirmed', label: 'Order Confirmed', desc: 'Pharmacist verification completed' },
    { status: 'Preparing', label: 'Preparing & Packing', desc: 'Medicines sealed with cold-chain care' },
    { status: 'Out for Delivery', label: 'Out for Delivery', desc: 'Rider dispatched in Islamabad' },
    { status: 'Delivered', label: 'Delivered', desc: 'Delivered safely to recipient' },
  ];

  const getStepState = (stepStatus: OrderStatus, currentStatus: OrderStatus) => {
    const orderSequence: OrderStatus[] = [
      'Pending',
      'Prescription Review',
      'Confirmed',
      'Preparing',
      'Ready for Pickup',
      'Out for Delivery',
      'Delivered',
    ];

    if (currentStatus === 'Cancelled' || currentStatus === 'Rejected') {
      return 'cancelled';
    }

    const currentIndex = orderSequence.indexOf(currentStatus);
    const stepIndex = orderSequence.indexOf(stepStatus);

    if (stepIndex < currentIndex) return 'completed';
    if (stepIndex === currentIndex) return 'current';
    return 'upcoming';
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Title */}
      <div className="text-center max-w-xl mx-auto space-y-2">
        <div className="inline-flex items-center gap-1.5 bg-emerald-50 text-emerald-800 text-xs font-bold px-3 py-1 rounded-full border border-emerald-200">
          <Truck className="w-4 h-4 text-emerald-600" />
          <span>Islamabad Real-Time Dispatch</span>
        </div>
        <h1 className="text-3xl font-black text-slate-900 tracking-tight">
          Track Your Order
        </h1>
        <p className="text-xs sm:text-sm text-slate-500">
          Enter your Bin Hayyan order number (e.g. <strong>BHP-2026-00101</strong>) or your phone number
        </p>
      </div>

      {/* Search Bar */}
      <div className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-6 shadow-md max-w-2xl mx-auto">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSearch();
          }}
          className="flex flex-col sm:flex-row gap-2"
        >
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="e.g. BHP-2026-00101 or +92 321 9876543"
              value={searchCode}
              onChange={(e) => setSearchCode(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white"
            />
          </div>
          <button
            type="submit"
            className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs sm:text-sm px-6 py-3 rounded-xl shadow-md transition-colors"
          >
            Track Status
          </button>
        </form>

        {/* Quick Demo links */}
        <div className="mt-3 flex items-center justify-center gap-2 text-xs text-slate-500">
          <span>Try Demo:</span>
          <button
            type="button"
            onClick={() => {
              setSearchCode('BHP-2026-00101');
              handleSearch('BHP-2026-00101');
            }}
            className="text-emerald-700 font-semibold underline hover:text-emerald-800"
          >
            BHP-2026-00101 (Out for Delivery)
          </button>
          <span>•</span>
          <button
            type="button"
            onClick={() => {
              setSearchCode('BHP-2026-00102');
              handleSearch('BHP-2026-00102');
            }}
            className="text-emerald-700 font-semibold underline hover:text-emerald-800"
          >
            BHP-2026-00102 (Delivered)
          </button>
        </div>
      </div>

      {/* Matched Order View */}
      {matchedOrder ? (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-lg space-y-8 animate-in fade-in duration-200">
          {/* Header Summary */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-100 gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs uppercase font-extrabold tracking-wider bg-emerald-100 text-emerald-800 px-2.5 py-0.5 rounded-md">
                  {matchedOrder.orderNumber}
                </span>
                <span className="text-xs font-bold text-slate-700">
                  Status: <strong className="text-emerald-700">{matchedOrder.orderStatus}</strong>
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Placed on {new Date(matchedOrder.createdAt).toLocaleDateString()} at {new Date(matchedOrder.createdAt).toLocaleTimeString()}
              </p>
            </div>

            <div className="text-left sm:text-right text-xs">
              <span className="text-slate-400 block text-[11px]">Estimated Islamabad Delivery</span>
              <strong className="text-sm font-bold text-slate-900 text-emerald-800">
                {matchedOrder.estimatedDelivery || 'Within 60 minutes'}
              </strong>
            </div>
          </div>

          {/* Visual Step-by-Step Timeline */}
          <div className="space-y-4">
            <h3 className="font-extrabold text-slate-900 text-sm">
              Live Progress Timeline
            </h3>

            <div className="relative pl-6 sm:pl-8 space-y-6 before:absolute before:left-3 sm:before:left-4 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
              {statusSteps.map((step, idx) => {
                const state = getStepState(step.status, matchedOrder.orderStatus);
                const isCompleted = state === 'completed';
                const isCurrent = state === 'current';

                return (
                  <div key={idx} className="relative flex items-start gap-4">
                    {/* Step Icon */}
                    <div
                      className={`absolute -left-6 sm:-left-8 w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center font-bold text-xs transition-colors ${
                        isCompleted
                          ? 'bg-emerald-600 text-white'
                          : isCurrent
                          ? 'bg-emerald-100 text-emerald-800 ring-4 ring-emerald-500/20'
                          : 'bg-slate-100 text-slate-400'
                      }`}
                    >
                      {isCompleted ? (
                        <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                      ) : isCurrent ? (
                        <div className="w-2.5 h-2.5 rounded-full bg-emerald-600 animate-ping"></div>
                      ) : (
                        <Circle className="w-3.5 h-3.5" />
                      )}
                    </div>

                    <div className="pl-3 sm:pl-4 space-y-0.5">
                      <h4
                        className={`text-xs sm:text-sm font-bold ${
                          isCompleted || isCurrent ? 'text-slate-900' : 'text-slate-400'
                        }`}
                      >
                        {step.label}
                      </h4>
                      <p className="text-[11px] text-slate-500">{step.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Detailed Audit Events Log */}
          {matchedOrder.timeline.length > 0 && (
            <div className="border-t border-slate-100 pt-6">
              <h4 className="font-bold text-slate-900 text-xs mb-3">
                Dispatch Logs & Checkpoints
              </h4>
              <div className="bg-slate-50 rounded-2xl p-4 divide-y divide-slate-100 text-xs space-y-2">
                {matchedOrder.timeline.map((event, i) => (
                  <div key={i} className="pt-2 first:pt-0 flex items-start justify-between gap-4">
                    <div>
                      <span className="font-semibold text-slate-800">{event.status}: </span>
                      <span className="text-slate-600">{event.note}</span>
                      {event.actor && (
                        <span className="text-[10px] text-emerald-700 block">Verified by {event.actor}</span>
                      )}
                    </div>
                    <span className="text-[10px] text-slate-400 shrink-0">
                      {new Date(event.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Recipient & Destination Box */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200 text-xs">
            <div>
              <strong className="block text-emerald-950 mb-1 flex items-center gap-1.5 font-bold">
                <MapPin className="w-3.5 h-3.5 text-emerald-700" /> Destination in Islamabad:
              </strong>
              <p className="text-emerald-900">
                {matchedOrder.shippingAddress.streetAddress}, Sector {matchedOrder.shippingAddress.sectorArea}, Islamabad
              </p>
              {matchedOrder.shippingAddress.deliveryNotes && (
                <p className="text-emerald-700 text-[11px] mt-1 italic">
                  Note: {matchedOrder.shippingAddress.deliveryNotes}
                </p>
              )}
            </div>

            <div>
              <strong className="block text-emerald-950 mb-1 flex items-center gap-1.5 font-bold">
                <Phone className="w-3.5 h-3.5 text-emerald-700" /> Recipient Details:
              </strong>
              <p className="text-emerald-900">
                {matchedOrder.customerName} ({matchedOrder.customerPhone})
              </p>
              <p className="text-emerald-800 text-[11px] mt-1">
                Payment: <strong>{matchedOrder.paymentMethod} (PKR {matchedOrder.total})</strong>
              </p>
            </div>
          </div>
        </div>
      ) : hasSearched ? (
        <div className="bg-white border border-slate-200 rounded-3xl p-10 text-center space-y-3">
          <p className="text-base font-bold text-slate-800">
            No active order found with reference: “{searchCode}”
          </p>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Please double check the order number sent in your confirmation message, or call our pharmacist
            dispatch desk at {settings.phone}.
          </p>
        </div>
      ) : null}
    </div>
  );
};
