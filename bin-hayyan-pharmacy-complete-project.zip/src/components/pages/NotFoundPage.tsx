import React from 'react';
import { Pill, Search, ArrowRight, Home } from 'lucide-react';
import { usePharmacy } from '../../context/PharmacyContext';

export const NotFoundPage: React.FC = () => {
  const { navigateTo } = usePharmacy();

  return (
    <div className="max-w-2xl mx-auto px-4 py-24 text-center space-y-6">
      <div className="w-20 h-20 rounded-3xl bg-emerald-50 text-emerald-700 flex items-center justify-center mx-auto border border-emerald-200 shadow-sm">
        <Pill className="w-10 h-10 rotate-45" />
      </div>

      <div className="space-y-2">
        <span className="text-xs font-black uppercase tracking-widest text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full">
          Error 404
        </span>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
          Page or Medicine Not Found
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto leading-relaxed">
          The requested pharmacy page could not be located. It may have moved or the link might be expired.
          You can search our Islamabad catalog or return to the main dispensary page.
        </p>
      </div>

      <div className="flex flex-wrap justify-center gap-3 pt-2">
        <button
          onClick={() => navigateTo('home')}
          className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs sm:text-sm px-6 py-3 rounded-xl shadow-md transition-colors flex items-center gap-2"
        >
          <Home className="w-4 h-4" />
          <span>Return to Homepage</span>
        </button>

        <button
          onClick={() => navigateTo('shop')}
          className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs sm:text-sm px-6 py-3 rounded-xl transition-colors flex items-center gap-2"
        >
          <Search className="w-4 h-4" />
          <span>Search Products</span>
        </button>
      </div>
    </div>
  );
};
