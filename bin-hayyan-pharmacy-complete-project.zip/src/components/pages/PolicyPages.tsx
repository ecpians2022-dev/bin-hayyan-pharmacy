import React, { useState } from 'react';
import { ShieldCheck, Truck, RotateCcw, Lock, FileText } from 'lucide-react';
import { usePharmacy } from '../../context/PharmacyContext';

export const PolicyPages: React.FC = () => {
  const { pageParams, deliveryZones, settings } = usePharmacy();
  const [activeTab, setActiveTab] = useState<'delivery' | 'refund' | 'privacy' | 'terms'>(
    pageParams.tab || 'delivery'
  );

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
      {/* Navigation Tabs */}
      <div className="flex flex-wrap items-center justify-center gap-2 border-b border-slate-200 pb-4">
        <button
          onClick={() => setActiveTab('delivery')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors ${
            activeTab === 'delivery'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Truck className="w-4 h-4" /> Delivery Information
        </button>
        <button
          onClick={() => setActiveTab('refund')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors ${
            activeTab === 'refund'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <RotateCcw className="w-4 h-4" /> Refund & Safety Return Policy
        </button>
        <button
          onClick={() => setActiveTab('privacy')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors ${
            activeTab === 'privacy'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Lock className="w-4 h-4" /> Privacy & Prescription Data
        </button>
        <button
          onClick={() => setActiveTab('terms')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors ${
            activeTab === 'terms'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <FileText className="w-4 h-4" /> Terms & Conditions
        </button>
      </div>

      {/* TAB 1: Delivery Information */}
      {activeTab === 'delivery' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-10 shadow-sm space-y-6 text-xs sm:text-sm text-slate-700 leading-relaxed">
          <div className="border-b border-slate-100 pb-4">
            <h1 className="text-2xl font-black text-slate-900">
              Islamabad Delivery Information & Schedule
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Real-time local dispatch across Islamabad Capital Territory (ICT)
            </p>
          </div>

          <div className="space-y-4">
            <h3 className="font-bold text-slate-900 text-base">Delivery Zones & Charges</h3>
            <p>
              Bin Hayyan Pharmacy operates an in-house dispatch service equipped with temperature-controlled thermal
              carrying packs. Delivery charges are calculated based on your sector zone in Islamabad:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {deliveryZones.map((zone) => (
                <div key={zone.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                  <h4 className="font-extrabold text-slate-900 text-sm text-emerald-800">{zone.name}</h4>
                  <p className="text-xs font-bold text-slate-800">
                    Fee: PKR {zone.fee} • Est: {zone.estimatedTime}
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Sectors: {zone.sectors.join(', ')}
                  </p>
                </div>
              ))}
            </div>

            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-950 font-semibold text-xs">
              ⚡ Free Doorstep Delivery: Any order with subtotal exceeding <strong>PKR {settings.freeDeliveryThreshold}</strong> qualifies for 100% free delivery across all Islamabad zones!
            </div>

            <h3 className="font-bold text-slate-900 text-base pt-3">Cold-Chain Handling for Insulin & Vaccines</h3>
            <p>
              All temperature-sensitive medicines (2°C–8°C) are dispatched using specialized pharmaceutical
              cool-boxes lined with conditioned ice packs. Our delivery riders are trained to hand over biological
              medications directly to the recipient to ensure immediate refrigeration.
            </p>

            <h3 className="font-bold text-slate-900 text-base pt-3">Pharmacy In-Store Pickup</h3>
            <p>
              Customers may also select <strong>Pharmacy Pickup</strong> at our Markaz F-7 / Beverly Centre branch.
              Orders placed for pickup are typically packaged and verified within 20 minutes with zero delivery surcharge.
            </p>
          </div>
        </div>
      )}

      {/* TAB 2: Refund & Return Policy */}
      {activeTab === 'refund' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-10 shadow-sm space-y-6 text-xs sm:text-sm text-slate-700 leading-relaxed">
          <div className="border-b border-slate-100 pb-4">
            <h1 className="text-2xl font-black text-slate-900">
              Medicine Refund & Patient Safety Return Policy
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Compliant with the Drug Regulatory Authority of Pakistan (DRAP) Healthcare Safety Guidelines
            </p>
          </div>

          <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl text-amber-950 text-xs leading-relaxed space-y-1.5">
            <strong className="block font-bold text-amber-900">Pharmaceutical Safety Mandate:</strong>
            <p>
              Under medical drug safety laws, dispensed medicines cannot be restocked or returned once
              they have left the custody of the licensed dispensary and the seal has been opened.
              This prevents any risk of counterfeit substitution, storage tampering, or accidental thermal degradation.
            </p>
          </div>

          <div className="space-y-4">
            <h3 className="font-bold text-slate-900 text-base">Eligible Return Scenarios</h3>
            <p>You are entitled to an immediate replacement or full refund if:</p>
            <ul className="list-disc pl-5 space-y-1.5 text-xs text-slate-600">
              <li>The delivered product was damaged during rider transit (e.g., shattered vial, leaked bottle).</li>
              <li>The product delivered differs in strength or generic salt from what was verified on your confirmed order.</li>
              <li>The package is unopened and returned to our rider at the exact time of delivery inspection.</li>
            </ul>

            <h3 className="font-bold text-slate-900 text-base pt-3">Medical Devices & Diagnostics</h3>
            <p>
              Blood glucose meters (Accu-Chek), blood pressure monitors (Beurer), and nebulizers carry official manufacturer
              warranties. Unopened devices in pristine box condition can be exchanged within 48 hours of purchase.
            </p>

            <h3 className="font-bold text-slate-900 text-base pt-3">Refund Processing Method</h3>
            <p>
              Approved refunds are credited back via Direct Bank Transfer (IBAN) or Cash on Delivery reversal within
              24 to 48 hours following inspection by our lead pharmacist.
            </p>
          </div>
        </div>
      )}

      {/* TAB 3: Privacy Policy */}
      {activeTab === 'privacy' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-10 shadow-sm space-y-6 text-xs sm:text-sm text-slate-700 leading-relaxed">
          <div className="border-b border-slate-100 pb-4">
            <h1 className="text-2xl font-black text-slate-900">
              Privacy Policy & Clinical Record Protection
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Confidentiality standards for patient data and prescription files
            </p>
          </div>

          <div className="space-y-4">
            <p>
              Bin Hayyan Pharmacy respects patient confidentiality and the sensitive nature of medical prescriptions.
              This policy explains how personal and medical information is collected, safeguarded, and handled.
            </p>

            <h3 className="font-bold text-slate-900 text-base">Prescription Document Privacy</h3>
            <p>
              Uploaded prescription images and PDF documents are strictly confidential. They are stored in access-controlled
              storage and accessible exclusively by registered pharmacy staff for clinical verification and dispensing.
              We will never share or sell patient medical records to third-party marketing companies.
            </p>

            <h3 className="font-bold text-slate-900 text-base">Contact Information Usage</h3>
            <p>
              Your contact phone number and Islamabad address are utilized strictly for order verification,
              pharmacist consultations, and rider delivery navigation.
            </p>
          </div>
        </div>
      )}

      {/* TAB 4: Terms & Conditions */}
      {activeTab === 'terms' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-10 shadow-sm space-y-6 text-xs sm:text-sm text-slate-700 leading-relaxed">
          <div className="border-b border-slate-100 pb-4">
            <h1 className="text-2xl font-black text-slate-900">
              Terms & Conditions
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Terms of service governing Bin Hayyan Pharmacy orders and interactions
            </p>
          </div>

          <div className="space-y-4">
            <h3 className="font-bold text-slate-900 text-base">Medical Disclaimer</h3>
            <p>
              Information, descriptions, and active ingredients listed on this platform are for general informational
              purposes only and do not replace professional diagnosis, treatment, or advice from a registered PMDC/PMC
              medical practitioner. Always consult your doctor before starting or discontinuing any medication.
            </p>

            <h3 className="font-bold text-slate-900 text-base">Prescription Dispensing Authority</h3>
            <p>
              Bin Hayyan Pharmacy reserves the right to refuse or withhold dispensing of any prescription medication
              if a valid prescription is not provided, if doctor registration cannot be verified, or if dosage exceeds
              safe clinical thresholds as determined by our licensed pharmacist.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
