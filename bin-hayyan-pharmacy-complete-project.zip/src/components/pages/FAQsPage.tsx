import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronUp, MessageCircle, Phone } from 'lucide-react';
import { usePharmacy } from '../../context/PharmacyContext';
import { StorageService } from '../../services/storage';

export const FAQsPage: React.FC = () => {
  const { settings, navigateTo } = usePharmacy();
  const faqs = StorageService.getFAQs();
  const [openId, setOpenId] = useState<string | null>(faqs[0]?.id || null);

  const toggleFAQ = (id: string) => {
    setOpenId(openId === id ? null : id);
  };

  const cleanPhone = settings.whatsapp.replace(/[^0-9]/g, '');

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-10">
      {/* Title */}
      <div className="text-center max-w-xl mx-auto space-y-2">
        <div className="inline-flex items-center gap-1.5 bg-emerald-50 text-emerald-800 text-xs font-bold px-3 py-1 rounded-full border border-emerald-200">
          <HelpCircle className="w-4 h-4 text-emerald-600" />
          <span>Patient Support & Answers</span>
        </div>
        <h1 className="text-3xl font-black text-slate-900 tracking-tight">
          Frequently Asked Questions
        </h1>
        <p className="text-xs sm:text-sm text-slate-500">
          Clear answers regarding ordering medicines, prescription validation, Islamabad delivery, and payment options.
        </p>
      </div>

      {/* Accordion FAQ List */}
      <div className="space-y-3">
        {faqs.map((faq) => {
          const isOpen = openId === faq.id;

          return (
            <div
              key={faq.id}
              className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm transition-all"
            >
              <button
                onClick={() => toggleFAQ(faq.id)}
                className="w-full p-5 text-left flex items-center justify-between gap-4 hover:bg-slate-50/50 transition-colors"
              >
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded mr-2">
                    {faq.category}
                  </span>
                  <h3 className="font-bold text-slate-900 text-sm sm:text-base inline-block mt-1 sm:mt-0">
                    {faq.question}
                  </h3>
                </div>
                <div className="text-slate-400 p-1">
                  {isOpen ? <ChevronUp className="w-5 h-5 text-emerald-700" /> : <ChevronDown className="w-5 h-5" />}
                </div>
              </button>

              {isOpen && (
                <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-600 border-t border-slate-100 leading-relaxed bg-slate-50/30">
                  {faq.answer}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Additional Help Box */}
      <div className="bg-slate-900 text-white p-8 rounded-3xl shadow-xl flex flex-col sm:flex-row items-center justify-between gap-6 text-center sm:text-left">
        <div>
          <h3 className="text-lg font-bold">Have a question not listed here?</h3>
          <p className="text-xs text-slate-300 mt-1 max-w-md">
            Our Islamabad dispensary staff is on duty daily from 8:00 AM to 12:00 Midnight to answer
            clinical or dispatch questions.
          </p>
        </div>

        <div className="flex flex-wrap gap-3">
          <a
            href={`https://wa.me/${cleanPhone}`}
            target="_blank"
            rel="noreferrer"
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-md transition-colors"
          >
            <MessageCircle className="w-4 h-4" /> Ask on WhatsApp
          </a>
          <a
            href={`tel:${settings.phone}`}
            className="bg-white/10 hover:bg-white/20 text-white font-bold text-xs px-4 py-2.5 rounded-xl flex items-center gap-2 transition-colors border border-white/20"
          >
            <Phone className="w-4 h-4" /> Call Pharmacist
          </a>
        </div>
      </div>
    </div>
  );
};
