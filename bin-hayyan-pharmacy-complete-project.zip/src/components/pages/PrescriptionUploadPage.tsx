import React, { useState } from 'react';
import {
  FileText,
  Upload,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Clock,
  Phone,
  Lock,
  ArrowRight,
  Eye,
} from 'lucide-react';
import { usePharmacy } from '../../context/PharmacyContext';

export const PrescriptionUploadPage: React.FC = () => {
  const { uploadPrescription, currentUser, deliveryZones, navigateTo, showToast } = usePharmacy();

  const [patientName, setPatientName] = useState(currentUser?.name || '');
  const [patientPhone, setPatientPhone] = useState(currentUser?.phone || '+92 300 ');
  const [patientEmail, setPatientEmail] = useState(currentUser?.email || '');
  const [patientAge, setPatientAge] = useState('');
  const [doctorName, setDoctorName] = useState('');
  const [sectorArea, setSectorArea] = useState('F-7');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [preferredDeliveryTime, setPreferredDeliveryTime] = useState('Earliest available delivery (45 - 90 mins)');
  const [additionalNotes, setAdditionalNotes] = useState('');

  // File state
  const [fileName, setFileName] = useState<string>('');
  const [fileType, setFileType] = useState<string>('');
  const [fileSize, setFileSize] = useState<string>('');
  const [fileUrl, setFileUrl] = useState<string>('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submittedRef, setSubmittedRef] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Sector list from delivery zones
  const allSectors = deliveryZones.flatMap((z) => z.sectors);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check size limit: 10MB
    if (file.size > 10 * 1024 * 1024) {
      showToast('File size must be under 10MB.', 'error');
      return;
    }

    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
    if (!validTypes.includes(file.type)) {
      showToast('Please upload a JPG, PNG, or PDF file.', 'error');
      return;
    }

    setFileName(file.name);
    setFileType(file.type);
    setFileSize(`${(file.size / (1024 * 1024)).toFixed(2)} MB`);

    const reader = new FileReader();
    reader.onload = () => {
      setFileUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
    showToast(`Prescription file attached: ${file.name}`, 'info');
  };

  const handleUseSamplePrescription = () => {
    setFileName('sample_dr_prescription_islamabad.jpg');
    setFileType('image/jpeg');
    setFileSize('1.2 MB');
    setFileUrl('https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=800&q=80');
    setDoctorName('Dr. Asad Ullah Khan (Consultant, Shifa International Hospital Islamabad)');
    setAdditionalNotes('Please deliver 1 strip of Augmentin 625mg and 1 Ventolin Inhaler as indicated on slip.');
    showToast('Demo prescription document loaded.', 'info');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!patientName.trim()) {
      showToast('Please enter patient name.', 'error');
      return;
    }

    if (!patientPhone.trim() || patientPhone.trim().length < 9) {
      showToast('Please provide a valid Pakistani contact phone number.', 'error');
      return;
    }

    if (!fileUrl && !fileName) {
      showToast('Please upload or attach your doctor prescription document.', 'error');
      return;
    }

    setIsSubmitting(true);

    try {
      const rx = uploadPrescription({
        userId: currentUser?.id,
        patientName,
        patientPhone,
        patientEmail,
        patientAge,
        doctorName,
        sectorArea,
        deliveryAddress: deliveryAddress || `Sector ${sectorArea}, Islamabad`,
        preferredDeliveryTime,
        additionalNotes,
        fileName: fileName || 'prescription_document.jpg',
        fileType: fileType || 'image/jpeg',
        fileSize: fileSize || '1.1 MB',
        fileUrl: fileUrl || 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=800&q=80',
      });

      setSubmittedRef(rx.referenceNumber);
      setIsSubmitted(true);
    } catch {
      showToast('Failed to submit prescription. Please try again.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSubmitted) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16">
        <div className="bg-white border border-emerald-200 rounded-3xl p-8 sm:p-12 shadow-xl text-center space-y-6">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-inner">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <span className="text-xs uppercase font-extrabold tracking-widest text-emerald-800 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
              Prescription Ref: {submittedRef}
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              Prescription Submitted Successfully
            </h2>
          </div>

          <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl text-xs sm:text-sm text-emerald-950 text-left leading-relaxed space-y-2">
            <p className="font-semibold">
              “Your prescription has been submitted successfully. Our pharmacy team will review it and
              contact you regarding availability, pricing, and order confirmation.”
            </p>
            <p className="text-emerald-800 text-xs">
              • A licensed PharmD pharmacist will review the medical doctor's stamp and dosage.
              <br />
              • We will contact you at <strong>{patientPhone}</strong> to verify the medicines before preparing delivery.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-left bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <div>
              <span className="text-slate-400 block text-[11px]">Patient Name</span>
              <strong className="text-slate-800">{patientName}</strong>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Contact Phone</span>
              <strong className="text-slate-800">{patientPhone}</strong>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Delivery Sector</span>
              <strong className="text-slate-800">{sectorArea}, Islamabad</strong>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Attached File</span>
              <strong className="text-slate-800 truncate block">{fileName}</strong>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
            <button
              onClick={() => navigateTo('account', { tab: 'prescriptions' })}
              className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs sm:text-sm px-6 py-3 rounded-xl shadow-md transition-colors"
            >
              View My Prescriptions History
            </button>
            <button
              onClick={() => navigateTo('home')}
              className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs sm:text-sm px-6 py-3 rounded-xl transition-colors"
            >
              Return to Homepage
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto space-y-2">
        <div className="inline-flex items-center gap-1.5 bg-emerald-50 text-emerald-800 text-xs font-bold px-3 py-1 rounded-full border border-emerald-200">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>DRAP Healthcare Safety & Compliance</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
          Upload Doctor's Prescription
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
          Order your doctor-prescribed medications safely. Our licensed Islamabad pharmacy team
          will inspect the slip, confirm active strengths, and prepare your delivery.
        </p>
      </div>

      {/* Safety Policy Alert Banner */}
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-xs text-amber-900 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <strong className="font-bold block text-amber-950 mb-0.5">
            Strict Pharmacist Review Mandate:
          </strong>
          <span>
            In accordance with Pakistani pharmaceutical safety regulations, prescription medicines will
            <strong> NOT be automatically dispensed </strong> without review and verification by our
            licensed pharmacist. Your prescription image is kept completely confidential and encrypted.
          </span>
        </div>
      </div>

      {/* Main Upload Form */}
      <form
        onSubmit={handleSubmit}
        className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-10 shadow-lg space-y-8"
      >
        {/* Step 1: Upload Document Area */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-emerald-600 text-white text-xs flex items-center justify-center font-bold">
                1
              </span>
              <span>Upload Prescription Document (JPG, PNG, PDF)</span>
            </label>

            {/* Quick Demo Upload Button */}
            <button
              type="button"
              onClick={handleUseSamplePrescription}
              className="text-xs text-emerald-700 hover:text-emerald-800 font-semibold underline"
            >
              Use Sample Prescription File
            </button>
          </div>

          <div className="border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-2xl p-6 sm:p-8 text-center transition-colors bg-slate-50/50">
            {fileName ? (
              <div className="flex flex-col items-center gap-2">
                <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <FileText className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-bold text-slate-900 text-sm truncate max-w-xs">{fileName}</p>
                  <p className="text-[11px] text-slate-500">
                    {fileSize} • {fileType}
                  </p>
                </div>
                <div className="flex gap-2 mt-2">
                  <label className="cursor-pointer bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-semibold px-3 py-1.5 rounded-lg shadow-sm">
                    <span>Change File</span>
                    <input
                      type="file"
                      accept=".jpg,.jpeg,.png,.pdf"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                  </label>
                  {fileUrl && fileType.startsWith('image') && (
                    <a
                      href={fileUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1"
                    >
                      <Eye className="w-3.5 h-3.5" /> Preview
                    </a>
                  )}
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-3">
                <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <Upload className="w-7 h-7" />
                </div>
                <div className="space-y-1">
                  <p className="font-bold text-slate-800 text-sm">
                    Drag and drop your prescription or{' '}
                    <label className="text-emerald-700 hover:underline cursor-pointer">
                      browse device
                      <input
                        type="file"
                        accept=".jpg,.jpeg,.png,.pdf"
                        onChange={handleFileChange}
                        className="hidden"
                      />
                    </label>
                  </p>
                  <p className="text-xs text-slate-400">
                    Supports high-resolution camera photos (JPG, PNG) or Clinic PDF (Max 10MB)
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Step 2: Patient & Doctor Information */}
        <div className="space-y-4 border-t border-slate-100 pt-6">
          <label className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-emerald-600 text-white text-xs flex items-center justify-center font-bold">
              2
            </span>
            <span>Patient & Contact Details</span>
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Patient Full Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                placeholder="e.g. Tariq Mehmood"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Mobile Number (for Pharmacist Call / WhatsApp) <span className="text-rose-500">*</span>
              </label>
              <input
                type="tel"
                required
                value={patientPhone}
                onChange={(e) => setPatientPhone(e.target.value)}
                placeholder="+92 3XX-XXXXXXX"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Email Address (Optional)
              </label>
              <input
                type="email"
                value={patientEmail}
                onChange={(e) => setPatientEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Patient Age / Notes
              </label>
              <input
                type="text"
                value={patientAge}
                onChange={(e) => setPatientAge(e.target.value)}
                placeholder="e.g. 45 years / Pediatric"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Prescribing Doctor & Hospital / Clinic
              </label>
              <input
                type="text"
                value={doctorName}
                onChange={(e) => setDoctorName(e.target.value)}
                placeholder="e.g. Dr. Asad Ullah Khan (Shifa International Hospital Islamabad)"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white"
              />
            </div>
          </div>
        </div>

        {/* Step 3: Islamabad Delivery Information */}
        <div className="space-y-4 border-t border-slate-100 pt-6">
          <label className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-emerald-600 text-white text-xs flex items-center justify-center font-bold">
              3
            </span>
            <span>Islamabad Delivery Preferences</span>
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Islamabad Sector / Area <span className="text-rose-500">*</span>
              </label>
              <select
                value={sectorArea}
                onChange={(e) => setSectorArea(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
              >
                {allSectors.map((sector) => (
                  <option key={sector} value={sector}>
                    {sector} (Islamabad / ICT)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Preferred Delivery Time
              </label>
              <select
                value={preferredDeliveryTime}
                onChange={(e) => setPreferredDeliveryTime(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
              >
                <option value="Earliest available delivery (45 - 90 mins)">
                  Earliest available delivery (45 - 90 mins)
                </option>
                <option value="Morning Delivery (9:00 AM - 12:00 PM)">
                  Morning Delivery (9:00 AM - 12:00 PM)
                </option>
                <option value="Afternoon Delivery (1:00 PM - 5:00 PM)">
                  Afternoon Delivery (1:00 PM - 5:00 PM)
                </option>
                <option value="Evening Delivery (6:00 PM - 10:00 PM)">
                  Evening Delivery (6:00 PM - 10:00 PM)
                </option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Street Address / House #
              </label>
              <input
                type="text"
                value={deliveryAddress}
                onChange={(e) => setDeliveryAddress(e.target.value)}
                placeholder="House # 12, Street 34, Subsector / Landmark"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Additional Instructions or Specific Medicines Needed
              </label>
              <textarea
                rows={3}
                value={additionalNotes}
                onChange={(e) => setAdditionalNotes(e.target.value)}
                placeholder="e.g. Please provide generic alternative if brand is unavailable, or specify number of days course..."
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>
          </div>
        </div>

        {/* Security & Privacy Assurance */}
        <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-600 flex items-center gap-3">
          <Lock className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>
            Patient privacy guaranteed. Prescription files and clinical records are protected from public access
            and accessible strictly to licensed pharmacy verification staff.
          </span>
        </div>

        {/* Submit Button */}
        <div>
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-4 px-6 rounded-2xl bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-sm sm:text-base shadow-xl shadow-emerald-700/20 transition-all hover:scale-[1.01] active:scale-[0.99] flex items-center justify-center gap-2"
          >
            <FileText className="w-5 h-5" />
            <span>{isSubmitting ? 'Submitting to Pharmacist...' : 'Submit Prescription for Verification'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </form>
    </div>
  );
};
