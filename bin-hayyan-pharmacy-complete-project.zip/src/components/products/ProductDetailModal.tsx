import React, { useState } from 'react';
import {
  X,
  ShoppingCart,
  Heart,
  FileText,
  ShieldAlert,
  Thermometer,
  Info,
  CheckCircle2,
  Building,
  Tag,
  Share2,
} from 'lucide-react';
import { Product } from '../../types/pharmacy';
import { usePharmacy } from '../../context/PharmacyContext';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({ product, onClose }) => {
  const { addToCart, toggleWishlist, isInWishlist, navigateTo, showToast } = usePharmacy();
  const [quantity, setQuantity] = useState(1);

  if (!product) return null;

  const inWishlist = isInWishlist(product.id);
  const isOutOfStock = product.stock <= 0;

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      showToast('Product link copied to clipboard!', 'info');
    }
  };

  const handleAddToCart = () => {
    addToCart(product, quantity);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6">
      <div
        className="relative bg-white rounded-3xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto border border-slate-200 animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 text-slate-400 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-full transition-colors"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-6 sm:p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
            {/* Product Image Column */}
            <div>
              <div className="relative rounded-2xl overflow-hidden bg-slate-50 border border-slate-200 aspect-square flex items-center justify-center">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover object-center"
                />
                {product.requiresPrescription && (
                  <div className="absolute top-3 left-3 bg-amber-500 text-white text-xs font-bold px-2.5 py-1 rounded-md shadow-sm flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5" /> Doctor Prescription (Rx) Required
                  </div>
                )}
              </div>

              {/* Action Buttons row */}
              <div className="mt-4 flex items-center gap-3">
                <button
                  onClick={() => toggleWishlist(product.id)}
                  className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 border transition-colors ${
                    inWishlist
                      ? 'bg-rose-50 border-rose-200 text-rose-600'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${inWishlist ? 'fill-rose-500' : ''}`} />
                  {inWishlist ? 'Saved in Wishlist' : 'Add to Wishlist'}
                </button>

                <button
                  onClick={handleShare}
                  className="p-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
                  title="Share product link"
                >
                  <Share2 className="w-4 h-4" />
                </button>
              </div>

              {/* Cold-chain / storage notice */}
              <div className="mt-4 p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl text-xs text-emerald-900 flex items-start gap-2.5">
                <Thermometer className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="block font-semibold">Storage & Cold-Chain Assurance:</strong>
                  <span className="text-emerald-800">{product.storageInfo}</span>
                </div>
              </div>
            </div>

            {/* Product Details Column */}
            <div className="space-y-4">
              <div>
                <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
                  <span className="font-bold text-emerald-800 uppercase tracking-wide">
                    {product.brand}
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1 text-slate-600">
                    <Building className="w-3 h-3" /> {product.manufacturer}
                  </span>
                </div>

                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 leading-snug">
                  {product.name}
                </h2>

                <p className="mt-1 text-xs font-medium text-emerald-700 bg-emerald-50 inline-block px-2.5 py-1 rounded-md border border-emerald-200">
                  Active Formula / Salt: {product.genericName}
                </p>
              </div>

              {/* Price & Stock */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <div className="flex items-baseline justify-between mb-3">
                  <div>
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl font-black text-slate-900">
                        PKR {product.discountPrice ?? product.price}
                      </span>
                      {product.discountPrice && (
                        <span className="text-sm text-slate-400 line-through">
                          PKR {product.price}
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-slate-500 block">
                      Price inclusive of all applicable government taxes
                    </span>
                  </div>

                  <div className="text-right">
                    {isOutOfStock ? (
                      <span className="inline-block px-2.5 py-1 rounded-md bg-rose-100 text-rose-700 font-bold text-xs">
                        Out of Stock
                      </span>
                    ) : (
                      <span className="inline-block px-2.5 py-1 rounded-md bg-emerald-100 text-emerald-800 font-bold text-xs">
                        {product.stock} In Stock
                      </span>
                    )}
                  </div>
                </div>

                {/* Quantity and Add to Cart */}
                <div className="flex items-center gap-3">
                  <div className="flex items-center border border-slate-300 rounded-xl bg-white">
                    <button
                      onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                      disabled={quantity <= 1 || isOutOfStock}
                      className="px-3 py-2 text-slate-600 hover:text-slate-900 disabled:opacity-40"
                    >
                      -
                    </button>
                    <span className="px-3 py-2 text-xs font-bold text-slate-800 min-w-[32px] text-center">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))}
                      disabled={quantity >= product.stock || isOutOfStock}
                      className="px-3 py-2 text-slate-600 hover:text-slate-900 disabled:opacity-40"
                    >
                      +
                    </button>
                  </div>

                  <button
                    onClick={handleAddToCart}
                    disabled={isOutOfStock}
                    className="flex-1 py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold bg-emerald-700 hover:bg-emerald-800 text-white shadow-md shadow-emerald-700/20 disabled:bg-slate-200 disabled:text-slate-400 disabled:shadow-none flex items-center justify-center gap-2 transition-all"
                  >
                    <ShoppingCart className="w-4 h-4" />
                    <span>Add to Cart (PKR {(product.discountPrice ?? product.price) * quantity})</span>
                  </button>
                </div>
              </div>

              {/* Prescription Guidance Banner */}
              {product.requiresPrescription && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-start gap-2.5">
                  <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block font-bold">Pharmacist Prescription Notice:</strong>
                    <span>
                      This is a prescription medication. You can checkout now, but order verification
                      requires uploading your doctor’s prescription before dispatch.
                    </span>
                    <button
                      onClick={() => {
                        onClose();
                        navigateTo('prescription-upload');
                      }}
                      className="mt-1.5 block text-amber-800 font-bold underline hover:text-amber-900"
                    >
                      Upload Doctor’s Prescription Now →
                    </button>
                  </div>
                </div>
              )}

              {/* Specs List */}
              <div className="space-y-2 text-xs text-slate-600 pt-2">
                <div className="grid grid-cols-2 gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Dosage Form</span>
                    <strong className="text-slate-800">{product.dosageForm}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Pack Size</span>
                    <strong className="text-slate-800">{product.packSize}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Strength</span>
                    <strong className="text-slate-800">{product.strength}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">SKU / Barcode</span>
                    <strong className="text-slate-800">{product.sku}</strong>
                  </div>
                </div>

                <div>
                  <h4 className="font-bold text-slate-900 mb-1 flex items-center gap-1.5">
                    <Info className="w-3.5 h-3.5 text-emerald-600" /> Usage & Administration
                  </h4>
                  <p className="text-slate-600 leading-relaxed bg-slate-50/50 p-2.5 rounded-lg border border-slate-100">
                    {product.usageInstructions}
                  </p>
                </div>

                {product.warnings && (
                  <div>
                    <h4 className="font-bold text-slate-900 mb-1 flex items-center gap-1.5 text-rose-800">
                      <ShieldAlert className="w-3.5 h-3.5 text-rose-600" /> Warnings & Precautions
                    </h4>
                    <p className="text-rose-900/90 leading-relaxed bg-rose-50/50 p-2.5 rounded-lg border border-rose-100 text-[11px]">
                      {product.warnings}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
