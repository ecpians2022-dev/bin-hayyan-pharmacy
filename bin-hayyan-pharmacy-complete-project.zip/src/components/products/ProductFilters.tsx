import React from 'react';
import { Filter, Check, RotateCcw } from 'lucide-react';
import { ProductCategory } from '../../types/pharmacy';
import { usePharmacy } from '../../context/PharmacyContext';

interface ProductFiltersProps {
  selectedCategory: ProductCategory | 'All';
  onSelectCategory: (cat: ProductCategory | 'All') => void;
  filterPrescription: 'all' | 'otc' | 'rx';
  setFilterPrescription: (val: 'all' | 'otc' | 'rx') => void;
  inStockOnly: boolean;
  setInStockOnly: (val: boolean) => void;
  maxPrice: number;
  setMaxPrice: (val: number) => void;
  selectedBrand: string;
  setSelectedBrand: (brand: string) => void;
  brands: string[];
  onReset: () => void;
}

export const ProductFilters: React.FC<ProductFiltersProps> = ({
  selectedCategory,
  onSelectCategory,
  filterPrescription,
  setFilterPrescription,
  inStockOnly,
  setInStockOnly,
  maxPrice,
  setMaxPrice,
  selectedBrand,
  setSelectedBrand,
  brands,
  onReset,
}) => {
  const { categories } = usePharmacy();

  return (
    <aside className="bg-white border border-slate-200 rounded-2xl p-5 space-y-6">
      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
        <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
          <Filter className="w-4 h-4 text-emerald-600" /> Filters & Categories
        </h3>
        <button
          onClick={onReset}
          className="text-[11px] text-slate-500 hover:text-emerald-700 flex items-center gap-1 font-semibold"
        >
          <RotateCcw className="w-3 h-3" /> Reset
        </button>
      </div>

      {/* Category List */}
      <div>
        <label className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-2.5">
          Department / Category
        </label>
        <div className="space-y-1 max-h-56 overflow-y-auto pr-1">
          <button
            onClick={() => onSelectCategory('All')}
            className={`w-full text-left px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors ${
              selectedCategory === 'All'
                ? 'bg-emerald-700 text-white'
                : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <span>All Categories</span>
            {selectedCategory === 'All' && <Check className="w-3.5 h-3.5" />}
          </button>

          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => onSelectCategory(cat)}
              className={`w-full text-left px-3 py-1.5 rounded-lg text-xs font-medium flex items-center justify-between transition-colors ${
                selectedCategory === cat
                  ? 'bg-emerald-700 text-white font-semibold'
                  : 'text-slate-700 hover:bg-slate-100'
              }`}
            >
              <span className="truncate">{cat}</span>
              {selectedCategory === cat && <Check className="w-3.5 h-3.5" />}
            </button>
          ))}
        </div>
      </div>

      {/* Prescription Requirement */}
      <div className="border-t border-slate-100 pt-4">
        <label className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-2.5">
          Prescription Type
        </label>
        <div className="space-y-1.5">
          <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
            <input
              type="radio"
              name="rx_type"
              checked={filterPrescription === 'all'}
              onChange={() => setFilterPrescription('all')}
              className="accent-emerald-600"
            />
            <span>All Products</span>
          </label>
          <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
            <input
              type="radio"
              name="rx_type"
              checked={filterPrescription === 'otc'}
              onChange={() => setFilterPrescription('otc')}
              className="accent-emerald-600"
            />
            <span>OTC (No Prescription Required)</span>
          </label>
          <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
            <input
              type="radio"
              name="rx_type"
              checked={filterPrescription === 'rx'}
              onChange={() => setFilterPrescription('rx')}
              className="accent-emerald-600"
            />
            <span>Prescription Only (Rx)</span>
          </label>
        </div>
      </div>

      {/* In Stock Only Checkbox */}
      <div className="border-t border-slate-100 pt-4">
        <label className="flex items-center gap-2 text-xs font-semibold text-slate-800 cursor-pointer">
          <input
            type="checkbox"
            checked={inStockOnly}
            onChange={(e) => setInStockOnly(e.target.checked)}
            className="w-4 h-4 rounded text-emerald-600 accent-emerald-600 cursor-pointer"
          />
          <span>In Stock in Islamabad Only</span>
        </label>
      </div>

      {/* Brand Filter */}
      {brands.length > 0 && (
        <div className="border-t border-slate-100 pt-4">
          <label className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-2.5">
            Brand / Manufacturer
          </label>
          <select
            value={selectedBrand}
            onChange={(e) => setSelectedBrand(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-600"
          >
            <option value="">All Brands & Companies</option>
            {brands.map((b) => (
              <option key={b} value={b}>
                {b}
              </option>
            ))}
          </select>
        </div>
      )}

      {/* Price Slider */}
      <div className="border-t border-slate-100 pt-4">
        <div className="flex items-center justify-between text-xs mb-2">
          <label className="font-bold text-slate-900 uppercase tracking-wider text-[11px]">
            Max Price
          </label>
          <span className="font-extrabold text-emerald-800">PKR {maxPrice}</span>
        </div>
        <input
          type="range"
          min="100"
          max="15000"
          step="100"
          value={maxPrice}
          onChange={(e) => setMaxPrice(Number(e.target.value))}
          className="w-full accent-emerald-700 cursor-pointer"
        />
        <div className="flex justify-between text-[10px] text-slate-400 mt-1">
          <span>PKR 100</span>
          <span>PKR 15,000</span>
        </div>
      </div>
    </aside>
  );
};
