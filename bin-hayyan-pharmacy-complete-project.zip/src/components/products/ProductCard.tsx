import React from 'react';
import { ShoppingCart, Heart, FileText, Check, AlertTriangle, Eye } from 'lucide-react';
import { Product } from '../../types/pharmacy';
import { usePharmacy } from '../../context/PharmacyContext';

interface ProductCardProps {
  product: Product;
  onQuickView?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onQuickView }) => {
  const { addToCart, toggleWishlist, isInWishlist, navigateTo } = usePharmacy();
  const inWishlist = isInWishlist(product.id);

  const isLowStock = product.stock > 0 && product.stock <= product.lowStockThreshold;
  const isOutOfStock = product.stock <= 0;

  const handleCardClick = () => {
    if (onQuickView) {
      onQuickView(product);
    } else {
      navigateTo('product-detail', { productId: product.id });
    }
  };

  return (
    <div className="group relative bg-white border border-slate-200 rounded-2xl p-4 flex flex-col justify-between hover:shadow-xl hover:border-emerald-300 transition-all duration-200">
      {/* Top Badges */}
      <div className="flex items-start justify-between gap-1 mb-2.5 z-10">
        <div className="flex flex-wrap gap-1">
          {product.requiresPrescription ? (
            <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-800 border border-amber-300 text-[10px] font-bold px-2 py-0.5 rounded-md">
              <FileText className="w-3 h-3 text-amber-600" /> Rx Required
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-semibold px-2 py-0.5 rounded-md">
              OTC / Non-Rx
            </span>
          )}

          {product.discountPrice && (
            <span className="bg-rose-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-md">
              SAVE PKR {product.price - product.discountPrice}
            </span>
          )}
        </div>

        {/* Wishlist button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
          className={`p-1.5 rounded-full transition-colors ${
            inWishlist
              ? 'text-rose-500 bg-rose-50'
              : 'text-slate-400 hover:text-rose-500 hover:bg-slate-100'
          }`}
          aria-label="Add to Wishlist"
        >
          <Heart className={`w-4 h-4 ${inWishlist ? 'fill-rose-500' : ''}`} />
        </button>
      </div>

      {/* Product Image */}
      <div
        onClick={handleCardClick}
        className="relative w-full h-44 mb-3 rounded-xl overflow-hidden bg-slate-50 flex items-center justify-center cursor-pointer group-hover:opacity-95"
      >
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
          onError={(e) => {
            // fallback placeholder if remote image fails
            (e.target as HTMLImageElement).src =
              'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=600&q=80';
          }}
        />

        {/* Quick View Button on hover */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            if (onQuickView) onQuickView(product);
          }}
          className="absolute inset-auto bottom-2 bg-white/95 text-slate-800 text-xs font-semibold px-3 py-1.5 rounded-lg shadow-md opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1.5 border border-slate-200"
        >
          <Eye className="w-3.5 h-3.5 text-emerald-600" /> Details
        </button>
      </div>

      {/* Product Information */}
      <div className="flex-1 flex flex-col justify-between" onClick={handleCardClick}>
        <div className="cursor-pointer">
          <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
            <span className="font-semibold text-emerald-800 uppercase tracking-wider text-[10px]">
              {product.brand}
            </span>
            <span className="text-slate-400 truncate max-w-[120px]">{product.manufacturer}</span>
          </div>

          <h3 className="font-bold text-slate-900 text-sm leading-snug line-clamp-2 hover:text-emerald-700 transition-colors">
            {product.name}
          </h3>

          {/* Generic salt & strength */}
          <div className="mt-1 bg-slate-50 border border-slate-100 rounded-lg p-1.5 text-[11px] text-slate-600">
            <p className="truncate font-medium text-slate-700">
              <span className="text-slate-400">Salt:</span> {product.genericName}
            </p>
            <div className="flex items-center justify-between mt-0.5 text-[10px] text-slate-500">
              <span>{product.strength}</span>
              <span>•</span>
              <span className="truncate">{product.packSize}</span>
            </div>
          </div>
        </div>

        {/* Pricing & Stock status */}
        <div className="mt-3 pt-3 border-t border-slate-100">
          <div className="flex items-baseline justify-between mb-2">
            <div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-base font-extrabold text-slate-900">
                  PKR {product.discountPrice ?? product.price}
                </span>
                {product.discountPrice && (
                  <span className="text-xs text-slate-400 line-through">
                    PKR {product.price}
                  </span>
                )}
              </div>
            </div>

            {/* Stock indicator */}
            <div className="text-[11px]">
              {isOutOfStock ? (
                <span className="text-rose-600 font-semibold flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" /> Out of stock
                </span>
              ) : isLowStock ? (
                <span className="text-amber-600 font-medium">
                  Only {product.stock} left
                </span>
              ) : (
                <span className="text-emerald-700 font-medium flex items-center gap-1">
                  <Check className="w-3 h-3 text-emerald-600" /> In Stock
                </span>
              )}
            </div>
          </div>

          {/* Add to Cart CTA */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              addToCart(product, 1);
            }}
            disabled={isOutOfStock}
            className={`w-full py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              isOutOfStock
                ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                : 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-sm shadow-emerald-700/20 active:scale-[0.98]'
            }`}
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            <span>{isOutOfStock ? 'Notify When Available' : 'Add to Cart'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
