/**
 * Standalone Pure TypeScript ZIP Archive Generator
 * Creates standard, universally extractable .zip files in the browser
 * without external packages or server dependencies.
 */

// CRC-32 Table
const crcTable: Uint32Array = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();

function computeCRC32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    crc = (crc >>> 8) ^ crcTable[(crc ^ bytes[i]) & 0xff];
  }
  return (crc ^ 0xffffffff) >>> 0;
}

export interface ZipFileEntry {
  filename: string;
  content: string | Uint8Array;
}

export function createZipArchive(entries: ZipFileEntry[]): Blob {
  const encoder = new TextEncoder();
  const fileParts: Uint8Array[] = [];
  const centralDirParts: Uint8Array[] = [];

  let currentOffset = 0;

  for (const entry of entries) {
    const filenameBytes = encoder.encode(entry.filename);
    const contentBytes =
      typeof entry.content === 'string' ? encoder.encode(entry.content) : entry.content;

    const crc = computeCRC32(contentBytes);
    const size = contentBytes.length;

    // Local Header (30 bytes + filename)
    const localHeader = new Uint8Array(30 + filenameBytes.length);
    const localView = new DataView(localHeader.buffer);

    localView.setUint32(0, 0x04034b50, true); // Local header signature
    localView.setUint16(4, 20, true); // Version needed (2.0)
    localView.setUint16(6, 0, true); // General purpose bit flag
    localView.setUint16(8, 0, true); // Compression method: 0 (Stored/Uncompressed)
    localView.setUint16(10, 0x4a21, true); // Mod time (approx)
    localView.setUint16(12, 0x58a5, true); // Mod date (approx)
    localView.setUint32(14, crc, true); // CRC32
    localView.setUint32(18, size, true); // Compressed size
    localView.setUint32(22, size, true); // Uncompressed size
    localView.setUint16(26, filenameBytes.length, true); // Filename length
    localView.setUint16(28, 0, true); // Extra field length

    localHeader.set(filenameBytes, 30);

    fileParts.push(localHeader);
    fileParts.push(contentBytes);

    // Central Directory Header (46 bytes + filename)
    const cdHeader = new Uint8Array(46 + filenameBytes.length);
    const cdView = new DataView(cdHeader.buffer);

    cdView.setUint32(0, 0x02014b50, true); // Central directory signature
    cdView.setUint16(4, 20, true); // Version made by
    cdView.setUint16(6, 20, true); // Version needed
    cdView.setUint16(8, 0, true); // Flags
    cdView.setUint16(10, 0, true); // Compression method
    cdView.setUint16(12, 0x4a21, true); // Mod time
    cdView.setUint16(14, 0x58a5, true); // Mod date
    cdView.setUint32(16, crc, true); // CRC32
    cdView.setUint32(20, size, true); // Compressed size
    cdView.setUint32(24, size, true); // Uncompressed size
    cdView.setUint16(28, filenameBytes.length, true); // Filename length
    cdView.setUint16(30, 0, true); // Extra field length
    cdView.setUint16(32, 0, true); // Comment length
    cdView.setUint16(34, 0, true); // Disk number start
    cdView.setUint16(36, 0, true); // Internal attributes
    cdView.setUint32(38, 0, true); // External attributes
    cdView.setUint32(42, currentOffset, true); // Local header offset

    cdHeader.set(filenameBytes, 46);
    centralDirParts.push(cdHeader);

    currentOffset += localHeader.length + contentBytes.length;
  }

  // End of Central Directory (EOCD)
  const cdOffset = currentOffset;
  const cdSize = centralDirParts.reduce((acc, part) => acc + part.length, 0);

  const eocd = new Uint8Array(22);
  const eocdView = new DataView(eocd.buffer);

  eocdView.setUint32(0, 0x06054b50, true); // EOCD signature
  eocdView.setUint16(4, 0, true); // Number of this disk
  eocdView.setUint16(6, 0, true); // Disk where CD starts
  eocdView.setUint16(8, entries.length, true); // Number of CD records on disk
  eocdView.setUint16(10, entries.length, true); // Total number of CD records
  eocdView.setUint32(12, cdSize, true); // Size of central directory
  eocdView.setUint32(16, cdOffset, true); // Offset of start of CD
  eocdView.setUint16(20, 0, true); // Comment length

  const parts: BlobPart[] = [...fileParts, ...centralDirParts, eocd] as unknown as BlobPart[];
  return new Blob(parts, { type: 'application/zip' });
}

export function triggerDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
