# Bin Hayyan Pharmacy — Islamabad, Pakistan 🏥

Official online store and dispensary management platform for **Bin Hayyan Pharmacy** (Islamabad, Pakistan).

## 🌟 Quick Options for Deployment

### Option A: Drag & Drop Upload (No Command Line)
See **`DRAG_AND_DROP_TO_GITHUB_GUIDE.md`** for step-by-step browser upload without terminal or git commands.
The root `index.html` and `assets/` are pre-compiled and ready to serve directly!

### Option B: Automated GitHub Actions CI/CD
1. Push this repository to GitHub main branch.
2. Under **Settings → Pages → Build and deployment > Source**, select **GitHub Actions**.
3. GitHub Actions builds and deploys the site automatically using `.github/workflows/deploy.yml`.

### Option C: Local Developer Run
```bash
npm install
npm run dev
```
Visit `http://localhost:3000`.

## 🔐 Default Admin Access
- **Email:** `admin@binhayyanpharmacy.pk`
- **Password:** `admin123`
- **Change Password:** Go to Admin Portal (`/admin`) → "Change Admin Password" tab.
