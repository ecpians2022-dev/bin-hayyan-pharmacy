# Bin Hayyan Pharmacy — Drag & Drop GitHub Deployment Guide 🚀
*No Command Line / Terminal Required!*

This project includes a **complete production index.html file** and bundled assets. You can launch your website on GitHub Pages entirely through your web browser in less than 2 minutes.

---

## 📌 STEP 1: Create a Repository on GitHub.com
1. Open your browser and visit: **[https://github.com/new](https://github.com/new)**
2. Enter Repository name: `bin-hayyan-pharmacy`
3. Select **Public**
4. (Optional) You can leave "Add a README file" unchecked
5. Click **Create repository**

---

## 📌 STEP 2: Drag & Drop Files to GitHub (No Git Commands!)
1. On the new repository page, click the link: **"uploading an existing file"** (or click **Add file → Upload files**).
2. Unzip/extract this downloaded archive on your computer.
3. Select all the extracted files and folders:
   - `index.html` *(The complete production entrypoint!)*
   - `assets/` *(Contains compiled JS & CSS)*
   - `404.html` *(Routing helper for GitHub Pages)*
   - `.nojekyll` *(Prevents GitHub Jekyll processing)*
   - `logo.svg`
   - `docs/`
   - (Plus any other files)
4. **Drag and drop** them straight into the GitHub upload area in your browser window.
5. Scroll down and click the green button: **"Commit changes"**.

---

## 📌 STEP 3: Turn On GitHub Pages (Free Hosting)
1. In your GitHub repository, click on **Settings** (gear icon at top).
2. On the left sidebar menu, click **Pages** (under Code and automation).
3. Under **Build and deployment**:
   - **Source:** Choose **"Deploy from a branch"**
   - **Branch:** Select **"main"** (or master)
   - **Folder:** Choose **/ (root)** (or **/docs**)
4. Click **Save**.
5. Within 60 seconds, refresh the page. A banner will appear:
   👉 **"Your site is live at https://<your-username>.github.io/bin-hayyan-pharmacy/"**

---

## 🔐 ADMIN PORTAL CREDENTIALS & HOW TO CHANGE PASSWORD

### Default Credentials:
- **Admin Portal URL:** Click **"Admin Portal"** in the Left Sidebar (or navigate to `/admin`)
- **Lead Administrator Email:** `admin@binhayyanpharmacy.pk`
- **Default Password:** `admin123`
- **Dispensary Pharmacist Email:** `pharmacist@binhayyanpharmacy.pk`
- **Default Password:** `pharmacist123`

### How to Change the Admin Password:
1. Open the website and click **"Admin Portal"** on the left sidebar.
2. Sign in using `admin@binhayyanpharmacy.pk` and `admin123` (or use the 1-Click "Lead Admin" login button).
3. In the top navigation tabs of the Admin Dashboard, click on **"Change Admin Password"** (Key icon 🔑).
4. Enter:
   - **Current Password:** `admin123`
   - **New Password:** (your new secure password)
   - **Confirm New Password**
5. Click **"Update Admin Password"**.
6. The new password is saved immediately in persistent browser storage!

### Creating Sub-Users (Staff Members):
1. In the Admin Dashboard, click the **"Create Sub-Users & Staff"** tab.
2. Click **"+ Add New Sub-User"** to create accounts for dispensary clerks, delivery riders, or verification pharmacists.
3. You can set individual passwords or click **"Reset Pass"** on any staff member anytime!
